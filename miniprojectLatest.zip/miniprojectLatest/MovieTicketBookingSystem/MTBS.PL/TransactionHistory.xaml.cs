﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.Entity;
using MTBS.Exception;
using MTBS.BL;


namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for TransactionHistory.xaml
    /// </summary>
    public partial class TransactionHistory : Window
    {
        BookTicketsBL bal = null;
        List<BookTickets> bklist = null;
        Tickets tkts = null;

        public TransactionHistory()
        {
            InitializeComponent();
            bal = new BookTicketsBL();
            bklist = new List<BookTickets>();
            tkts = new Tickets();          

        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtViewersID.Text);
                bklist = bal.GetAll();
                var res = from t in bklist
                          where t.ViewersId == id
                          select t;
                dgvHistory.ItemsSource = res.ToList();
            }

            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            UserHome uh3 = new UserHome();
            uh3.ShowDialog();
        }


    }
}
