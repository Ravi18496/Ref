﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.Entity;
using MTBS.Exception;
using MTBS.BL;


namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for ScreenDetails.xaml
    /// </summary>
    public partial class ScreenDetails : Window
    {
        ManagingScreensBL bal = null;
        List<Screens> allScreens = null;
        Screens sc = null;
        public ScreenDetails()
        {
            InitializeComponent();
            bal = new ManagingScreensBL();
            sc = new Screens();
            cbScreenId.DataContext = bal.GetAll();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                sc.ScreenName = txtName.Text;
                sc.Capacity = Convert.ToInt32(txtCapacity.Text);
                bal.Insert(sc);
                allScreens = bal.GetAll();
                dgScreendetails.ItemsSource = allScreens.ToList();            
            }

             catch (MtbsException ex)
             {
                 MessageBox.Show(ex.Message);
             }
             catch (SystemException ex)
             {
                 MessageBox.Show(ex.Message);
             }
            
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                sc.ScreenID = Convert.ToInt32(cbScreenId.Text);
                sc.ScreenName = txtName.Text;
                sc.Capacity = Convert.ToInt32(txtCapacity.Text);
                bal.Update(sc);
                allScreens = bal.GetAll();
                dgScreendetails.ItemsSource = allScreens.ToList();     
            }
            catch (MtbsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }               
        }



        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            cbScreenId.Text = "";
            txtName.Text = "";
            txtCapacity.Text = "";        
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(cbScreenId.Text);
                bal.Delete(id);
                allScreens = bal.GetAll();
                dgScreendetails.ItemsSource = allScreens.ToList();
                cbScreenId.DataContext = bal.GetAll();
            }
            catch (MtbsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }  
        }

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                allScreens = bal.GetAll();
                PopulatUI(allScreens);

            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void PopulatUI(List<Screens> allscreens)
        {
            dgScreendetails.ItemsSource = allScreens;
            cbScreenId.ItemsSource = allScreens;
            cbScreenId.DisplayMemberPath = "ScreenID";
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            AdminRoles adr = new AdminRoles();
            adr.Show();
            this.Close();
        }
           

            
    }
}
    

