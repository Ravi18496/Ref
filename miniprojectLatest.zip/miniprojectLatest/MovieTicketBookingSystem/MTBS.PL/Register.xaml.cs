﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.Entity;
using MTBS.BL;
using MTBS.Exception;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        Viewers v = null;
        ViewersRegistraionBL bl = null;
        public Register()
        {
            InitializeComponent();
            v = new Viewers();
            bl = new ViewersRegistraionBL();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            int userRegistered = 0;
            SearchMovies sm = new SearchMovies();
            try
            {
                v.FirstName = txtFirstName.Text;
                v.LastName = txtLastName.Text;
                v.MobileNumber = txtMobileNo.Text;
                v.Email = txtEmail.Text;
                v.Username = txtUserName.Text;
                v.Password = pwd.Password;
                userRegistered = bl.Insert(v);
                if (userRegistered == 1)
                {
                    MessageBox.Show("User Registered Successfully");
                    sm.ShowDialog();
                    
                }
                
            }
            catch (MtbsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
