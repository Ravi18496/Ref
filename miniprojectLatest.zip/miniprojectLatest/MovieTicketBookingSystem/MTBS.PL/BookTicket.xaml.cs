﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.Entity;
using MTBS.Exception;
using MTBS.BL;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for BookTicket.xaml
    /// </summary>
    public partial class BookTicket : Window
    {
        BookTicketsBL bl = null;
        List<BookTickets> tickets = null;
        BookTickets b = null;
        ManageMovieDetailsBL bal = null;


        public BookTicket()
        {
            InitializeComponent();
            bl = new BookTicketsBL();
            b = new BookTickets();
            bal = new ManageMovieDetailsBL();
            cbMovieName.DataContext = bal.GetAll();

        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                tickets = bl.GetAll();
                int c = 0;

                int id = Convert.ToInt32(txtViewersID.Text);
                foreach (var item in tickets)
                {
                    if(id == item.ViewersId)
                    {
                        b.ViewersId = Convert.ToInt16(txtViewersID.Text);
                        b.MovieName = cbMovieName.Text;
                        b.ShowDate = Convert.ToDateTime(dtShowDate.Text);
                        b.ShowTime = cbShowTime.Text;
                        b.No_Of_Tickets = Convert.ToInt16(txtNoofTkts.Text);
                        bl.Insert(b);
                        tickets = bl.GetAll();
                        c = 1;

                        txtViewersID.Text = " ";
                        cbShowTime.Text = " ";
                        txtNoofTkts.Text = " ";
                        cbMovieName.Text = " ";
                        dtShowDate.Text = " ";
                        break;


                    }
                }
               
                if(c != 1)
                {
                    MessageBox.Show("Enter Valid Viewers Id");
                    txtViewersID.Text = " ";
                    cbShowTime.Text = " ";
                    txtNoofTkts.Text = " ";
                    cbMovieName.Text = " ";
                    dtShowDate.Text = " ";
                }
               
            }

            catch (MtbsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnPayment_Click(object sender, RoutedEventArgs e)
        {
            Payment p = new Payment();
            p.Show();
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            UserHome uh4 = new UserHome();
            uh4.ShowDialog();
        }

      
    }
}
