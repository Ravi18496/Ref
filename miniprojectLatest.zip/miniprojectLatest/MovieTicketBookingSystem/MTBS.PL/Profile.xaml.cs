﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.BL;
using MTBS.Entity;
using MTBS.Exception;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for Profile.xaml
    /// </summary>
    public partial class Profile : Window
    {
        Viewers v = null;
        ViewersRegistraionBL bal = null;
        List<Viewers> views = null;
        public Profile()
        {
            InitializeComponent();
            v = new Viewers();
            bal = new ViewersRegistraionBL();
        }

        private void btnTransHstry_Click(object sender, RoutedEventArgs e)
        {
            TransactionHistory th = new TransactionHistory();
            th.ShowDialog();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                v.ViewersID = Convert.ToInt32(txtViewerId.Text);
                v.FirstName = txtFirstName.Text;
                v.LastName = txtLastName.Text;
                v.MobileNumber = txtMobileNo.Text;
                v.Password = txtChangePswd.Password;
                v.Username = txtUserName.Text;
                v.Email = txtEmail.Text;
                bal.Update(v);

            }
            catch (MtbsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            views = bal.GetAll();
            try
            {
                int viewerId = int.Parse(txtViewerId.Text);
                foreach (var id in views )
                {
                    if (viewerId == id.ViewersID)
                    {
                        txtFirstName.Text = id.FirstName;
                        txtLastName.Text = id.LastName;
                        txtMobileNo.Text = id.MobileNumber;
                        txtEmail.Text = id.Email;
                        txtUserName.Text = id.Username;
                        txtChangePswd.Password = id.Password;                      

                    }
                }
            }
            catch (MtbsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        
    }
}
