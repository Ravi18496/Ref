﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.Entity;
using MTBS.Exception;
using MTBS.BL;


namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for TicketDetails.xaml
    /// </summary>
    public partial class TicketDetails : Window
    {
        ManagingTicketsBL bal = null;
        List<Tickets> tktsList = null;
        Tickets tkts = null;

        public TicketDetails()
        {
            InitializeComponent();
            bal = new ManagingTicketsBL();
            tktsList = new List<Tickets>();
            tkts = new Tickets();
            cbTicketID.DataContext = bal.GetAll();
            cbViewersID.DataContext = bal.GetAllViewers();
            cbShowID.DataContext = bal.GetAllShows();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                tkts.Transaction_Date = Convert.ToDateTime(dtPicker.Text);
                tkts.No_of_tickets = Convert.ToInt32(txtNoofTickets.Text);
                tkts.ViewersID = Convert.ToInt32(cbViewersID.Text);
                tkts.ShowID = Convert.ToInt32(cbShowID.Text);
                bal.Insert(tkts);
                tktsList = bal.GetAll();
                dgTicketDetails.ItemsSource = tktsList.ToList();
                cbTicketID.DataContext = bal.GetAll();
            }

            catch (MtbsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                tkts.TicketId = Convert.ToInt32(cbTicketID.Text);
                tkts.No_of_tickets = Convert.ToInt32(txtNoofTickets.Text);
                tkts.Transaction_Date = Convert.ToDateTime(dtPicker.Text);
                tkts.ViewersID = Convert.ToInt32(cbViewersID.Text);
                tkts.ShowID = Convert.ToInt32(cbShowID.Text);
                bal.Update(tkts);
                tktsList = bal.GetAll();
                dgTicketDetails.ItemsSource = tktsList.ToList();
            }

            catch (MtbsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnClearAll_Click(object sender, RoutedEventArgs e)
        {
            cbTicketID.Text = "";
            dtPicker.Text = "";
            txtNoofTickets.Text = "";
            cbViewersID.Text = "";
            cbShowID.Text = "";
        }

        private void PopulateUI(List<Tickets> tktsList)
        {
            dgTicketDetails.ItemsSource = tktsList;
            cbTicketID.ItemsSource = tktsList;
            cbTicketID.DisplayMemberPath = "TicketID";
                        
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(cbTicketID.Text);
                bal.Delete(id);
                tktsList = bal.GetAll();
                dgTicketDetails.ItemsSource = tktsList.ToList();
                cbTicketID.DataContext = bal.GetAll();
            }
            catch (MtbsException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }  
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            AdminRoles adr = new AdminRoles();
            adr.Show();
            this.Close();
        }

    }
}
