﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.Entity;
using MTBS.BL;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for Movies.xaml
    /// </summary>
    public partial class SearchMovies : Window
    {
        Movies m = null;
        ManageMovieDetailsBL bal = null;
        SearchMoviesBL bl = null;
        List<Movies> allMovies = null;
        Genre g = null;
        List<Genre> glist = null;

        public SearchMovies()
        {
            InitializeComponent();
            m = new Movies();
            bal = new ManageMovieDetailsBL();
            bl = new SearchMoviesBL();
            cbGenreName.DataContext = bl.GetAllGenre();
        }

        private void btnShowAll_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                allMovies = bal.GetAll();
                dgvMovieDetails.ItemsSource = allMovies.ToList();

            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBookTickets_Click(object sender, RoutedEventArgs e)
        {
            BookTicket bk = new BookTicket();
            bk.Show();
            this.Hide();
            this.Close();
        }

        private void btnsearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string genreName = cbGenreName.Text;
                glist = bal.GetAllGenre();
                var res = from m in glist
                          where m.GenreName == genreName
                          select m;
                int id = 0;
                foreach (var item in res)
                {
                    id = item.GenreID;
                }
                //MessageBox.Show(id.ToString());
                allMovies = new List<Movies>();
                allMovies = bal.GetAll();
                var res1 = from s in allMovies
                           where s.GenreID == id
                           select s;
                dgvMovieDetails.ItemsSource = res1.ToList();
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //private void btnHistory_Click(object sender, RoutedEventArgs e)
        //{
        //    TransactionHistory th = new TransactionHistory();
        //    th.Show();
        //    this.Hide();
        //    this.Close();
        //}

        //private void btnProfile_Click(object sender, RoutedEventArgs e)
        //{
        //    Profile pro = new Profile();
        //    pro.Show();
        //    this.Hide();
        //    this.Close();

        //}

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow hp = new MainWindow();
            hp.Show();
            this.Hide();
            this.Close();
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            UserHome uh2 = new UserHome();
            uh2.ShowDialog();
        }

    }
}
