﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.Entity;
using MTBS.Exception;
using MTBS.BL;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for UserHome.xaml
    /// </summary>
    public partial class UserHome : Window
    {
        public UserHome()
        {
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
           
        }

        private void btnBook_Click(object sender, RoutedEventArgs e)
        {
            BookTicket bkt = new BookTicket();
            bkt.Show();
            this.Close();
        }

        private void btnSearchMov_Click(object sender, RoutedEventArgs e)
        {
            SearchMovies smv = new SearchMovies();
            smv.ShowDialog();
            this.Close();
        }

        private void btnHistory_Click(object sender, RoutedEventArgs e)
        {
            TransactionHistory th = new TransactionHistory();
            th.ShowDialog();
            this.Close();
        }

        private void btnProfile_Click(object sender, RoutedEventArgs e)
        {
            Profile pf = new Profile();
            pf.ShowDialog();
            this.Close();
        }
    }
}
