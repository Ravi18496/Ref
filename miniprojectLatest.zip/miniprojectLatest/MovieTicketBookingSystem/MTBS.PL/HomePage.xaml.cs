﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MTBS.BL;
using MTBS.Entity;
using MTBS.Exception;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ViewersRegistraionBL bal = new ViewersRegistraionBL();
        List<Viewers> viewList = new List<Viewers>();
        public MainWindow()
        {
            viewList = bal.GetAll();
            InitializeComponent();
        }

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{
        //    Register rtr = new Register();
        //    rtr.ShowDialog();

        //}

       // private void Button_Click_1(object sender, RoutedEventArgs e)
        //{
            //SearchMovies mvs = new SearchMovies();

            //string userName = txtUName.Text;
            //string password = txtPwd.Password;

            //bool loginSuccess = false;
     
            //var login = from v in viewList
            //where v.Username == userName && v.Password == password
            //select v;

            //foreach (var item in login)
            //{
            //    loginSuccess = true;
            //    mvs.ShowDialog();
            //    txtUName.Text = "";
            //    txtPwd.Password = "";
            //    //this.Hide();
            //    //this.Close();
            //}
            //if (!loginSuccess)
            //{
            //    MessageBox.Show("Invalid Credentials");
            //}
        //}

        //private void Button_Click_2(object sender, RoutedEventArgs e)
        //{
        //    int i = 0;
        //    while (i == 0)
        //    {
        //        if (txtAdminName.Text == "Admin" && pwdAdminPwd.Password == "admin")
        //        {
        //            AdminRoles adr = new AdminRoles();
        //            adr.ShowDialog();
        //            txtAdminName.Text = "";
        //            pwdAdminPwd.Password="";
        //            i ++;
        //        }

        //        else
        //        {
        //            MessageBox.Show("Entered Credentials are wrong");
        //            i++;
        //            txtAdminName.Text = "";
        //            pwdAdminPwd.Password = "";
        //        }
        //    }
        //}

        private void btnALogin_Click(object sender, RoutedEventArgs e)
        {
            int i = 0;
            while (i == 0)
            {
                if (txtAdminName.Text == "Admin" && pwdAdminpwd.Password == "admin")
                {
                    AdminRoles adr = new AdminRoles();
                    adr.ShowDialog();
                    txtAdminName.Text = "";
                    pwdAdminpwd.Password = "";
                    i++;
                }

                else
                {
                    MessageBox.Show("Entered Credentials are wrong");
                    i++;
                    txtAdminName.Text = "";
                    pwdAdminpwd.Password = "";
                }
            }
        }

        private void btnULogin_Click(object sender, RoutedEventArgs e)
        {
            UserHome mvs = new UserHome();

            string userName = txtUName.Text;
            string password = txtPwd.Password;

            bool loginSuccess = false;

            var login = from v in viewList
                        where v.Username == userName && v.Password == password
                        select v;

            foreach (var item in login)
            {
                loginSuccess = true;
                mvs.ShowDialog();
                txtUName.Text = "";
                txtPwd.Password = "";
                //this.Hide();
                //this.Close();
            }
            if (!loginSuccess)
            {
                MessageBox.Show("Invalid Credentials");
            }

        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            Register rtr = new Register();
            rtr.ShowDialog();
        }
    }
}
