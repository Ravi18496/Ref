﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for ManageScreens.xaml
    /// </summary>
    public partial class AdminRoles : Window
    {
        public AdminRoles()
        {
            InitializeComponent();
        }

        private void btnGenerateReports_Click(object sender, RoutedEventArgs e)
        {
            GenerateReports grd = new GenerateReports();
            grd.Show();
            this.Hide();
            this.Close();
        }

        private void btnManageTicket_Click(object sender, RoutedEventArgs e)
        {
            TicketDetails tcd = new TicketDetails();
            tcd.Show();
            this.Hide();
            this.Close();
        }

        private void btnManageMovie_Click(object sender, RoutedEventArgs e)
        {
            MovieDetails mvd = new MovieDetails();
            mvd.Show();
            this.Hide();
            this.Close();
        }

        private void btnManageScreen_Click(object sender, RoutedEventArgs e)
        {
            ScreenDetails scd = new ScreenDetails();
            scd.Show();
            this.Hide();
            this.Close();
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            MainWindow hp = new MainWindow();
            hp.ShowDialog();
        }

      
    }
}
