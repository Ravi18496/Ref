﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTBS.Entity
{
    public class Tickets
    {
        int ticketId;
        public int TicketId
        {
            get { return ticketId; }
            set { ticketId = value; }
        }

        DateTime transactionDate;
        public DateTime Transaction_Date
        {
            get { return transactionDate; }
            set { transactionDate = value; }
        }

        int noofTickets;
        public int No_of_tickets
        {
            get { return noofTickets; }
            set { noofTickets = value; }
        }

        int viewersID;
        public int ViewersID
        {
            get { return viewersID; }
            set { viewersID = value; }
        }

        int showID;
        public int ShowID
        {
            get { return showID; }
            set { showID = value; }
        }
    }
}
