﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTBS.Entity
{
    public class BookTickets
    {
        int viewersId;
        public int ViewersId
        {
            get { return viewersId; }
            set { viewersId = value; }
        }

        string movieName;
        public string MovieName
        {
            get { return movieName; }
            set { movieName = value; }
        }

        DateTime showDate;
        public DateTime ShowDate
        {
            get { return showDate; }
            set { showDate = value; }
        }
        string showTime;
        public string ShowTime
        {
            get { return showTime; }
            set { showTime = value; }
        }
        int no_Of_Tickets;
        public int No_Of_Tickets
        {
            get { return no_Of_Tickets; }
            set { no_Of_Tickets = value; }
        }
    }
}
