﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTBS.Entity
{
    public class Movies
    {
       
        int movieID;
        public int MovieID
        {
            get { return movieID; }
            set { movieID = value; }
        }

        string movieName;
        public string MovieName
        {
            get { return movieName; }
            set { movieName = value; }
        }

        DateTime releaseDate;
        public DateTime ReleaseDate
        {
            get { return releaseDate; }
            set { releaseDate = value; }
        }

        int genreID;
        public int GenreID
        {
            get { return genreID; }
            set { genreID = value; }
        }

        string movieDescription;
        public string Movie_Description
        {
            get { return movieDescription; }
            set { movieDescription = value; }
        }


    }
}
