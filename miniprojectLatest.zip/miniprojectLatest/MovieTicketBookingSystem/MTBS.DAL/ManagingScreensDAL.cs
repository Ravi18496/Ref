﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using MTBS.Entity;
using MTBS.Exception;
namespace MTBS.DAL
{
    public class ManagingScreensDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public ManagingScreensDAL()
        {
            string cnstr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            cn = new SqlConnection(cnstr);
        }

        public List<Screens> SelectAll()
        {

            List<Screens> cust = new List<Screens>();

            try
            {
                cmd = new SqlCommand("select * from OMTBS_Screens", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                // to retrive records with the help of DR
                while (dr.Read())
                {
                    Screens sc = new Screens();
                    sc.ScreenID = (int)dr[0];
                    sc.ScreenName = dr[1].ToString();
                    sc.Capacity = (int)dr[2];
                    cust.Add(sc);
                }
            }

            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                dr.Close();
                cn.Close();
            }
            return cust;

        }


        public int Insert(Screens sc)
        {
            int n;

            try
            {
                cmd = new SqlCommand("usp_Insert_OMTBS_Screens", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ScreenName", sc.ScreenName);
                cmd.Parameters.AddWithValue("@Capacity", sc.Capacity);
                cn.Open();
                n = cmd.ExecuteNonQuery();
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return n;
        }

        public int Update(Screens sc)
        {
            int n;
            try
            {

                cmd = new SqlCommand("usp_UpdateOMTBS_Screens", cn); //stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ScreenId", sc.ScreenID);
                cmd.Parameters.AddWithValue("@ScreenName", sc.ScreenName);
                cmd.Parameters.AddWithValue("@Capacity", sc.Capacity);
                cn.Open();
                n = cmd.ExecuteNonQuery();
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return n;
        }

        public int Delete(int screenId)
        {
            int n;
            Screens sc = new Screens();
            try
            {
                cmd = new SqlCommand("usp_Delete_OMTBS_Screens", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ScreenID", screenId);
                cn.Open();
                n = cmd.ExecuteNonQuery();
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return n;
        }
    }
}
