﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.Entity;
using System.Data.SqlClient;
using System.Configuration;

namespace MTBS.DAL
{
    public class SearchMoviesDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public SearchMoviesDAL()
        {
            string cnstr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            cn = new SqlConnection(cnstr);
        }

        public List<Genre> SelectGenre()
        {
            List<Genre> gen = new List<Genre>();
            try
            {
                cmd = new SqlCommand("select DISTINCT GenreName from OMTBS_Genre", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Genre g = new Genre();
                    g.GenreName = dr["GenreName"].ToString();
                    gen.Add(g);
                }
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                dr.Close();
                cn.Close();
            }
            return gen;
        }
                

    }
}
