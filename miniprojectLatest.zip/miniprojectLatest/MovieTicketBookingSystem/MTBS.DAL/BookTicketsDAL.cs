﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.Entity;
using MTBS.Exception;
using System.Data.SqlClient;
using System.Configuration;

namespace MTBS.DAL
{
    public class BookTicketsDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public BookTicketsDAL()
        {
            string cnstr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            cn = new SqlConnection(cnstr);
        }
        public List<BookTickets> SelectAll()
        {
            List<BookTickets> booktick = new List<BookTickets>();
            try
            {
                cmd = new SqlCommand("select * from OMTBS_BookTickets order by ShowDate desc", cn);
                //cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    BookTickets b = new BookTickets();
                    b.ViewersId = (int)dr[0];
                    b.MovieName = dr[1].ToString();
                    b.ShowDate = (DateTime)dr[2];
                    b.ShowTime = dr[3].ToString();
                    b.No_Of_Tickets = (int)dr[4];
                    booktick.Add(b);
                }
            }
            catch(MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                dr.Close();
                cn.Close();
            }
            return booktick;
        }
        public int Insert(BookTickets b)
        {
            int tick;

            try
            {
                cmd = new SqlCommand("usp_Insert_OMTBS_BookTickets", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ViewersId", b.ViewersId);
                cmd.Parameters.AddWithValue("@MovieName", b.MovieName);
                cmd.Parameters.AddWithValue("@ShowDate", b.ShowDate);
                cmd.Parameters.AddWithValue("@ShowTime", b.ShowTime);
                cmd.Parameters.AddWithValue("@No_Of_Tickets", b.No_Of_Tickets);

                cn.Open();
                tick = cmd.ExecuteNonQuery();
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return tick;
        }
    }
}
