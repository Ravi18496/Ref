﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.Entity;
using MTBS.Exception;
using System.Data.SqlClient;
using System.Configuration;

namespace MTBS.DAL
{
   
        public class ViewersRegistrationDAL
        {
            SqlConnection cn = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            public ViewersRegistrationDAL()
            {
                string cnstr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
                cn = new SqlConnection(cnstr);

            }

            public List<Viewers> SelectAll()
            {
                List<Viewers> Views = new List<Viewers>();
                try
                {
                    cmd = new SqlCommand("usp_SelectAll_OMTBS_Viewers", cn);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cn.Open();
                    dr = cmd.ExecuteReader();
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            Viewers v = new Viewers();
                            v.ViewersID = (int)dr[0];
                            v.FirstName = dr[1].ToString();
                            v.LastName = dr[2].ToString();
                            v.MobileNumber = dr[3].ToString();
                            v.Email = dr[4].ToString();
                            v.Username = dr[5].ToString();
                            v.Password = dr[6].ToString();
                            Views.Add(v);
                        }
                    }

                    else
                    {
                        throw new MtbsException("There are no users available");
                    }
                }

                catch (MtbsException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                finally
                {
                    dr.Close();
                    cn.Close();
                }
                return Views;
            }

            public int Insert(Viewers v)
            {
                int recordsAffected = 0;
                try
                {

                    cmd = new SqlCommand("usp_Insert_OMTBS_Viewers", cn); //stored procedure
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FirstName", v.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", v.LastName);
                    cmd.Parameters.AddWithValue("@MobileNumber", v.MobileNumber);
                    cmd.Parameters.AddWithValue("@Email", v.Email);
                    cmd.Parameters.AddWithValue("@UserName", v.Username);
                    cmd.Parameters.AddWithValue("@Password", v.Password);
                    cn.Open();
                    recordsAffected = cmd.ExecuteNonQuery();
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                finally
                {
                    cn.Close();
                }
                return recordsAffected;
            }

            public int Update(Viewers v)
            {
                int recordsAffected = 0;

                try
                {
                    cmd = new SqlCommand("usp_Update_OMTBS_Viewers", cn);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ViewersID", v.ViewersID);
                    cmd.Parameters.AddWithValue("@FirstName", v.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", v.LastName);
                    cmd.Parameters.AddWithValue("@MobileNumber", v.MobileNumber);
                    cmd.Parameters.AddWithValue("@Email", v.Email);
                    cmd.Parameters.AddWithValue("@UserName", v.Username);
                    cmd.Parameters.AddWithValue("@Password", v.Password);
                    cn.Open();
                    recordsAffected = cmd.ExecuteNonQuery();
                }
                catch (MtbsException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                finally
                {
                    cn.Close();
                }
                return recordsAffected;
            }

        }
    }

