﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.Entity;
using MTBS.DAL;
using MTBS.Exception;
using System.Text.RegularExpressions;

namespace MTBS.BL
{
    public class ViewersRegistraionBL
    {
        ViewersRegistrationDAL dal = null;
        Viewers v = null;
        public ViewersRegistraionBL()
        {
            dal = new ViewersRegistrationDAL();
            v = new Viewers();
        }

        public static int ValidateUser(Viewers view)
        {
            int userValidated = 1;
            StringBuilder message = new StringBuilder();

            try
            {

                if (view.FirstName.Trim() == string.Empty)
                {
                    message.Append("Firstname should be provided\n");
                    userValidated = 0;
                }
                else if (!Regex.IsMatch(view.FirstName, "[A-Z][a-z]+"))
                {
                    message.Append("Firstname should start with capital alphabet and it should have alphabets only\n");
                    userValidated = 0;
                }
                if (view.LastName.Trim() == string.Empty)
                {
                    message.Append("LastName should be provided\n");
                    userValidated = 0;
                }

                if (view.MobileNumber.Trim() == string.Empty)
                {
                    message.Append("Phone number should be provided\n");
                    userValidated = 0;
                }
                else if (!Regex.IsMatch(view.MobileNumber, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 7 or 8 or 9 and it should have 10 digits\n");
                    userValidated = 0;
                }
                if (view.Email.Trim() == string.Empty)
                {
                    message.Append("Email Address should be provided\n");
                    userValidated = 0;
                }
                else if (!Regex.IsMatch(view.Email, @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"))
                {
                    message.Append("Enter a valid Email Address\n");
                    userValidated = 0;
                }

                if (view.Username.Trim() == string.Empty)
                {
                    message.Append("UserName should be provided\n");
                    userValidated = 0;
                }
                if (view.Password.Trim() == string.Empty)
                {
                    message.Append("Password should be provided\n");
                    userValidated = 0;
                }
              

                if (userValidated == 0)
                    throw new MtbsException(message.ToString());
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userValidated;
        }

        public List<Viewers> GetAll()
        {

            try
            {
                return dal.SelectAll();
            }
            catch (MtbsException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public int Insert(Viewers v)
        {
            int recordsAffected = 0;

            try
            {
                if(ValidateUser(v) == 1)
                {
                   recordsAffected = dal.Insert(v);
                }
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
        public int Update(Viewers v)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateUser(v) == 0)
                {
                    recordsAffected = dal.Update(v);
                }
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

    }
}
