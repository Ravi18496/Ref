﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.Exception;
using MTBS.Entity;
using MTBS.DAL;

namespace MTBS.BL
{
    public class BookTicketsBL
    {
        BookTicketsDAL dal = null;
        BookTickets b = null;
        public BookTicketsBL()
        {
            dal = new BookTicketsDAL();
            b = new BookTickets();
        }
        public List<BookTickets> GetAll()
        {
            try
            {
                return dal.SelectAll();
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
        public int Insert(BookTickets b)
        {
            try
            {
                return dal.Insert(b);
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
    }
}
