﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.DAL;
using MTBS.Entity;
using MTBS.Exception;

namespace MTBS.BL
{
    public class ManagingScreensBL
    {
        ManagingScreensDAL dal = null;
        Screens sc = null;

        public ManagingScreensBL()
        {
            dal = new ManagingScreensDAL();
            sc = new Screens();
        }

        public List<Screens> GetAll()
        {
            try
            {
                return dal.SelectAll();
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public int Insert(Screens sc1)
        {
            try
            {
                return dal.Insert(sc1);
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public int Delete(int screenId)
        {
            try
            {
                return dal.Delete(screenId);
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
        public int Update(Screens sc1)
        {
            try
            {
                return dal.Update(sc1);
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
    }


}
