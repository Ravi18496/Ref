﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTBS.Exception
{
    public class MtbsException : ApplicationException
    {
        //Default Constructor
        public MtbsException()
            : base()
        { }

        //Parameterized Constructor
        public MtbsException(string message)
            : base(message)
        { }
    }
}
