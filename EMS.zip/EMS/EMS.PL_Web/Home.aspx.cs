﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.Exception;
using EMS_BAL;

namespace EMS.PL_Web
{
    public partial class Home : System.Web.UI.Page
    {
        EmployeeValidation ebal = new EmployeeValidation();
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["user"] != null)
            //{
            //    lblWelcome.Text = "Welcome " + Session["user"].ToString();
            //    Master.Logout = true;
            //    Master.Menu = true;
            //}
            //else
            //{
            //    Response.Redirect("Login.aspx");
            //}

            try
            {
                List<Employee_Entity> studList = ebal.DisplayAll();

                if (studList.Count > 0)
                {
                    gvStudent.DataSource = studList;
                    gvStudent.DataBind();
                }
                else
                    throw new Employee_Exception("Student Details Not Available");
            }
            catch (Employee_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}