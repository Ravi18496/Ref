﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;
using System.Data.SqlClient;
using System.Configuration;

namespace EMS.DAL
{
    public class EmployeeOperations
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public EmployeeOperations()
        {
            string constr = ConfigurationManager.ConnectionStrings["con1"].ConnectionString;
            //string constr = @"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_13Dec17_Hinjawadi_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser";
            con = new SqlConnection(constr);
        }

        //Insert Employee
        public int InsertEmployee(Employee_Entity emp)
        {
            int recordsAffected = 0;
            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();
                //cmd.CommandText = "USP_InsertEmployee_142743v";
                cmd = new SqlCommand("USP_Insert_Joni", con);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@EmpId", emp.EmpId);
                cmd.Parameters.AddWithValue("@EmpName", emp.EmpName);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@DOJ", emp.DOJ);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);
                cmd.Parameters.AddWithValue("@DeptID", emp.DeptId);

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                
                
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(Employee_Exception ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            finally
            {
                
                con.Close();
            }
            return recordsAffected;
        }

        //Update Employee
        public int UpdateEmployee(Employee_Entity emp)
        {
            int recordsAffected = 0;
            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();
                //cmd.CommandText = "USP_UpdateEmployee_142743";

                cmd = new SqlCommand("USP_Update_Joni", con);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@EmpID", emp.EmpId);
                cmd.Parameters.AddWithValue("@EmpName", emp.EmpName);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@DOJ", emp.DOJ);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);
                cmd.Parameters.AddWithValue("@DeptID", emp.DeptId);

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                
                

            }
            catch(SqlException ex)
            {
                throw ex;

            }
            catch(Employee_Exception ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            finally
            {
               
                con.Close();
            }

            return recordsAffected;
        }

        //Delete Employee
        public int DeleteEmployee(int empid)
        {
            int recordsAffected = 0;

            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();
                //cmd.CommandText = "USP_DeleteEmployee_142743vj";

                cmd = new SqlCommand("USP_Delete_Joni", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpId",empid);
                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                //cmd.Connection.Close();
                


            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(Employee_Exception ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return recordsAffected;
        }

        //Display All
        public List<Employee_Entity> DisplayAll()
        {
            List<Employee_Entity> empList = new List<Employee_Entity>();
            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();
                //cmd.CommandText = "USP_SelectAllEmployee_142743v";

                cmd = new SqlCommand("USP_SelectALL_Joni", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                con.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows)
                    {
                        Employee_Entity emp = new Employee_Entity();
                        emp.EmpId = (int)dr["EmpId"];
                        emp.EmpName = dr["EmpName"].ToString();
                        emp.Gender = dr["Gender"].ToString();
                        emp.DOJ = Convert.ToDateTime(dr["DOJ"]);
                        emp.DeptId = (int)dr["DeptId"];
                        emp.Salary = (decimal)dr["Salary"];
                        empList.Add(emp);
                    }

                    else
                        throw new Employee_Exception("Records are not available");
                }
              

            }
            catch(Employee_Exception ex)
            {
                throw ex;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            finally
            {
                 dr.Close();
                 con.Close();
            }
            return empList;
        }

        //Total count
        public int TotalCountEmployee(Employee_Entity emp)
        {
            int count = 0;
            try
            {
                cmd = new SqlCommand("USP_TotalCount", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                count = (int)cmd.ExecuteScalar();

            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(Employee_Exception ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            finally
            {
                con.Close();
            }
            return count;
        }

        //Search Employee Method
        public Employee_Entity SearchEmployee(int empid)
        {
            Employee_Entity emp = null;
            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();
                //cmd.CommandText = "USP_SelectAllEmployee_142743v";

                cmd = new SqlCommand("USP_SearchEmployee_Joni", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@EmpId", empid);

                con.Open();
                dr = cmd.ExecuteReader();
                  if (dr.HasRows)
                    {
                        emp = new Employee_Entity();
                        dr.Read();
                        emp.EmpId = (int)dr["EmpId"];
                        emp.EmpName = dr["EmpName"].ToString();
                        emp.Gender = dr["Gender"].ToString();
                        emp.DOJ = Convert.ToDateTime(dr["DOJ"]);
                        emp.DeptId = (int)dr["DeptId"];
                        emp.Salary = (decimal)dr["Salary"];
                       
                    }

                    else
                        throw new Employee_Exception("Records are not available");
                


            }
            catch (Employee_Exception ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                con.Close();
            }
            return emp;
        }



    }
}
