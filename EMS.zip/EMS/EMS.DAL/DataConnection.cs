﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace EMS.DAL
{
    public class DataConnection
    {
        public SqlCommand GenerateCommand()
        {
            SqlCommand cmd = null;

            try
            {
                //Creating Connection Object
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con1"].ConnectionString);
                //Creating Command object
                cmd = new SqlCommand();

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return cmd;
        }
    }
}
