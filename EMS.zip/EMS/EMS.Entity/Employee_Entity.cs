﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    public class Employee_Entity
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public DateTime DOJ { get; set; }
        public string Gender { get; set; }
        public int DeptId { get; set; }
        public decimal Salary { get; set; }
    }
}
