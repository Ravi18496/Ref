﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EMS.Entity;
using EMS.Exception;
using EMS_BAL;

namespace EMS.PL
{
    public partial class Form1 : Form
    {
        List<Employee_Entity> allemp = null;
        Employee_Entity emp = null;
        EmployeeValidation empbl = new EmployeeValidation();
        //EmployeeValidation empbl = new EmployeeValidation();
        public Form1()
        {
            InitializeComponent();
        }

        //Insert Button Function
        private void btninsert_Click(object sender, EventArgs e)
        {
            int empInserted = 0;
            Employee_Entity emp = new Employee_Entity();
            try
            {
                int id = 0;
                //Convert.ToInt32(cbEmpId.Text);
                if (int.TryParse(cbEmpId.Text, out id)) { }

                string name = txtempname.Text;
                DateTime doj = Convert.ToDateTime(dtdoj.Text);

                decimal sal = 0;
                //Convert.ToDecimal(txtsalary.Text);
                if (decimal.TryParse(txtsalary.Text, out sal)) { }

                int depid = 0;
                //Convert.ToInt32(txtdeptid.Text);
                if (int.TryParse(txtdeptid.Text, out depid)) { }

                emp.DOJ = DateTime.Parse(dtdoj.Text);

                //var buttons = this.Controls.OfType<RadioButton>().FirstOrDefault(n => n.Checked);
                //if (buttons == rbtnMale)
                //{
                //    emp.Gender = "Male";
                //}
                //else if(buttons == rbtnFemale)
                //{
                //    emp.Gender = "Female";
                //}

                if (rbtnFemale.Checked == true)
                    emp.Gender = "Female";
                else emp.Gender = "Male";

                emp.EmpId = id;
                emp.EmpName = name;
                //emp.DOJ = doj;
                emp.Salary = sal;
                emp.DeptId = depid;

                empInserted = empbl.InsertEmployee(emp);
                if (empInserted > 0)
                {
                    MessageBox.Show("Employee Sucessfully Inserted");
                }
                else
                {
                    throw new Employee_Exception("Employee Details are not inserted");
                }
                
                
            }
            catch(Employee_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            PopulateUI(allemp);

        }

        //button to Count method
        private void btntotcount_Click(object sender, EventArgs e)
        {
            //Employee_Entity emp = new Employee_Entity();
            //MessageBox.Show(allemp.Count.ToString());

            int countEmployee = 0;
            Employee_Entity emp = new Employee_Entity();
            try
            {
                countEmployee = empbl.TotalCount(emp);

                if(countEmployee>0)
                {
                    MessageBox.Show("Total Employee records are : " + countEmployee);
                }
                else
                {
                    MessageBox.Show("Total Employee Records are : " + countEmployee);
                }

            }
            catch(Employee_Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Form 1 method
        private void Form1_Load(object sender, EventArgs e)
        {
            //EmployeeValidation empbl = new EmployeeValidation();
            //allemp = empbl.DisplayAll();
            //PopulateUI(allemp);

        }

        //Populate ui method
        private void PopulateUI(List<Employee_Entity> allemp)
        {
            allemp = empbl.DisplayAll();
            dgemp.DataSource = allemp;
            cbEmpId.DataSource = allemp;
            cbEmpId.DisplayMember = "EmpId";
        }

        // Population using txt box
        private void txtempid_TextChanged(object sender, EventArgs e)
        {
           allemp = empbl.DisplayAll();
            try
            {
                int id = int.Parse(txtempid.Text);
                foreach (var item in allemp)
                {
                    if (id == item.EmpId)
                    {
                        txtempname.Text = item.EmpName;
                        if (item.Gender == "Male")
                        {
                            rbtnMale.Checked = true;
                        }
                        else if (item.Gender == "Female")
                        {
                            rbtnFemale.Checked = true;
                        }
                        dtdoj.Text = Convert.ToString(item.DOJ);
                        txtdeptid.Text = Convert.ToString(item.DeptId);
                        txtsalary.Text = Convert.ToString(item.Salary);
                        break;
                    }

                }
            }
            catch(Employee_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Population using Combo box
        private void cbEmpID_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<Employee_Entity> empList = empbl.DisplayAll();
            try
            {
                int id = 0;
                //int.Parse(cbEmpId.Text);
                if (int.TryParse(cbEmpId.Text, out id)) { }
                foreach (var item in empList)
                {
                    if (id == item.EmpId)
                    {
                        txtempname.Text = item.EmpName;
                        if (item.Gender == "Male")
                        {
                            rbtnMale.Checked = true;
                        }
                        else if (item.Gender == "Female")
                        {
                            rbtnFemale.Checked = true;
                        }
                        dtdoj.Text = Convert.ToString(item.DOJ);
                        txtdeptid.Text = Convert.ToString(item.DeptId);
                        txtsalary.Text = Convert.ToString(item.Salary);
                        break;
                    }

                }
            }

            catch(Employee_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Delete button function
        private void btndelete_Click(object sender, EventArgs e)
        {
            int empDeleted = 0;
            try
            {
                int id = 0;
                    //Convert.ToInt32(cbEmpId.Text);
                //empbl.DeleteEmployee(id);
                if (int.TryParse(cbEmpId.Text, out id)) { }

                if(id<=0)
                {
                    throw new Employee_Exception("**Please provide valid Employee Id to delete His/Her Employee records**");
                }
                

                empDeleted = empbl.DeleteEmployee(id);

                if (empDeleted > 0)
                {
                    MessageBox.Show("Employee Details are Successfully Deleted");
                    PopulateUI(allemp);
                }
                else
                {
                    throw new Employee_Exception("Employee Details are not Available in the records");
                }
                
            }

            catch(Employee_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }


        //Update button function
        private void btnupdate_Click(object sender, EventArgs e)
        {
            int empUpdated = 0;
            Employee_Entity emp = new Employee_Entity();
            try
            {

                int id = 0;
                //Convert.ToInt32(cbEmpId.Text);
                if (int.TryParse(cbEmpId.Text, out id)) { }

                string name = txtempname.Text;
                DateTime doj = Convert.ToDateTime(dtdoj.Text);

                decimal sal = 0;
                //Convert.ToDecimal(txtsalary.Text);
                if (decimal.TryParse(txtsalary.Text, out sal)) { }

                int depid = 0;
                //Convert.ToInt32(txtdeptid.Text);
                if (int.TryParse(txtdeptid.Text, out depid)) { }

                emp.DOJ = DateTime.Parse(dtdoj.Text);

               

                if (rbtnFemale.Checked == true)
                    emp.Gender = "Female";
                else emp.Gender = "Male";

                emp.EmpId = id;
                emp.EmpName = name;
                //emp.DOJ = doj;
                emp.Salary = sal;
                emp.DeptId = depid;

                empUpdated = empbl.UpdateEmployee(emp);
                if (empUpdated > 0)
                {
                    MessageBox.Show("Employee Details are successfully Updated");
                    PopulateUI(allemp);
                }
                else
                {
                    throw new Employee_Exception("Employee Details are not Updated");
                }
             
            }
            catch (Employee_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }

        //Button Show All
        private void btnShowAll_Click(object sender, EventArgs e)
        {
            //int empShow = 0;
            //Employee_Entity emp = new Employee_Entity();
            try
            {
                allemp = empbl.DisplayAll();
                PopulateUI(allemp);

            }
            catch(Employee_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Search Click

        private void btnSearch_Click(object sender, EventArgs e)
        {
            emp = new Employee_Entity();
            try
            {
                int id = 0;
                if (int.TryParse(cbEmpId.Text, out id)) { }

                if(id<=0)
                {
                    throw new Employee_Exception("**Plese provide valid Employee Id to search His/Her Employee Details**");
                }

                 emp = empbl.SearchEmployee(id);
                dgemp.DataSource = emp;

            }
            catch(Employee_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }

        





    }
}
