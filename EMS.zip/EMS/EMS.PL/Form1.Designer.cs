﻿namespace EMS.PL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btndisp = new System.Windows.Forms.Button();
            this.txtempname = new System.Windows.Forms.TextBox();
            this.btntotcount = new System.Windows.Forms.Button();
            this.dgemp = new System.Windows.Forms.DataGridView();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btninsert = new System.Windows.Forms.Button();
            this.txtsalary = new System.Windows.Forms.TextBox();
            this.lbdeptid1 = new System.Windows.Forms.ListBox();
            this.dtdoj = new System.Windows.Forms.DateTimePicker();
            this.lbEmpID1 = new System.Windows.Forms.ListBox();
            this.rbtnFemale = new System.Windows.Forms.RadioButton();
            this.rbtnMale = new System.Windows.Forms.RadioButton();
            this.lbldeptid = new System.Windows.Forms.Label();
            this.lblsalary = new System.Windows.Forms.Label();
            this.lbldoj = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblempname = new System.Windows.Forms.Label();
            this.lblempid = new System.Windows.Forms.Label();
            this.txtempid = new System.Windows.Forms.TextBox();
            this.txtdeptid = new System.Windows.Forms.TextBox();
            this.cbEmpId = new System.Windows.Forms.ComboBox();
            this.btnShowAll = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgemp)).BeginInit();
            this.SuspendLayout();
            // 
            // btndisp
            // 
            this.btndisp.Location = new System.Drawing.Point(736, 1);
            this.btndisp.Margin = new System.Windows.Forms.Padding(2);
            this.btndisp.Name = "btndisp";
            this.btndisp.Size = new System.Drawing.Size(56, 27);
            this.btndisp.TabIndex = 39;
            this.btndisp.Text = "Btn";
            this.btndisp.UseVisualStyleBackColor = true;
            // 
            // txtempname
            // 
            this.txtempname.Location = new System.Drawing.Point(213, 91);
            this.txtempname.Margin = new System.Windows.Forms.Padding(2);
            this.txtempname.Name = "txtempname";
            this.txtempname.Size = new System.Drawing.Size(107, 20);
            this.txtempname.TabIndex = 38;
            // 
            // btntotcount
            // 
            this.btntotcount.Location = new System.Drawing.Point(766, 255);
            this.btntotcount.Margin = new System.Windows.Forms.Padding(2);
            this.btntotcount.Name = "btntotcount";
            this.btntotcount.Size = new System.Drawing.Size(124, 28);
            this.btntotcount.TabIndex = 37;
            this.btntotcount.Text = "Total Employee Count";
            this.btntotcount.UseVisualStyleBackColor = true;
            this.btntotcount.Click += new System.EventHandler(this.btntotcount_Click);
            // 
            // dgemp
            // 
            this.dgemp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgemp.Location = new System.Drawing.Point(369, 54);
            this.dgemp.Margin = new System.Windows.Forms.Padding(2);
            this.dgemp.Name = "dgemp";
            this.dgemp.RowTemplate.Height = 24;
            this.dgemp.Size = new System.Drawing.Size(521, 179);
            this.dgemp.TabIndex = 36;
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(347, 256);
            this.btnupdate.Margin = new System.Windows.Forms.Padding(2);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(56, 27);
            this.btnupdate.TabIndex = 35;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(236, 255);
            this.btndelete.Margin = new System.Windows.Forms.Padding(2);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(56, 27);
            this.btndelete.TabIndex = 34;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btninsert
            // 
            this.btninsert.Location = new System.Drawing.Point(96, 256);
            this.btninsert.Margin = new System.Windows.Forms.Padding(2);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(56, 27);
            this.btninsert.TabIndex = 33;
            this.btninsert.Text = "Insert";
            this.btninsert.UseVisualStyleBackColor = true;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // txtsalary
            // 
            this.txtsalary.Location = new System.Drawing.Point(213, 187);
            this.txtsalary.Margin = new System.Windows.Forms.Padding(2);
            this.txtsalary.Name = "txtsalary";
            this.txtsalary.Size = new System.Drawing.Size(111, 20);
            this.txtsalary.TabIndex = 32;
            // 
            // lbdeptid1
            // 
            this.lbdeptid1.FormattingEnabled = true;
            this.lbdeptid1.Location = new System.Drawing.Point(601, 1);
            this.lbdeptid1.Margin = new System.Windows.Forms.Padding(2);
            this.lbdeptid1.Name = "lbdeptid1";
            this.lbdeptid1.Size = new System.Drawing.Size(111, 17);
            this.lbdeptid1.TabIndex = 31;
            // 
            // dtdoj
            // 
            this.dtdoj.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtdoj.Location = new System.Drawing.Point(213, 159);
            this.dtdoj.Margin = new System.Windows.Forms.Padding(2);
            this.dtdoj.Name = "dtdoj";
            this.dtdoj.Size = new System.Drawing.Size(111, 20);
            this.dtdoj.TabIndex = 30;
            // 
            // lbEmpID1
            // 
            this.lbEmpID1.FormattingEnabled = true;
            this.lbEmpID1.Location = new System.Drawing.Point(467, 1);
            this.lbEmpID1.Margin = new System.Windows.Forms.Padding(2);
            this.lbEmpID1.Name = "lbEmpID1";
            this.lbEmpID1.Size = new System.Drawing.Size(107, 17);
            this.lbEmpID1.TabIndex = 29;
            // 
            // rbtnFemale
            // 
            this.rbtnFemale.AutoSize = true;
            this.rbtnFemale.Location = new System.Drawing.Point(265, 128);
            this.rbtnFemale.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnFemale.Name = "rbtnFemale";
            this.rbtnFemale.Size = new System.Drawing.Size(59, 17);
            this.rbtnFemale.TabIndex = 28;
            this.rbtnFemale.TabStop = true;
            this.rbtnFemale.Text = "Female";
            this.rbtnFemale.UseVisualStyleBackColor = true;
            // 
            // rbtnMale
            // 
            this.rbtnMale.AutoSize = true;
            this.rbtnMale.Location = new System.Drawing.Point(213, 128);
            this.rbtnMale.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnMale.Name = "rbtnMale";
            this.rbtnMale.Size = new System.Drawing.Size(48, 17);
            this.rbtnMale.TabIndex = 27;
            this.rbtnMale.TabStop = true;
            this.rbtnMale.Text = "Male";
            this.rbtnMale.UseVisualStyleBackColor = true;
            // 
            // lbldeptid
            // 
            this.lbldeptid.AutoSize = true;
            this.lbldeptid.Location = new System.Drawing.Point(93, 216);
            this.lbldeptid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldeptid.Name = "lbldeptid";
            this.lbldeptid.Size = new System.Drawing.Size(44, 13);
            this.lbldeptid.TabIndex = 26;
            this.lbldeptid.Text = "Dept ID";
            // 
            // lblsalary
            // 
            this.lblsalary.AutoSize = true;
            this.lblsalary.Location = new System.Drawing.Point(93, 187);
            this.lblsalary.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblsalary.Name = "lblsalary";
            this.lblsalary.Size = new System.Drawing.Size(36, 13);
            this.lblsalary.TabIndex = 25;
            this.lblsalary.Text = "Salary";
            // 
            // lbldoj
            // 
            this.lbldoj.AutoSize = true;
            this.lbldoj.Location = new System.Drawing.Point(93, 159);
            this.lbldoj.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbldoj.Name = "lbldoj";
            this.lbldoj.Size = new System.Drawing.Size(34, 13);
            this.lbldoj.TabIndex = 24;
            this.lbldoj.Text = "D.O.J";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(93, 132);
            this.lblgender.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(42, 13);
            this.lblgender.TabIndex = 23;
            this.lblgender.Text = "Gender";
            // 
            // lblempname
            // 
            this.lblempname.AutoSize = true;
            this.lblempname.Location = new System.Drawing.Point(93, 96);
            this.lblempname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblempname.Name = "lblempname";
            this.lblempname.Size = new System.Drawing.Size(59, 13);
            this.lblempname.TabIndex = 22;
            this.lblempname.Text = "Emp Name";
            // 
            // lblempid
            // 
            this.lblempid.AutoSize = true;
            this.lblempid.Location = new System.Drawing.Point(93, 61);
            this.lblempid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblempid.Name = "lblempid";
            this.lblempid.Size = new System.Drawing.Size(67, 13);
            this.lblempid.TabIndex = 21;
            this.lblempid.Text = "Employee ID";
            // 
            // txtempid
            // 
            this.txtempid.Location = new System.Drawing.Point(313, 8);
            this.txtempid.Name = "txtempid";
            this.txtempid.Size = new System.Drawing.Size(111, 20);
            this.txtempid.TabIndex = 40;
            this.txtempid.TextChanged += new System.EventHandler(this.txtempid_TextChanged);
            // 
            // txtdeptid
            // 
            this.txtdeptid.Location = new System.Drawing.Point(213, 213);
            this.txtdeptid.Name = "txtdeptid";
            this.txtdeptid.Size = new System.Drawing.Size(111, 20);
            this.txtdeptid.TabIndex = 41;
            // 
            // cbEmpId
            // 
            this.cbEmpId.FormattingEnabled = true;
            this.cbEmpId.Location = new System.Drawing.Point(213, 54);
            this.cbEmpId.Name = "cbEmpId";
            this.cbEmpId.Size = new System.Drawing.Size(111, 21);
            this.cbEmpId.TabIndex = 42;
            this.cbEmpId.SelectedIndexChanged += new System.EventHandler(this.cbEmpID_SelectedIndexChanged);
            // 
            // btnShowAll
            // 
            this.btnShowAll.Location = new System.Drawing.Point(467, 260);
            this.btnShowAll.Name = "btnShowAll";
            this.btnShowAll.Size = new System.Drawing.Size(75, 23);
            this.btnShowAll.TabIndex = 43;
            this.btnShowAll.Text = "ShowAll";
            this.btnShowAll.UseVisualStyleBackColor = true;
            this.btnShowAll.Click += new System.EventHandler(this.btnShowAll_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(617, 258);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 44;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(901, 337);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnShowAll);
            this.Controls.Add(this.cbEmpId);
            this.Controls.Add(this.txtdeptid);
            this.Controls.Add(this.txtempid);
            this.Controls.Add(this.btndisp);
            this.Controls.Add(this.txtempname);
            this.Controls.Add(this.btntotcount);
            this.Controls.Add(this.dgemp);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btninsert);
            this.Controls.Add(this.txtsalary);
            this.Controls.Add(this.lbdeptid1);
            this.Controls.Add(this.dtdoj);
            this.Controls.Add(this.lbEmpID1);
            this.Controls.Add(this.rbtnFemale);
            this.Controls.Add(this.rbtnMale);
            this.Controls.Add(this.lbldeptid);
            this.Controls.Add(this.lblsalary);
            this.Controls.Add(this.lbldoj);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.lblempname);
            this.Controls.Add(this.lblempid);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgemp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btndisp;
        private System.Windows.Forms.TextBox txtempname;
        private System.Windows.Forms.Button btntotcount;
        private System.Windows.Forms.DataGridView dgemp;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btninsert;
        private System.Windows.Forms.TextBox txtsalary;
        private System.Windows.Forms.ListBox lbdeptid1;
        private System.Windows.Forms.DateTimePicker dtdoj;
        private System.Windows.Forms.ListBox lbEmpID1;
        private System.Windows.Forms.RadioButton rbtnFemale;
        private System.Windows.Forms.RadioButton rbtnMale;
        private System.Windows.Forms.Label lbldeptid;
        private System.Windows.Forms.Label lblsalary;
        private System.Windows.Forms.Label lbldoj;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lblempname;
        private System.Windows.Forms.Label lblempid;
        private System.Windows.Forms.TextBox txtempid;
        private System.Windows.Forms.TextBox txtdeptid;
        private System.Windows.Forms.ComboBox cbEmpId;
        private System.Windows.Forms.Button btnShowAll;
        private System.Windows.Forms.Button btnSearch;
    }
}

