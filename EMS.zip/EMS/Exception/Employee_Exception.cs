﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exception
{
    public class Employee_Exception : ApplicationException
    {
        public Employee_Exception()
            :base()
        { }

        public Employee_Exception(string message)
            :base(message)
        { }
    }
}
