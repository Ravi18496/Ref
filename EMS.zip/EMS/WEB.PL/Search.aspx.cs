﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.Exception;
using EMS_BAL;

namespace WEB.PL
{
    public partial class Search : System.Web.UI.Page
    {
        EmployeeValidation ebal = null;
        Employee_Entity emp = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                //lblWelcome.Text = "Welcome " + Session["user"].ToString();
                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

            ebal = new EmployeeValidation();
            emp = new Employee_Entity();
            List<Employee_Entity> empList = new List<Employee_Entity>();
            empList = ebal.DisplayAll();
            if (!IsPostBack)
            {
                ddlEmpId.DataSource = empList;
                ddlEmpId.DataValueField = "EmpId";
                ddlEmpId.DataBind();
            }
        }

        //PAL layer Method to Search Employee Records
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            int id = 0;
            id = int.Parse(ddlEmpId.SelectedItem.ToString());
            try
            {
                
                txtEmpName.Text = "";
                txtDOJ.Text = "";
                txtDeptCode.Text = "";
                txtSalary.Text = "";
                rbFemale.Checked = false;
                rbMale.Checked = false;
                btnDelete.Enabled = false;
                btnUpdate.Enabled = false;
                emp = ebal.SearchEmployee(id);
                if ( emp.EmpId > 0)
                {
                    txtEmpName.Text = emp.EmpName;
                    txtEmpName.DataBind();
                    txtDOJ.Text = emp.DOJ.ToString("MM/dd/yyyy");
                    txtDOJ.DataBind();
                    int salary = 0;
                    salary = Convert.ToInt32(emp.Salary);
                    txtSalary.Text = salary.ToString();
                    txtSalary.DataBind();
                    txtDeptCode.Text = emp.DeptId.ToString();
                    if (emp.Gender == "Female")
                    {
                        rbFemale.Checked = true;
                        rbFemale.DataBind();
                    }
                    else
                    {
                        rbMale.Checked = true;
                        rbMale.DataBind();
                    }
                    btnDelete.Enabled = true;
                    btnUpdate.Enabled = true;
                    
                }


            }
            catch (Employee_Exception ex)
            {
                //lblError.Text = ex.Message;
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                //lblError.Text = ex.Message;
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        //PAL Layer Method to Update Employee Records
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                int id = 0;
                //if (int.TryParse(txtEmpId.Text, out id)) { }
                id = int.Parse(ddlEmpId.SelectedItem.ToString());

                emp.EmpId = id;
                emp.EmpName = txtEmpName.Text;
                emp.DOJ = Convert.ToDateTime(txtDOJ.Text);
                decimal sid = 0;
                if (decimal.TryParse(txtSalary.Text, out sid)) { }
                emp.Salary = sid;
                int did = 0;
                if (int.TryParse(txtDeptCode.Text, out did)) { }
                emp.DeptId = did;
                if (rbFemale.Checked == true)
                {
                    emp.Gender = rbFemale.Text;
                }
                else
                    emp.Gender = rbMale.Text;
                recordsAffected = ebal.UpdateEmployee(emp);
                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Employee Details are Successfully Updated');</script>");
                    txtEmpName.Text = "";
                    txtDOJ.Text = "";
                    txtDeptCode.Text = "";
                    txtSalary.Text = "";
                    rbFemale.Checked = false;
                    rbMale.Checked = false;
                    
                }
                else
                    throw new Employee_Exception("<script>alert('Please Provide Valid EmpId to update His/Her Employee Records.');</script>");

            }
            catch (Employee_Exception ex)
            {
                lblError.Text = ex.Message;
                Response.Write("<script>alert('" + lblError.Text + "')</script>");


            }
            catch (SystemException ex)
            {
                lblError.Text = ex.Message;
                Response.Write("<script>alert('" + lblError.Text + " ')</script>");
            }
        }

        //PL layer Method to delete Employee record
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

                int id = 0;
                //if (int.TryParse(txtEmpId.Text, out id)) { }
                id = int.Parse(ddlEmpId.SelectedItem.ToString());
                int recordsAffected = ebal.DeleteEmployee(id);
                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Employee Details are Successfully Deleted');</script>");
                    txtEmpName.Text = "";
                    txtDOJ.Text = "";
                    txtDeptCode.Text = "";
                    txtSalary.Text = "";
                    rbFemale.Checked = false;
                    rbMale.Checked = false;
                }
                else
                    throw new Employee_Exception("<script>alert('Employee Details Records are not Available');</script>");


            }
            catch(Employee_Exception ex)
            {
                lblError.Text = ex.Message;
                Response.Write("<script>alert('" + lblError.Text + "')</script>");
            }
            catch(SystemException ex)
            {
                lblError.Text = ex.Message;
                Response.Write("<script>alert('" + lblError.Text + "')</script>");
            }
            

        }

        protected void ddlEmpId_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtEmpName.Text = "";
            txtDOJ.Text = "";
            txtDeptCode.Text = "";
            txtSalary.Text = "";
            rbFemale.Checked = false;
            rbMale.Checked = false;
        }
    }
}