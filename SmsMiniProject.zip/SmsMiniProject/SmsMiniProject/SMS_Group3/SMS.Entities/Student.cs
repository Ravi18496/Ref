﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entities
{
    /// <summary>
    /// This class is for Student Entity
    /// </summary>
    public class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public string Gender { get; set; }
        public DateTime DOB { get; set; }
        public string BloodGroup { get; set; }
        public string Contact { get; set; }
        public string Student_address { get; set; }

    }
}
