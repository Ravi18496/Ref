﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entities
{
    /// <summary>
    /// This class is for Fees Entity
    /// </summary>
    public class Fees
    {
        public int InvoiceID { get; set; }
        public DateTime Payment_Date { get; set; }
        public int StudentID { get; set; }
        public int Fees_amount { get; set; }
    }
}
