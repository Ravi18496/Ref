﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entities
{
    /// <summary>
    /// This class is for Attendence Entity
    /// </summary>
    public class Attendence
    {
        public int AttendenceID { get; set; }
        public int StudentID { get; set; }
        public DateTime Today_Date { get; set; }
        public char Attended { get; set; }
    }
}
