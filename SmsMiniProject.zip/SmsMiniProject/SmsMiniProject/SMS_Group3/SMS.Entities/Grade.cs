﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entities
{
    /// <summary>
    /// This class is for Grade Entity
    /// </summary>
    public class Grade
    {
       
        public int ClassID { get; set; }
        public string GradeName { get; set; }
        public string Description_Grade { get; set; }
        public int Marks1 { get; set; }
        public int Marks2 { get; set; }
        public int Marks3 { get; set; }
        public int StudentID { get; set; }
        public int TeacherID { get; set; }
    }
}
