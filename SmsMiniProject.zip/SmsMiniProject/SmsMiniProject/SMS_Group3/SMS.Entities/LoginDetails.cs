﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entities
{
    public class LoginDetails
    {
        //Admin login properties
        public string UserAdmin { get; set; }
        public string PassAdmin { get; set; }

        //Teacher login properties
        public int TeacherID { get; set; }
        public string UserTeacher { get; set; }
        public string PassTeacher { get; set; }

        //Student login properties
        public int StudentId { get; set; }
        public string UserStudent { get; set; }
        public string PassStudent { get; set; }

        //Cashier login properties
        public string UserCashier { get; set; }
        public string PassCashier { get; set; }

    }
}
