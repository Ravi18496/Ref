﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exceptions
{
    /// <summary>
    /// This class is for Student Exception
    /// </summary>
    public class Student_Exception : ApplicationException
    {
        //System Exception
        public Student_Exception()
            : base()
        { }

        //User Defined Exception
        public Student_Exception(string message)
            : base(message)
        { }

    }
}
