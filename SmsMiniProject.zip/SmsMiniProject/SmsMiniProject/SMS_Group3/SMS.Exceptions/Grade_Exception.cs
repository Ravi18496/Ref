﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exceptions
{
    /// <summary>
    /// This class is for Grade Exception
    /// </summary>
    public class Grade_Exception : ApplicationException
    {
        //System Exception
        public Grade_Exception()
            : base()
        { }

        //User Defined Exception
        public Grade_Exception(string message)
            : base(message)
        { }
    }
}
