﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exceptions
{
    /// <summary>
    /// This class is for Fees Exception
    /// </summary>
    public class Fees_Exception : ApplicationException
    {
        //System Exception
        public Fees_Exception()
            : base()
        { }

        //User Defined Exception
        public Fees_Exception(string message)
            : base(message)
        { }
    }
}
