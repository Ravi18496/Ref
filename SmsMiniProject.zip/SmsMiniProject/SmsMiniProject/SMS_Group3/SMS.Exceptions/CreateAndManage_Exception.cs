﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exceptions
{
    public class CreateAndManage_Exception : ApplicationException
    {
        public CreateAndManage_Exception() : base()
        {
                
        }
        public CreateAndManage_Exception(string message) :base(message)
        {

        }
    }
}
