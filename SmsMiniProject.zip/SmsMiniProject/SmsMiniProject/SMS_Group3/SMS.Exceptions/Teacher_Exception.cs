﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exceptions
{
    /// <summary>
    /// This class is for Teacher Exception
    /// </summary>
    public class Teacher_Exception : ApplicationException
    {
        //System Exception
        public Teacher_Exception()
            : base()
        { }

        //User Defined Exception
        public Teacher_Exception(string message)
            : base(message)
        { }
    }
}
