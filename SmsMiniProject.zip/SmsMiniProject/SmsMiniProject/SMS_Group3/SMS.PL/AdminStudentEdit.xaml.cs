﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for AdminStudentEdit.xaml
    /// </summary>
    public partial class AdminStudentEdit : Window
    {
        List<Student> studList = null;
        Studnet_BAL sbal = null;
        public AdminStudentEdit()
        {
            InitializeComponent();
            sbal = new Studnet_BAL();
        }

        //Button Method To Insert Student Record
        private void btnStudentInsert_Click(object sender, RoutedEventArgs e)
        {
            int studentInserted = 0;
            Student stud = new Student();
            try
            {
                int id = 0;

                if (int.TryParse(txtStudentID.Text, out id)) { }
                stud.StudentID = id;
                stud.StudentName = txtStudentName.Text;
                stud.DOB = Convert.ToDateTime(dpStudentDOB.Text);
                if (rbtnStudentFemale.IsChecked == true)
                    stud.Gender = "Female";
                else stud.Gender = "Male";
                stud.Contact = txtStudentContact.Text;
                stud.BloodGroup = cbStudentBG.Text;
                stud.Student_address = new TextRange(rtxtStudentAddress.Document.ContentStart, rtxtStudentAddress.Document.ContentEnd).Text;

                studentInserted = sbal.InsertStudent(stud);
                if (studentInserted > 0)
                {
                    MessageBox.Show("Student Details Sucessfully Inserted");
                }
                else
                {
                    throw new Student_Exception("Student Details are not inserted");
                }


            }
            catch (Student_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            PopulateUI(studList);
        }

        //Method to Populate The Data in the GridView
        private void PopulateUI(List<Student> studList)
        {
            studList = sbal.DisplayStudent();
            dgvStudentData.ItemsSource = studList;
        }

        //Button Method To Display All
        private void btnStudentDisplay_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                studList = sbal.DisplayStudent();
                PopulateUI(studList);
            }
            catch (Student_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Button Method to Update Student Record
        private void btnStudentUpdate_Click(object sender, RoutedEventArgs e)
        {
            int studentUpdated = 0;
            Student stud = new Student();
            try
            {
                int id = 0;

                if (int.TryParse(txtStudentID.Text, out id)) { }
                stud.StudentID = id;
                stud.StudentName = txtStudentName.Text;
                stud.DOB = Convert.ToDateTime(dpStudentDOB.Text);
                if (rbtnStudentFemale.IsChecked == true)
                    stud.Gender = "Female";
                else stud.Gender = "Male";
                stud.Contact = txtStudentContact.Text;
                stud.BloodGroup = cbStudentBG.Text;
                stud.Student_address = new TextRange(rtxtStudentAddress.Document.ContentStart, rtxtStudentAddress.Document.ContentEnd).Text;

                studentUpdated = sbal.UpdateStudent(stud);
                if (studentUpdated > 0)
                {
                    MessageBox.Show("Student Details Sucessfully Updated");
                }
                else
                {
                    throw new Student_Exception("Student Details are not Updated");
                }


            }
            catch (Student_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            PopulateUI(studList);
        }

        //Button Method to Delete Student Record
        private void btnStudentDelete_Click(object sender, RoutedEventArgs e)
        {
            int studDeleted = 0;
            try
            {
                int id = 0;
                if (int.TryParse(txtStudentID.Text, out id)) { }

                if (id <= 0)
                {
                    throw new Student_Exception("**Please provide valid Student Id to delete His/Her Student records**");
                }

                studDeleted = sbal.DeleteStudent(id);
                if (studDeleted > 0)
                {
                    MessageBox.Show("Student Details are Successfully Deleted");
                    PopulateUI(studList);
                }
                else
                {
                    throw new Student_Exception("Student Details are not Available in the records");
                }

            }

            catch (Student_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Button Method to Search Student Record
        private void btnStudentSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = 0;
                if (int.TryParse(txtStudentID.Text, out id)) { }

                if (id <= 0)
                {
                    throw new Student_Exception("**Plese provide valid Student Id to search His/Her Student Details**");
                }

                studList = sbal.SearchStudent(id);
                dgvStudentData.ItemsSource = studList;

            }
            catch (Student_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Button Method to Get the Total Count of Student Records
        private void btnStudentCount_Click(object sender, RoutedEventArgs e)
        {
            int countStudent = 0;
            Student stud = new Student();
            try
            {
                countStudent = sbal.TotalCountStudent(stud);

                if (countStudent > 0)
                {
                    MessageBox.Show("Total Student records are : " + countStudent);
                }
                else
                {
                    MessageBox.Show("Total Student Records are : " + countStudent);
                }

            }
            catch (Student_Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        



        
    }
}
