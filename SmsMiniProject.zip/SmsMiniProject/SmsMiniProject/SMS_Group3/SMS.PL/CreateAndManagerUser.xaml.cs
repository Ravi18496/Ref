﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;
using System.Collections;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for CreateAndManagerUser.xaml
    /// </summary>
    public partial class CreateAndManagerUser : Window
    {
        LoginDetails ld = null;
        CreateAndManage_BAL cbal = null;
        Teacher_BAL tbal = null;
        Studnet_BAL sbal = null;
        List<Teacher> ldList = null;
        List<Student> sdList = null;
        ArrayList al = new ArrayList();
        List<TeacherLogin> teacherList = null;
        List<StudentLogin> studentList = null;

        public CreateAndManagerUser()
        {
            InitializeComponent();
            ld = new LoginDetails();
            cbal = new CreateAndManage_BAL();
            tbal = new Teacher_BAL();
            teacherList = new List<TeacherLogin>();
            sbal = new Studnet_BAL();
            sdList = new List<Student>();
            btnInsert.Visibility = System.Windows.Visibility.Hidden;
            btnDelete.Visibility = System.Windows.Visibility.Hidden;
            btnUpdate.Visibility = System.Windows.Visibility.Hidden;
            btnInsertStudent.Visibility = System.Windows.Visibility.Hidden;
            btnUpdateStudent.Visibility = System.Windows.Visibility.Hidden;
            btnDeleteStudent.Visibility = System.Windows.Visibility.Hidden;
            btnStudent.Visibility = System.Windows.Visibility.Hidden;
            btnTeacher.Visibility = System.Windows.Visibility.Hidden;
            
        
        }

        //Insert teacher
        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                int id = 0;
                id = Convert.ToInt32(cbId.SelectedItem);
                ld.TeacherID = id;
                ld.UserTeacher = lblName.Content.ToString();
                ld.PassTeacher = txtPassword.Text;
                recordsAffected = cbal.InsertTeacherLogin(ld);
                if (recordsAffected > 0)
                {
                    MessageBox.Show("Login Details successfully inserted");
                }
                else
                    MessageBox.Show("Login details are not inserted");
            }
            catch(CreateAndManage_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            PopulateUI(teacherList);

            

        }

        //Populating the data
        private void PopulateUI(List<TeacherLogin> teacherList)
        {
            teacherList = cbal.DisplayTeacherLogin();
            dgData.ItemsSource = teacherList;
        }

        private void cbSelect_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cbId.ItemsSource = null;
            int select = cbSelect.SelectedIndex;

            //ldList = new List<Teacher>();
            //ldList = tbal.DisplayTeacher();
                

            //sdList = new List<Student>();
            //sdList = sbal.DisplayStudent();

            
            if (select == 0)
            {
               
                ldList = new List<Teacher>();
                ldList = tbal.DisplayTeacher();
                al.Clear();
                foreach (var item in ldList)
                {
                   
                    al.Add(item.TeacherID);
                }
                
                cbId.ItemsSource = al;
                btnStudent.Visibility = System.Windows.Visibility.Hidden;
                btnInsertStudent.Visibility = System.Windows.Visibility.Hidden;
                btnUpdateStudent.Visibility = System.Windows.Visibility.Hidden;
                btnDeleteStudent.Visibility = System.Windows.Visibility.Hidden;
                btnInsert.Visibility = System.Windows.Visibility.Visible;
                btnDelete.Visibility = System.Windows.Visibility.Visible;
                btnUpdate.Visibility = System.Windows.Visibility.Visible;
                btnTeacher.Visibility = System.Windows.Visibility.Visible;
               
              
            }
            if(select == 1)
            {
                sdList = new List<Student>();
                sdList = sbal.DisplayStudent();
                al.Clear();
                foreach (var item in sdList)
                {
                    
                    al.Add(item.StudentID);
                }
                
                cbId.ItemsSource = al;
                btnInsert.Visibility = System.Windows.Visibility.Hidden;
                btnDelete.Visibility = System.Windows.Visibility.Hidden;
                btnUpdate.Visibility = System.Windows.Visibility.Hidden;
                btnTeacher.Visibility = System.Windows.Visibility.Hidden;
                btnInsertStudent.Visibility = System.Windows.Visibility.Visible;
                btnUpdateStudent.Visibility = System.Windows.Visibility.Visible;
                btnDeleteStudent.Visibility = System.Windows.Visibility.Visible;
                btnStudent.Visibility = System.Windows.Visibility.Visible;

            }
        }

        private void cbId_SelectionChanged(object sender, SelectionChangedEventArgs e)
            {
                
            int id = 0;

            lblName.Content = "";
            id = Convert.ToInt32(cbId.SelectedItem);
            
            ldList = new List<Teacher>();
            ldList = tbal.DisplayTeacher();
            foreach (var item in ldList)
            {
                if(id==item.TeacherID)
                {
                    lblName.Content = item.TeacherName;
                    break;
                }
            }

            sdList = new List<Student>();
            sdList = sbal.DisplayStudent();
            foreach (var item in sdList)
            {
                if (id == item.StudentID)
                {
                    lblName.Content = item.StudentName;
                    break;
                }
            }
        }

        //UpdateTeacher
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                int id = 0;
                id = Convert.ToInt32(cbId.SelectedItem);
                ld.TeacherID = id;
                ld.UserTeacher = lblName.Content.ToString();
                ld.PassTeacher = txtPassword.Text;
                recordsAffected = cbal.UpdateTeacherLogin(ld);
                if (recordsAffected > 0)
                {
                    MessageBox.Show("Login Details successfully Updated");
                }
                else
                    MessageBox.Show("Login details are not Updated");
            }
            catch (CreateAndManage_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            PopulateUI(teacherList);
        }

        //Delete Teacher
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int recordsAffected = 0;
            try
            {

                int id = 0;
                id = Convert.ToInt32(cbId.SelectedItem);
                ld.TeacherID = id;

                recordsAffected = cbal.DeleteTeacherLogin(id);
                if (recordsAffected > 0)
                {
                    MessageBox.Show("Teacher Login Details are Successfully Deleted");
                   
                }
                else
                {
                    throw new Student_Exception("Teacher Login Details are not Available in the records");
                }

            }

            catch (Student_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            PopulateUI(teacherList);
        }

        //Populating Teacher Data
        private void btnTeacher_Click(object sender, RoutedEventArgs e)
        {
            PopulateUI(teacherList);
        }

        //Populateing Student data
        private void btnStudent_Click(object sender, RoutedEventArgs e)
        {
            PopulateUIStudent(studentList);
        }

        //Populating the Student Data
        private void PopulateUIStudent(List<StudentLogin> studentList)
        {
            studentList = cbal.DisplayStudentLogin();
            dgData.ItemsSource = studentList;
        }

        //InsertStudent Login 
        private void btnInsertStudent_Click(object sender, RoutedEventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                int id = 0;
                id = Convert.ToInt32(cbId.SelectedItem);
                ld.StudentId = id;
                ld.UserStudent = lblName.Content.ToString();
                ld.PassStudent = txtPassword.Text;
                recordsAffected = cbal.InsertStudentLogin(ld);
                if (recordsAffected > 0)
                {
                    MessageBox.Show("Login Details successfully inserted");
                }
                else
                    MessageBox.Show("Login details are not inserted");
            }
            catch (CreateAndManage_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            PopulateUIStudent(studentList);
        }

        //Update Student Login
        private void btnUpdateStudent_Click(object sender, RoutedEventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                int id = 0;
                id = Convert.ToInt32(cbId.SelectedItem);
                ld.StudentId = id;
                ld.UserStudent = lblName.Content.ToString();
                ld.PassStudent = txtPassword.Text;
                recordsAffected = cbal.UpdateStudentLogin(ld);
                if (recordsAffected > 0)
                {
                    MessageBox.Show("Login Details successfully inserted");
                }
                else
                    MessageBox.Show("Login details are not inserted");
            }
            catch (CreateAndManage_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            PopulateUIStudent(studentList);
        }

        //Delete Student Login
        private void btnDeleteStudent_Click(object sender, RoutedEventArgs e)
        {
            int recordsAffected = 0;
            try
            {

                int id = 0;
                id = Convert.ToInt32(cbId.SelectedItem);
                ld.StudentId = id;

                recordsAffected = cbal.DeleteStudentLogin(id);
                if (recordsAffected > 0)
                {
                    MessageBox.Show("Student Login Details are Successfully Deleted");

                }
                else
                {
                    throw new Student_Exception("Student Login Details are not Available in the records");
                }

            }

            catch (Student_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            PopulateUIStudent(studentList);
        }




    }
}
