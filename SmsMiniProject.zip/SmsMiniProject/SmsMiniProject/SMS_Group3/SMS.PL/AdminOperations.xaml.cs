﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for AdminOperations.xaml
    /// </summary>
    public partial class AdminOperations : Window
    {
        public AdminOperations()
        {
            InitializeComponent();
        }

        private void btnTeacherDetails_Click(object sender, RoutedEventArgs e)
        {
            AdminTeacherEdit adte = new AdminTeacherEdit();
            adte.Show();
        }

        private void btnStudentDetails_Click(object sender, RoutedEventArgs e)
        {
            AdminStudentEdit sdte = new AdminStudentEdit();
            sdte.Show();
        }

        private void btnCreateMangeUser_Click(object sender, RoutedEventArgs e)
        {
             CreateAndManagerUser cm = new CreateAndManagerUser();
            cm.Show();
        }

        private void btnATC_Click(object sender, RoutedEventArgs e)
        {
            AssigningTeacherToClass atc = new AssigningTeacherToClass();
            atc.Show();
        }

        private void lblAdminlogout_Click(object sender, RoutedEventArgs e)
        {
            
            this.Close();
            
            
            //MainWindow mw = new MainWindow();
            //mw.Show();
        }
    }
}
