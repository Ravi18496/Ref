﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;
using System.Collections;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for AssigningTeacherToClass.xaml
    /// </summary>
    public partial class AssigningTeacherToClass : Window
    {
        ArrayList al1 = new ArrayList();
        ArrayList al2 = new ArrayList();
        Grade_BAL gbal = null;
        Teacher_BAL tbal = null;
        Studnet_BAL sbal = null;
        List<Teacher> tList = null;
        List<Student> sList = null;
        Grade gr = null;
        public AssigningTeacherToClass()
        {
            InitializeComponent();
            gbal = new Grade_BAL();
            tbal = new Teacher_BAL();
            sbal = new Studnet_BAL();
            tList = new List<Teacher>();
            sList = new List<Student>();

            tList = tbal.DisplayTeacher();
            al1.Clear();
            foreach (var item in tList)
            {
                al1.Add(item.TeacherID);
            }
            cbTeacherID.ItemsSource = al1;

            sList = sbal.DisplayStudent();
            al2.Clear();
            foreach (var item in sList)
            {
                al2.Add(item.StudentID);
            }
            cbSTudentID.ItemsSource = al2;
            
            
        }

        private void cbTeacherID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void cbSTudentID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        //Assigning to Class
        private void btnAssign_Click(object sender, RoutedEventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                gr = new Grade();
                int tid = Convert.ToInt32(cbTeacherID.SelectedItem);
                int sid = Convert.ToInt32(cbSTudentID.SelectedItem);
                int cid = 0;
                if (int.TryParse(txtClassId.Text, out cid)) { }
                gr.ClassID = cid;
                gr.TeacherID = tid;
                gr.StudentID = sid;

                recordsAffected = gbal.InsertGrade(gr);
                if (recordsAffected > 0)
                {
                    MessageBox.Show("Teacher Successfully Assigned to Class");
                }
                else
                    throw new Grade_Exception("Teacher Not Assigned to class");
            }
            catch(Grade_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
