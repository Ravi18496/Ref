﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using SMS.Entities;
using SMS.Exceptions;

namespace SMS.DAL
{
    public class AdminLogin
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public AdminLogin()
        {
            string constr = ConfigurationManager.ConnectionStrings["con1"].ConnectionString;

            con = new SqlConnection(constr);
        }
        public string ValidateLogin(LoginDetails user)
        {
            
            string username = null;
            

            try
            {
                cmd = new SqlCommand("AdminLogin_SMS", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserName", user.UserAdmin);
                cmd.Parameters.AddWithValue("@Password", user.PassAdmin);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    username = dr["UserName"].ToString();
                }
                con.Close();
            }
            catch (Login_Exception ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return username;
        }
    }
}
