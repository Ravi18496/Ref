﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using System.Data;
using System.Data.SqlClient;

namespace SMS.DAL
{
    public class Grade_DAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public Grade_DAL()
        {
            string cnStr = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_13Dec17_Hinjawadi_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser";
            cn = new SqlConnection(cnStr);
        }

        public List<Grade> SelectAll()
        {
            List<Grade> grad = new List<Grade>();

            try
            {
                cmd = new SqlCommand("Grade_Select", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Grade grd = new Grade();
                    grd.ClassID = (int)dr[0];
                    grd.GradeName = dr[1].ToString();
                    grd.Description_Grade = dr[2].ToString();
                    grd.Marks1 = (int)dr[3];
                    grd.Marks2 = (int)dr[4];
                    grd.Marks3 = (int)dr[5];
                    grd.StudentID = (int)dr[6];
                    grd.TeacherID = Convert.ToInt32(dr[7]);

                    grad.Add(grd);
                }
            }
            catch (Grade_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return grad;
        }

        public List<Grade> TeacherSelectAll()
        {
            List<Grade> grad = new List<Grade>();

            try
            {
                cmd = new SqlCommand("Grade_Select", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Grade grd = new Grade();
                    grd.ClassID = (int)dr[0];
                    //grd.GradeName = dr[1].ToString();
                    //grd.Description_Grade = dr[2].ToString();
                    //grd.Marks1 = (int)dr[3];
                    //grd.Marks2 = (int)dr[4];
                    //grd.Marks3 = (int)dr[5];
                    grd.StudentID = (int)dr[6];
                    grd.TeacherID = Convert.ToInt32(dr[7]);

                    grad.Add(grd);
                }
            }
            catch (Grade_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return grad;
        }

        //Insert Grade
        public int InsertGrade(Grade grade)
        {
            int recordsAffected = 0;
            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();
                //cmd.CommandText = "USP_InsertEmployee_142743v";
                cmd = new SqlCommand("Grade_admin", cn);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ClassID", grade.ClassID);
                cmd.Parameters.AddWithValue("@GradeName", "");
                cmd.Parameters.AddWithValue("@Grade_Description", "");
                cmd.Parameters.AddWithValue("@Marks1", 0);
                cmd.Parameters.AddWithValue("@Marks2", 0);
                cmd.Parameters.AddWithValue("@Marks3", 0);
                cmd.Parameters.AddWithValue("@StudentID", grade.StudentID);
                cmd.Parameters.AddWithValue("@TeacherID", grade.TeacherID);

                cn.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Grade_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                cn.Close();
            }
            return recordsAffected;
        }

        //Update Grade
        public int UpdateGrade(Grade grade)
        {
            int recordsAffected = 0;
            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();
                //cmd.CommandText = "USP_UpdateEmployee_142743";

                cmd = new SqlCommand("Grade_Update", cn);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;


                // cmd.Parameters.AddWithValue("@ClassID", grade.ClassID);
                cmd.Parameters.AddWithValue("@StudentID", grade.StudentID);
                cmd.Parameters.AddWithValue("@Gdes", grade.Description_Grade);
                cmd.Parameters.AddWithValue("@gname", grade.GradeName);
                cmd.Parameters.AddWithValue("@m1", grade.Marks1);
                cmd.Parameters.AddWithValue("@m2", grade.Marks2);
                cmd.Parameters.AddWithValue("@m3", grade.Marks3);

                //cmd.Parameters.AddWithValue("@TeacherID", grade.TeacherID);

                cn.Open();
                recordsAffected = cmd.ExecuteNonQuery();


            }
            catch (SqlException ex)
            {
                throw ex;

            }
            catch (Grade_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                cn.Close();
            }

            return recordsAffected;
        }
    }
}
