﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using System.Data.SqlClient;

namespace SMS.DAL
{
    public class Cash_DAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public Cash_DAL()
        {
            string str = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_13Dec17_Hinjawadi_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser";
            cn = new SqlConnection(str);
        }

        
        public bool Insert(Fees fee)
        {
            bool inserted = false;
            try
            {
                cmd = new SqlCommand("Fees_Insert", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@InvoiceID", fee.InvoiceID);
                cmd.Parameters.AddWithValue("@StudentID", fee.StudentID);
                cmd.Parameters.AddWithValue("@Payment_date", fee.Payment_Date);
                cmd.Parameters.AddWithValue("@Fees_amount", fee.Fees_amount);
                cn.Open();
                cmd.ExecuteNonQuery();
                inserted = true;
            }
            catch (Fees_Exception ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return inserted;
        }


        public bool Update(Fees fee)
        {
            bool updated = false;
            try
            {
                cmd = new SqlCommand("Fees_Update", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@InvoiceID", fee.InvoiceID);
                cmd.Parameters.AddWithValue("@StudentID", fee.StudentID);
                cmd.Parameters.AddWithValue("@Payment_date", fee.Payment_Date);
                cmd.Parameters.AddWithValue("@Fees_amount", fee.Fees_amount);
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Fees_Exception ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return updated;
        }

        public List<Fees> SelectAll()
        {
            List<Fees> stufee = new List<Fees>();

            try
            {

                cmd = new SqlCommand("Fees_Select", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();//For Select Only
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Fees fee = new Fees();
                    fee.InvoiceID = (int)dr[0];
                    fee.StudentID = (int)dr[2];
                    fee.Payment_Date = (Convert.ToDateTime(dr[1]));
                    fee.Fees_amount = (int)dr[3];

                    stufee.Add(fee);
                }
            }
            catch (Fees_Exception ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return stufee;
        }
    }
}
