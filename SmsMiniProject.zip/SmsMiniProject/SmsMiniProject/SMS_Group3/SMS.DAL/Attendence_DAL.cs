﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using SMS.Entities;
using SMS.Exceptions;

namespace SMS.DAL
{
    public class Attendence_DAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public Attendence_DAL()
        {
            string cnStr = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_13Dec17_Hinjawadi_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser";
            cn = new SqlConnection(cnStr);
        }

        public List<Attendence> SelectAll()
        {
            List<Attendence> Attnd = new List<Attendence>();

            try
            {
                cmd = new SqlCommand("Attendence_Select", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Attendence att = new Attendence();
                    att.AttendenceID = Convert.ToInt32(dr[0]);
                    att.StudentID = Convert.ToInt32(dr[1]);
                    att.Today_Date = Convert.ToDateTime(dr[2]);
                    att.Attended = Convert.ToChar(dr[3]);

                    Attnd.Add(att);
                }
            }
            catch (Attendence_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return Attnd;
        }

        //Insert Attendence for student
        public int InsertAttendence(Attendence att)
        {
            int recordsAffected = 0;
            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();              
                cmd = new SqlCommand("Attendence_Insert", cn);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AttendenceID", att.AttendenceID);
                cmd.Parameters.AddWithValue("@StudentID", att.StudentID);
                cmd.Parameters.AddWithValue("@Today_Date", att.Today_Date);
                cmd.Parameters.AddWithValue("@Attended", att.Attended);

                cn.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Attendence_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return recordsAffected;
        }
    }
}
