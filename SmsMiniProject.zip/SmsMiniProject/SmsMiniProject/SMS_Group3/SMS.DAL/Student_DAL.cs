﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;

namespace SMS.DAL
{
    public class Student_DAL
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        //Default Constructor for Connection String
        public Student_DAL()
        {
            string constr = ConfigurationManager.ConnectionStrings["con1"].ConnectionString;

            con = new SqlConnection(constr);
        }

        //Student Details Insert Method
        public int InsertStudent(Student s)
        {
            int recordsAffected = 0;
            try
            {
                cmd = new SqlCommand("Student_Insert", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@StudentID", s.StudentID);
                cmd.Parameters.AddWithValue("@StudentName", s.StudentName);
                cmd.Parameters.AddWithValue("@Gender", s.Gender);
                cmd.Parameters.AddWithValue("@DOB", s.DOB);
                cmd.Parameters.AddWithValue("@BloodGroup", s.BloodGroup);
                cmd.Parameters.AddWithValue("@Contact", s.Contact);
                cmd.Parameters.AddWithValue("@Student_Address", s.Student_address);

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();


            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                con.Close();
            }
            return recordsAffected;
        }

        //Student Details Update Method
        public int UpdateStudent(Student s)
        {
            int recordsAffected = 0;
            try
            {
                cmd = new SqlCommand("Student_Update", con);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@StudentID", s.StudentID);
                cmd.Parameters.AddWithValue("@StudentName", s.StudentName);
                cmd.Parameters.AddWithValue("@Gender", s.Gender);
                cmd.Parameters.AddWithValue("@DOB", s.DOB);
                cmd.Parameters.AddWithValue("@BloodGroup", s.BloodGroup);
                cmd.Parameters.AddWithValue("@Contact", s.Contact);
                cmd.Parameters.AddWithValue("@Student_Address", s.Student_address);



                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();


            }
            catch (SqlException ex)
            {
                throw ex;

            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                con.Close();
            }

            return recordsAffected;
        }

        //Student Details Delete Method
        public int DeleteStudent(int sid)
        {
            int recordsAffected = 0;

            try
            {

                cmd = new SqlCommand("Student_Delete", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StudentID", sid);
                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();


            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return recordsAffected;
        }

        //Student Details Display Method
        public List<Student> DisplayStudent()
        {
            List<Student> sList = new List<Student>();
            try
            {
                cmd = new SqlCommand("Student_Select", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                con.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows)
                    {
                        Student s = new Student();
                        s.StudentID = (int)dr["StudentID"];
                        s.StudentName = dr["StudentName"].ToString();
                        s.Gender = dr["Gender"].ToString();
                        s.DOB = Convert.ToDateTime(dr["DOB"]);
                        s.BloodGroup = dr["BloodGroup"].ToString();
                        s.Contact = dr["Contact"].ToString();
                        s.Student_address = dr["Student_address"].ToString();

                        sList.Add(s);
                    }
                    else
                        throw new Student_Exception("Records are not available");
                }
            }

            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                con.Close();
            }
            return sList;

        }

        //Student Details Total Count Method
        public int TotalCountStudent(Student t)
        {
            int count = 0;
            try
            {
                cmd = new SqlCommand("Student_TotalCount", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                count = (int)cmd.ExecuteScalar();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                con.Close();
            }
            return count;
        }

        //Student Details Search Method
        public List<Student> SearchStudent(int sid)
        {
            List<Student> sList = new List<Student>();
            try
            {
                cmd = new SqlCommand("Student_Search", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StudentID", sid);

                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    Student s = new Student();
                    dr.Read();
                    s.StudentID = (int)dr["StudentID"];
                    s.StudentName = dr["StudentName"].ToString();
                    s.Gender = dr["Gender"].ToString();
                    s.DOB = Convert.ToDateTime(dr["DOB"]);
                    s.BloodGroup = dr["BloodGroup"].ToString();
                    s.Contact = dr["Contact"].ToString();
                    s.Student_address = dr["Student_address"].ToString();

                    sList.Add(s);
                }

                else
                    throw new Student_Exception("Records are not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                con.Close();
            }
            return sList;
        }
    }
}
