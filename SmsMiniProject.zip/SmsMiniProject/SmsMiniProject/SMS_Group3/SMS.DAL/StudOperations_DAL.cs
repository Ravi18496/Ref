﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using SMS.Entities;
using SMS.Exceptions;


namespace SMS.DAL
{
    public class StudOperations_DAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public StudOperations_DAL()
        {
            string cnStr = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_13Dec17_Hinjawadi_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser";
            cn = new SqlConnection(cnStr);
        }

        public List<Student> SelectAll()
        {
            List<Student> stud = new List<Student>();

            try
            {
                cmd = new SqlCommand("Student_Select", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Student stu = new Student();
                    stu.StudentID = (int)dr[0];
                    stu.StudentName = dr[1].ToString();
                    stu.Gender = dr[2].ToString();
                    stu.DOB = (Convert.ToDateTime(dr[3]));
                    stu.BloodGroup = dr[4].ToString();
                    stu.Contact = dr[5].ToString();
                    stu.Student_address = dr[6].ToString();

                    stud.Add(stu);
                }
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return stud;
        }
    }

}
