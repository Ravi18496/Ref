﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;

namespace SMS.BAL
{
    /// <summary>
    /// This class is for Student BAL operations
    /// </summary>
    public class Studnet_BAL
    {
        Student_DAL sdal = new Student_DAL();

        //Method to validate Student Entered Detials
        public bool ValidateStudent(Student s)
        {
            bool sValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
                if (s.StudentID < 1000 || s.StudentID > 9999)
                {
                    sValidated = false;
                    message.Append("Student Id should only be 4 digits.\n");
                }
                if (s.StudentName == String.Empty)
                {
                    sValidated = false;
                    message.Append("Student Name should be provided.\n");
                }
                else if (!Regex.IsMatch(s.StudentName, "[A-Z][a-z]+"))
                {
                    sValidated = false;
                    message.Append("Student Name should start with capital alphabet and it should have alphabets only.\n");
                }
                if (s.Gender == String.Empty)
                {
                    sValidated = false;
                    message.Append("Student Gender should be Selected.\n");
                }
                if (s.DOB >= DateTime.Today)
                {
                    sValidated = false;
                    message.Append("Student Date of should be Less than current date.\n");
                }
                if (s.Contact == String.Empty)
                {
                    sValidated = false;
                    message.Append("Student Number should be provided.\n");
                }
                else if (!Regex.IsMatch(s.Contact, "[7-9][0-9]{9}"))
                {
                    sValidated = false;
                    message.Append("Contact Number should start with 7 or 8 or 9 and it should only be 10 digits.\n");
                }
                if (s.BloodGroup == String.Empty)
                {
                    sValidated = false;
                    message.Append("BloodGroup should be provided.\n");
                }

                if (s.Student_address == String.Empty)
                {
                    sValidated = false;
                    message.Append("Student address should be provided");
                }

                if (sValidated == false)
                {
                    throw new Student_Exception(message.ToString());
                }

            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return sValidated;
        }

        //Method to Validate Insert Student's details
        public int InsertStudent(Student s)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateStudent(s))
                {
                    recordsAffected = sdal.InsertStudent(s);
                }
                else
                {
                    throw new Student_Exception("Please provide valid Student Information.");
                }
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Method to validate Update Student's details
        public int UpdateStudent(Student s)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateStudent(s))
                {
                    recordsAffected = sdal.UpdateStudent(s);
                }
                else
                    throw new Student_Exception("Please Provide valid Student Information");
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Method to validate Delete Student's details
        public int DeleteStudent(int sid)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = sdal.DeleteStudent(sid);
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Method to validate Display Student's details
        public List<Student> DisplayStudent()
        {
            List<Student> sList = null;
            try
            {
                sList = sdal.DisplayStudent();
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return sList;
        }

        //Method to validate Total Count
        public int TotalCountStudent(Student s)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = sdal.TotalCountStudent(s);
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Method to Search Student Record
        public List<Student> SearchStudent(int sid)
        {
            List<Student> sList = null;
            try
            {
                sList = sdal.SearchStudent(sid);
            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return sList;
        }
    }
}
