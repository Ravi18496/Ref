﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;

namespace SMS.BAL
{
    public class TeacherLogin_BAL
    {
        TeacherLogin_DAL tdal = new TeacherLogin_DAL();
        public string TeacherLogin(LoginDetails user)
        {
            string username = null;

            try
            {
                username = tdal.ValidateLogin(user);
            }
            catch (Login_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return username;
        }
    }
}
