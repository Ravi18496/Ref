﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.DAL;
using SMS.Exceptions;

namespace SMS.BAL
{
    public class AdminLogin_BAL
    {
        AdminLogin adal = new AdminLogin();

        public string AdminLogin(LoginDetails user)
        {
            string username = null;

            try
            {
                username = adal.ValidateLogin(user);
            }
            catch (Login_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return username;
        }
    }
}
