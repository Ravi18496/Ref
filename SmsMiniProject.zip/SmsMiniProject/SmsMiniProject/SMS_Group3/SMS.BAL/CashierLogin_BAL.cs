﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;

namespace SMS.BAL
{
    public class CashierLogin_BAL
    {
        CashierLogin_DAL cdal = new CashierLogin_DAL();
        public string CashierLogin(LoginDetails user)
        {
            string username = null;

            try
            {
                username = cdal.ValidateLogin(user);
            }
            catch (Login_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return username;
        }
    }
}
