﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;
using System.Text.RegularExpressions;


namespace SMS.BAL
{
    public class Grade_BAL
    {
        Grade_DAL dal = null;

        public Grade_BAL()
        {
            dal = new Grade_DAL();
        }

        //Getall method to retrieve all the data from stored procedure
        public List<Grade> GetAll()
        {
            List<Grade> grdlist = null;
            try
            {

                grdlist = dal.SelectAll();

            }
            catch (Grade_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return grdlist;
        }

        public List<Grade> TeacherGetAll()
        {
            List<Grade> grdlist = null;
            try
            {

                grdlist = dal.TeacherSelectAll();

            }
            catch (Grade_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return grdlist;
        }

        //Validations for Grade
        public bool ValidateGrade(Grade grade)
        {
            bool gradeValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //if (grade.ClassID < 100 || grade.ClassID > 999)
                //{
                //  message.Append("Grade ID should be 3 digits\n");
                //  gradeValidated = false;
                //}
                if (grade.GradeName == String.Empty)
                {
                    gradeValidated = false;
                    message.Append("Grade Name should be provided\n");
                }
                else if (!Regex.IsMatch(grade.GradeName, "[A-D]{1}"))
                {
                    message.Append("Grade Name should start with capital alphabet and it should have alphabets only\n\n");
                    gradeValidated = false;
                }
                if (grade.Description_Grade == String.Empty)
                {
                    message.Append("Grade Description should be provided\n");
                    gradeValidated = false;
                }
                if (grade.Marks1 < 0 || grade.Marks2 < 0 || grade.Marks3 < 0)
                {
                    message.Append("Marks Should be positive\n");
                    gradeValidated = false;
                }
                //if (grade.StudentID < 1000 || grade.StudentID > 9999)
                //{
                //    message.Append("Student ID should be 4 digits\n");
                //    gradeValidated = false;
                //}
                if (gradeValidated == false)
                    throw new Grade_Exception(message.ToString());
            }
            catch (Grade_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return gradeValidated;
        }

        //Insert 
        public int InsertGrade(Grade grade)
        {
            int recordsAffected = 0;

            try
            {
                
                    recordsAffected = dal.InsertGrade(grade);
                
            }
            catch (Grade_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Update
        public int UpdateGrade(Grade grade)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateGrade(grade))
                {
                    recordsAffected = dal.UpdateGrade(grade);
                }
                else
                    throw new Grade_Exception("Please Provide valid Grade Information");
            }
            catch (Grade_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
    }
}
