﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;

namespace SMS.BAL
{
    public class StudOperations_BAL
    {
        StudOperations_DAL dal = null;

        public StudOperations_BAL()
        {
            dal = new StudOperations_DAL();
        }

        //Getall method to retrieve all the data from stored procedure
        public List<Student> GetAll()
        {
            List<Student> stulist = null;
            try
            {

                stulist = dal.SelectAll();

            }
            catch (Student_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stulist;
        }
    }
}
