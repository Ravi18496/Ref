﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTBS.Entity
{
    public class Screens
    {
        int screenID;
        public int ScreenID
        {
            get { return screenID; }
            set { screenID = value; }
        }

        string screenName;
        public string ScreenName
        {
            get { return screenName; }
            set { screenName = value; }
        }

        int capacity;
        public int Capacity
        {
            get { return capacity; }
            set { capacity = value; }
        }
    }
}
