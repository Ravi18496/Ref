﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTBS.Entity
{
    public class Genre
    {
        int genreID;
        public int GenreID
        {
            get { return genreID; }
            set { genreID = value; }
        }

        string genreName;
        public string GenreName
        {
            get { return genreName; }
            set { genreName = value; }
        }

        string description;
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

    }
}
