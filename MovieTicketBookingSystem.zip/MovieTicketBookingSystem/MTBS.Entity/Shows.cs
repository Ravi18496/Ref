﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTBS.Entity
{
    public class Shows
    {
        int showID;
        public int ShowID
        {
            get { return showID; }
            set { showID = value; }
        }

        DateTime showTime;
        public DateTime ShowTime
        {
            get { return showTime; }
            set { showTime = value; }
        }

        int price;
        public int Price
        {
            get { return price; }
            set { price = value; }
        }

        int screenID;
        public int ScreenID
        {
            get { return screenID; }
            set { screenID = value; }
        }

        int movieID;
        public int MovieID
        {
            get { return movieID; }
            set { movieID = value; }
        }
    }
}
