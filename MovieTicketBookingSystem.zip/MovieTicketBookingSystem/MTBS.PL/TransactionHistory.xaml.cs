﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.Entity;
using MTBS.Exception;
using MTBS.BL;


namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for TransactionHistory.xaml
    /// </summary>
    public partial class TransactionHistory : Window
    {
        ManagingTicketsBL bal = null;
        List<Tickets> tktsList = null;
        Tickets tkts = null;

        public TransactionHistory()
        {
            InitializeComponent();
            bal = new ManagingTicketsBL();
            tktsList = new List<Tickets>();
            tkts = new Tickets();          

        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtViewersID.Text);
            tktsList = bal.GetAll();
            var res = from t in tktsList
                      where t.ViewersID == id
                      select t;
            dgvHistory.ItemsSource = res.ToList(); 
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            UserHome uh3 = new UserHome();
            uh3.ShowDialog();
        }


    }
}
