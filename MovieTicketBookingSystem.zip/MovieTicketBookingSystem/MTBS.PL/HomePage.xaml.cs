﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class HomePage : Window
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            Register rtr = new Register();
            rtr.ShowDialog();
        }

        private void btnUserLogin_Click(object sender, RoutedEventArgs e)
        {
            UserHome mvs = new UserHome();
            mvs.ShowDialog();
        }

        private void btnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            AdminRoles adr = new AdminRoles();
            adr.ShowDialog();
        }

       
    }
}
