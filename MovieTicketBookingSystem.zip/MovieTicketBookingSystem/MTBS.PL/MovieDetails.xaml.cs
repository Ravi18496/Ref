﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.Entity;
using MTBS.BL;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for MovieDetails.xaml
    /// </summary>
    public partial class MovieDetails : Window
    {
        Movies m = null;
        ManageMovieDetailsBL bal = null;
        List<Genre> allGenres = null;
        List<Movies> allMovies = null;
        public MovieDetails()
        {
            InitializeComponent();
            m = new Movies();
            bal = new ManageMovieDetailsBL();
            cbMovieId.DataContext = bal.GetAll();
            cbGenreId.DataContext = bal.GetAllGenre();

        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                m.MovieName = txtMovieName.Text;
                m.ReleaseDate = Convert.ToDateTime(dtReleaseDate.Text);
                m.GenreID = Convert.ToInt32(cbGenreId.Text);
                m.Movie_Description = txtDescription.Text;
                bal.Insert(m);
                allMovies = bal.GetAll();
                dgvSelectAll.ItemsSource = allMovies.ToList();
                cbMovieId.DataContext = bal.GetAll();
            }

            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                m.MovieID = Convert.ToInt16(cbMovieId.Text);
                m.MovieName = txtMovieName.Text;
                m.ReleaseDate = Convert.ToDateTime(dtReleaseDate.Text);
                m.GenreID = Convert.ToInt16(cbGenreId.Text);
                m.Movie_Description = txtDescription.Text;
                bal.Update(m);
                allMovies = bal.GetAll();
                dgvSelectAll.ItemsSource = allMovies.ToList();
                cbMovieId.DataContext = bal.GetAll();

            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt16(cbMovieId.Text);
            bal.Delete(id);
            allMovies = bal.GetAll();
            dgvSelectAll.ItemsSource = allMovies.ToList();
            cbMovieId.DataContext = bal.GetAll();
        }

        private void btnClearAll_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                txtMovieName.Text = " ";
                txtDescription.Text = " ";
                dtReleaseDate.Text = " ";
                cbGenreId.Text = " ";
                cbMovieId.Text = " ";
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisplayAll_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                allMovies = bal.GetAll();
                PopulateUI(allMovies);

            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void PopulateUI(List<Movies> allMovies)
        {
            dgvSelectAll.ItemsSource = allMovies;
            cbMovieId.ItemsSource = allMovies;
            cbMovieId.DisplayMemberPath = "MovieID";

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AdminRoles adr = new AdminRoles();
            adr.ShowDialog();
        }

    }
}
