﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for ManageScreens.xaml
    /// </summary>
    public partial class AdminRoles : Window
    {
        public AdminRoles()
        {
            InitializeComponent();
        }

        private void btnGenerateReports_Click(object sender, RoutedEventArgs e)
        {
            GenerateReports grd = new GenerateReports();
            grd.ShowDialog();
        }

        private void btnManageTicket_Click(object sender, RoutedEventArgs e)
        {
            TicketDetails tcd = new TicketDetails();
            tcd.ShowDialog();
        }

        private void btnManageMovie_Click(object sender, RoutedEventArgs e)
        {
            MovieDetails mvd = new MovieDetails();
            mvd.ShowDialog();
        }

        private void btnManageScreen_Click(object sender, RoutedEventArgs e)
        {
            ScreenDetails scd = new ScreenDetails();
            scd.ShowDialog();
        }

      
    }
}
