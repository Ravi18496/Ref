﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MTBS.Entity;
using MTBS.Exception;
using MTBS.BL;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for BookTickets.xaml
    /// </summary>
    public partial class BookTickets : Window
    {
        ManageMovieDetailsBL bal = null;
        ManagingTicketsBL tktsbal = null;
        Movies m = null;
        Tickets tkts = null;

        public BookTickets()
        {
            InitializeComponent();
            bal = new ManageMovieDetailsBL();
            tktsbal = new ManagingTicketsBL();
            tkts = new Tickets();
            m = new Movies();
            cbMovieName.DataContext = bal.GetAll();
        }

        private void btnPayment_Click(object sender, RoutedEventArgs e)
        {
            Payment pm = new Payment();
            pm.ShowDialog();
            try
            {
                m.MovieName = cbMovieName.Text;

            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            UserHome uh4 = new UserHome();
            uh4.ShowDialog();
        }


    }
}
