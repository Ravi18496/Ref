﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MTBS.PL
{
    /// <summary>
    /// Interaction logic for Description.xaml
    /// </summary>
    public partial class UserHome : Window
    {
        public UserHome()
        {
            InitializeComponent();
        }

        private void btnBook_Click(object sender, RoutedEventArgs e)
        {
            BookTickets bkt = new BookTickets();
            bkt.ShowDialog();
        }

        private void btnSearchMov_Click(object sender, RoutedEventArgs e)
        {
            SearchMovies smv = new SearchMovies();
            smv.ShowDialog();
        }

        private void btnProfile_Click(object sender, RoutedEventArgs e)
        {
            Profile pf = new Profile();
            pf.ShowDialog();
        }

        private void btnHistory_Click(object sender, RoutedEventArgs e)
        {
            TransactionHistory th = new TransactionHistory();
            th.ShowDialog();
        }
    }
}
