﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.Entity;
using MTBS.Exception;

namespace MTBS.DAL
{
    public class ManagingTicketsDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public ManagingTicketsDAL()
        {
            string cnstr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            cn = new SqlConnection(cnstr);
        }

        public List<Tickets> SelectAll()
        {

            List<Tickets> tktsList = new List<Tickets>();

            try
            {
                cmd = new SqlCommand("select * from OMTBS_Tickets", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                // to retrive records with the help of DR
                while (dr.Read())
                {
                    Tickets tkts = new Tickets();
                    tkts.TicketId = (int)dr[0];
                    tkts.Transaction_Date = Convert.ToDateTime(dr[1]);
                    tkts.No_of_tickets = (int)dr[2];
                    tkts.ViewersID = (int)dr[3];
                    tkts.ShowID = (int)dr[4];
                    
                    tktsList.Add(tkts);
                }
            }

            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                dr.Close();
                cn.Close();
            }
            return tktsList;

        }

        public List<Viewers> SelectAllViewers()
        {
            List<Viewers> vsList = new List<Viewers>();
            try
            {
                cmd = new SqlCommand("select * from OMTBS_Viewers", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Viewers v = new Viewers();
                    v.ViewersID= (int)dr[0];
                    v.FirstName = dr[1].ToString();
                    v.LastName = dr[2].ToString();
                    v.MobileNumber = dr[3].ToString();
                    v.Email = dr[4].ToString();
                    v.Username = dr[5].ToString();
                    v.Password=dr[6].ToString();
                    vsList.Add(v);
                }
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                dr.Close();
                cn.Close();
            }
            return vsList;
        }

        public List<Shows> SelectAllShows()
        {
            List<Shows> showList = new List<Shows>();
            try
            {
                cmd = new SqlCommand("select * from OMTBS_Shows", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Shows s = new Shows();
                    s.ShowID = (int)dr[0];
                    s.ShowTime = Convert.ToDateTime(dr[1]);
                    s.Price = (int)dr[2];
                    s.ScreenID = (int)dr[3];
                    s.MovieID = (int)dr[4];
                    showList.Add(s);
                    
                }
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                dr.Close();
                cn.Close();
            }
            return showList;
        }

        public int Insert(Tickets tkts)
        {
            int n;

            try
            {
                cmd = new SqlCommand("usp_Insert_OMTBS_Tickets", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Transaction_Date", tkts.Transaction_Date);
                cmd.Parameters.AddWithValue("@No_of_tickets", tkts.No_of_tickets);
                cmd.Parameters.AddWithValue("@ViewersID", tkts.ViewersID);
                cmd.Parameters.AddWithValue("@ShowID", tkts.ShowID);
                cn.Open();
                n = cmd.ExecuteNonQuery();
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return n;
        }

        public int Update(Tickets tkts)
        {
            int n;

            try
            {
                cmd = new SqlCommand("usp_Update_OMTBS_Tickets", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TicketId", tkts.TicketId);
                cmd.Parameters.AddWithValue("@Transaction_Date", tkts.Transaction_Date);
                cmd.Parameters.AddWithValue("@No_of_tickets", tkts.No_of_tickets);
                cmd.Parameters.AddWithValue("@ViewersID", tkts.ViewersID);
                cmd.Parameters.AddWithValue("@ShowID", tkts.ShowID);
                cn.Open();
                n = cmd.ExecuteNonQuery();
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return n;
        }
    }
}
