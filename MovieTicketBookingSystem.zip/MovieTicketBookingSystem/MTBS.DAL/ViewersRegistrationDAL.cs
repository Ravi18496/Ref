﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.Entity;
using System.Data.SqlClient;
using System.Configuration;

namespace MTBS.DAL
{
   
        public class ViewersRegistrationDAL
        {
            SqlConnection cn = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            public ViewersRegistrationDAL()
            {
                string cnstr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
                cn = new SqlConnection(cnstr);

            }
            public int Insert(Viewers v)
            {
                int n;
                try
                {

                    cmd = new SqlCommand("usp_Insert_OMTBS_Viewers", cn); //stored procedure
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FirstName", v.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", v.LastName);
                    cmd.Parameters.AddWithValue("@MobileNumber", v.MobileNumber);
                    cmd.Parameters.AddWithValue("@Email", v.Email);
                    cmd.Parameters.AddWithValue("@UserName", v.Username);
                    cmd.Parameters.AddWithValue("@Password", v.Password);
                    cn.Open();
                    n = cmd.ExecuteNonQuery();
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                finally
                {
                    cn.Close();
                }
                return n;
            }
        }
    }

