﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MTBS.Entity;
using System.Data.SqlClient;
using System.Configuration;

namespace MTBS.DAL
{
    public class ManageMovieDetailsDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public ManageMovieDetailsDAL()
        {
            string cnstr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            cn = new SqlConnection(cnstr);
        }
        public List<Movies> SelectAll()
        {
            List<Movies> mov = new List<Movies>();
            try
            {
                cmd = new SqlCommand("select * from OMTBS_Movies", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Movies m = new Movies();
                    m.MovieID = (int)dr[0];
                    m.MovieName = dr[1].ToString();
                    m.ReleaseDate = (DateTime)dr[2];
                    m.GenreID = (int)dr[3];
                    m.Movie_Description = dr[4].ToString();
                    mov.Add(m);
                }
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                dr.Close();
                cn.Close();
            }
            return mov;
        }
        public int Insert(Movies m)
        {
            int mo;

            try
            {
                cmd = new SqlCommand("usp_Insert_OMTBS_Movies", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MovieName", m.MovieName);
                cmd.Parameters.AddWithValue("@ReleaseDate", m.ReleaseDate);
                cmd.Parameters.AddWithValue("@GenreID", m.GenreID);
                cmd.Parameters.AddWithValue("@Movie_Description", m.Movie_Description);

                cn.Open();
                mo = cmd.ExecuteNonQuery();
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return mo;
        }
        public int Update(Movies m)
        {
            int mo;
            try
            {

                cmd = new SqlCommand("usp_UpdateOMTBS_Movies", cn); //stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MovieID", m.MovieID);
                cmd.Parameters.AddWithValue("@MovieName", m.MovieName);
                cmd.Parameters.AddWithValue("@ReleaseDate", m.ReleaseDate);
                cmd.Parameters.AddWithValue("@GenreID", m.GenreID);
                cmd.Parameters.AddWithValue("@Movie_Description", m.Movie_Description);
                cn.Open();
                mo = cmd.ExecuteNonQuery();
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return mo;
        }
        public int Delete(int movieid)
        {
            int n;
            try
            {
                cmd = new SqlCommand("usp_Delete_OMTBS_Movies", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MovieID", movieid);
                cn.Open();
                n = cmd.ExecuteNonQuery();
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return n;
        }

        public List<Genre> SelectAllGenre()
        {
            List<Genre> Gen = new List<Genre>();
            try
            {
                cmd = new SqlCommand("select * from OMTBS_Genre", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Genre g = new Genre();
                    g.GenreID = (int)dr[0];
                    g.GenreName = dr[1].ToString();
                    g.Description = dr[2].ToString();
                    Gen.Add(g);
                }
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                dr.Close();
                cn.Close();
            }
            return Gen;
        }
    }
}
