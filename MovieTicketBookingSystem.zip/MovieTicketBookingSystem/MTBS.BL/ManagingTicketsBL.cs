﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.Entity;
using MTBS.Exception;
using MTBS.DAL;

namespace MTBS.BL
{
    public class ManagingTicketsBL
    {
        ManagingTicketsDAL dal = null;
        Tickets tkts = null;

        public ManagingTicketsBL()
        {
            dal = new ManagingTicketsDAL();
            tkts = new Tickets();
        }

        public List<Tickets> GetAll()
        {
            try
            {
                return dal.SelectAll();
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public List<Viewers> GetAllViewers()
        {
            try
            {
                return dal.SelectAllViewers();
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public List<Shows> GetAllShows()
        {
            try
            {
                return dal.SelectAllShows();
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public int Insert(Tickets tkt)
        {
            try
            {
                return dal.Insert(tkt);
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public int Update(Tickets tkt)
        {
            try
            {
                return dal.Update(tkt);
            }
            catch (MtbsException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
    }
}
