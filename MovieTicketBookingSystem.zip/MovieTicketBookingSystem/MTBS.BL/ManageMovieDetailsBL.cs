﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MTBS.Entity;
using MTBS.DAL;

namespace MTBS.BL
{
    public class ManageMovieDetailsBL
    {
        ManageMovieDetailsDAL dal = null;
        Movies m = null;
        public ManageMovieDetailsBL()
        {
            dal = new ManageMovieDetailsDAL();
            m = new Movies();
        }
        public List<Movies> GetAll()
        {
            try
            {
                return dal.SelectAll();
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public List<Genre> GetAllGenre()
        {
            try
            {
                return dal.SelectAllGenre();
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

        public int Insert(Movies m)
        {
            try
            {
                return dal.Insert(m);
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
        public int Update(Movies m)
        {
            try
            {
                return dal.Update(m);
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
        public int Delete(int movieid)
        {
            try
            {
                return dal.Delete(movieid);
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }

    }
}
