﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.DAL;
using MTBS.Entity;

namespace MTBS.BL
{
    public class SearchMoviesBL
    {
        SearchMoviesDAL dal = null;

        public SearchMoviesBL()
        {
            dal = new SearchMoviesDAL();
        }
        public List<Genre> GetAllGenre()
        {
            try
            {
                return dal.SelectGenre();
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
    }
}
