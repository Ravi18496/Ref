﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTBS.Entity;
using MTBS.DAL;

namespace MTBS.BL
{
    public class ViewersRegistraionBL
    {
        ViewersRegistrationDAL dal = null;
        Viewers v = null;
        public ViewersRegistraionBL()
        {
            dal = new ViewersRegistrationDAL();
            v = new Viewers();
        }
        public int Insert(Viewers v)
        {
            try
            {
                return dal.Insert(v);
            }
            catch(SystemException ex)
            {
                throw ex;
            }
        }
    }
}
