﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Exceptions;
using SMS.BAL;
using SMS.Entities;

namespace WEB.PL
{
    public partial class ATtC : System.Web.UI.Page
    {
        List<Student> studList = null;
        List<Teacher> teachList = null;
        Student_BAL sbal = null;
        Teacher_BAL tbal = null;
        AssigningTeacher astc = null;
        AssigningTeacher_BAL abal = null;
        Class c = new SMS.Entities.Class();
        Class_BAL cbal = new Class_BAL();

        protected void Page_Load(object sender, EventArgs e)
        {
            abal = new AssigningTeacher_BAL();
            studList = new List<Student>();
            teachList = new List<Teacher>();
            sbal = new Student_BAL();
            tbal = new Teacher_BAL();
            
            
            List<Class> clist = new List<SMS.Entities.Class>();

            clist = cbal.DisplayClass();
            ddlClassId.DataSource = clist;
            ddlClassId.DataTextField = "ClassID";
            ddlClassId.DataBind();

            if (!IsPostBack)
            {
                studList = sbal.DisplayStudent();
                teachList = tbal.DisplayTeacher();
                ddlStudentID.DataSource = studList;
                ddlStudentID.DataTextField = "StudentID";
                DataBind();
                ddlTeacherID.DataSource = teachList;
                ddlTeacherID.DataTextField = "TeacherID";
                DataBind();
            }
        }

      
       

        //Assigning Teacher to Class Method
        protected void btnAssign_Click(object sender, EventArgs e)
        {
            
            
        }

        protected void btnAssign_Click1(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            astc = new AssigningTeacher();
            astc.ClassID = int.Parse(ddlClassId.SelectedItem.ToString());
            astc.StudentID = int.Parse(ddlStudentID.SelectedItem.ToString());
            astc.TeacherID = int.Parse(ddlTeacherID.SelectedItem.ToString());
            try
            {
                recordsAffected = abal.InsertAssigningTeacher(astc);
                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Assigned Successfully')</script>");
                }
                else
                    Response.Write("<script>alert('Not Assigned ')</script>");
            }
            catch(AssigningTeacher_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
        }

        //Class Description Method
        protected void btnInsertClassDescription_Click1(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            c.ClassName = txtClassDiscription.Text;
            recordsAffected = cbal.InsertClass(c);
            try
            {
                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Assigned Successfully')</script>");
                }
                else
                    Response.Write("<script>alert('Not Assigned ')</script>");
            }
            catch(Class_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>"); 
            }

        }

    }
}