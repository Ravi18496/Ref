﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace WEB.PL
{
    public partial class StudentGradeAndAttendence : System.Web.UI.Page
    {
        List<Marks> mlist = new List<Marks>();
        Marks_BAL mbal = new Marks_BAL();
        List<Attendence> alist = new List<Attendence>();
        Attendence_BAL abal = new Attendence_BAL();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //protected void btnStudentGrade_Click(object sender, EventArgs e)
        //{
        //    mlist = mbal.GetAll();
        //    int id = 0;
        //    id = Convert.ToInt32(Session["userid"]);
        //    var res = from m in mlist
        //              where m.MarksID == id
        //              select m;
        //    gvStudentAG.DataSource= res.ToList();
        //    gvStudentAG.DataBind();
        //}

        protected void btnStudentAttendence_Click(object sender, EventArgs e)
        {
            alist = abal.GetAll();
            int id = 0;
            id = Convert.ToInt32(Session["userid"]);
            List<Attendence> att = new List<Attendence>();
            foreach (var item in alist)
            {
                if (item.StudentID == id)
                {
                    att.Add(item);
                    break;
                }
            }
            gvStudentAG.DataSource = att;
            gvStudentAG.DataBind();
        }

        protected void btnStudentGrade_Click1(object sender, EventArgs e)
        {
            mlist = mbal.GetAll();
            int id = 0;
            id = Convert.ToInt32(Session["userid"]);
            List<Marks> marks = new List<Marks>();
            foreach (var item in mlist)
            {
                if(item.StudentID == id)
                {
                    marks.Add(item);
                    break;
                }
            }
            gvStudentAG.DataSource = marks;
            gvStudentAG.DataBind();
        }
    }
}