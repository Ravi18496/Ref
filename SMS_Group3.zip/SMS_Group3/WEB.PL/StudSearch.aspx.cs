﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.BAL;
using SMS.Exceptions;

namespace WEB.PL
{
    public partial class StudSearch : System.Web.UI.Page
    {
        Student_BAL sbal = null;
        List<Student> studList = null;
        Student stud = null;

        //Page Load
        protected void Page_Load(object sender, EventArgs e)
        {

            sbal = new Student_BAL();
            studList = new List<Student>();
            if (!IsPostBack)
            {
                studList = sbal.DisplayStudent();
                ddlStudId.DataSource = studList;
                ddlStudId.DataTextField = "StudentID";
                DataBind();
            }
        }

        //Search Student
        protected void btnStudentSearch_Click(object sender, EventArgs e)
        {
            stud = new Student();
            try
            {
                int id = 0;
                string sid = ddlStudId.SelectedItem.ToString();
                if (int.TryParse(sid, out id)) { }
                stud = sbal.SearchStudent(id);
                if (stud.StudentID > 0)
                {
                    btnDeleteStudent.Enabled = true;
                    btnUpdateStudent.Enabled = true;
                    txtAddress.Text = stud.Student_address;
                    txtContact.Text = stud.Contact;
                    txtStudName.Text = stud.StudentName;
                    txtDOB.Text = stud.DOB.ToString("yyyy-MM-dd");
                    ddlBG.SelectedValue = stud.BloodGroup;
                    rblGender.SelectedValue = stud.Gender;

                }

            }
            catch
            {

            }
        }

        //Selection Index Changed
        protected void ddlStudId_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnDeleteStudent.Enabled = false;
            btnUpdateStudent.Enabled = false;
            txtAddress.Text = "";
            txtContact.Text = "";
            txtStudName.Text = "";
            txtDOB.Text = "";
            ddlBG.SelectedValue = null;
            rblGender.SelectedValue = null;
        }

        //Update Student
        protected void btnUpdateStudent_Click(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                stud = new Student();
                int id = 0;
                string sid = ddlStudId.SelectedItem.ToString();
                if (int.TryParse(sid, out id)) { }
                stud.StudentID = id;
                stud.StudentName = txtStudName.Text;
                stud.Gender = rblGender.SelectedItem.ToString();
                stud.BloodGroup = ddlBG.SelectedItem.ToString();
                stud.Contact = txtContact.Text;
                stud.DOB = Convert.ToDateTime(txtDOB.Text);
                stud.Student_address = txtAddress.Text;
                recordsAffected = sbal.UpdateStudent(stud);
                if (recordsAffected > 0)
                {
                    lblSuccess.Text = "Student Updated Successfully with id " + id;
                }
                else
                    throw new Student_Exception("<script>alert('Student Details are not Successfully Updated')</script>");

            }
            catch (Student_Exception ex)
            {

                Response.Write("<script>alert('" + ex.Message + "')</script>");


            }
            catch (SystemException ex)
            {

                Response.Write("<script>alert('" + ex.Message + " ')</script>");
            }
        }

        //Delete Student
        protected void btnDeleteStudent_Click(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                int id = 0;
                string sid = ddlStudId.SelectedItem.ToString();
                if (int.TryParse(sid, out id)) { }
                recordsAffected = sbal.DeleteStudent(id);
                if (recordsAffected > 0)
                {
                    lblSuccess.Text = "Student Deleted Successfully with id : " + id;

                    //Binding Again After Deleting
                    sbal = new Student_BAL();
                    studList = new List<Student>();

                    studList = sbal.DisplayStudent();
                    ddlStudId.DataSource = studList;
                    ddlStudId.DataTextField = "StudentID";
                    DataBind();
                    btnDeleteStudent.Enabled = false;
                    btnUpdateStudent.Enabled = false;
                    txtAddress.Text = "";
                    txtContact.Text = "";
                    txtStudName.Text = "";
                    txtDOB.Text = "";
                    ddlBG.SelectedValue = null;
                    rblGender.SelectedValue = null;

                }
                else
                    throw new Student_Exception("<script>alert('Student Details are not Successfully Updated')</script>");
            }
            catch (Student_Exception ex)
            {

                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            catch (SystemException ex)
            {

                Response.Write("<script>alert('" + ex.Message + " ')</script>");
            }
        }

    }
}