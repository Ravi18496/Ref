﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.BAL;
using SMS.Exceptions;


namespace WEB.PL
{
    public partial class ForStudent : System.Web.UI.Page
    {
        List<Student> studList = null;
        List<Teacher> teachList = null;
        Student_BAL sbal = null;
        Teacher_BAL tbal = null;
        LoginDetails login = null;
        LoginValidations lbal = null;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            studList = new List<Student>();
            teachList = new List<Teacher>();
            sbal = new Student_BAL();
            tbal = new Teacher_BAL();
            lbal = new LoginValidations();

            if(!IsPostBack)
            {
                string name = ddlStudent.SelectedItem.ToString();

                if (name == "Student")
                {
                    studList = sbal.DisplayStudent();
                    ddlSelectId.DataSource = studList;
                    ddlSelectId.DataTextField = "StudentID";
                    DataBind();

                }
                else
                {
                    teachList = tbal.DisplayTeacher();
                    ddlSelectId.DataSource = teachList;
                    ddlSelectId.DataTextField = "TeacherID";
                    DataBind();
                }

                int id = 0;
                string tsid = ddlSelectId.SelectedItem.ToString();
                if (int.TryParse(tsid, out id)) { }

                lblUserName.Text = "";

                studList = sbal.DisplayStudent();
                foreach (var item in studList)
                {
                    if (id == item.StudentID)
                    {
                        lblUserName.Text = item.StudentName;
                        break;
                    }
                }
                teachList = tbal.DisplayTeacher();
                foreach (var item in teachList)
                {
                    if (id == item.TeacherID)
                    {
                        lblUserName.Text = item.TeacherName;
                        break;
                    }
                }
            }

            
        }

        //Select Index Changed for student and Teacher
        protected void ddlStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnStudPassInsert.Enabled = true;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            txtPassword.Text = "";
            int id = 0;
            string tsid = ddlSelectId.SelectedItem.ToString();
            if (int.TryParse(tsid, out id)) { }

            lblUserName.Text = "";
            string name = ddlStudent.SelectedItem.ToString();
             
                if (name == "Student")
                {
                    studList = sbal.DisplayStudent();
                    ddlSelectId.DataSource = studList;
                    ddlSelectId.DataTextField = "StudentID";
                    DataBind();
                }

                else
                {
                    teachList = tbal.DisplayTeacher();
                    ddlSelectId.DataSource = teachList;
                    ddlSelectId.DataTextField = "TeacherID";
                    DataBind();                    

                }

                foreach (var item in teachList)
                {
                    if (id == item.TeacherID)
                    {
                        lblUserName.Text = item.TeacherName;
                        break;
                    }
                }
                foreach (var item in studList)
                {
                    if (id == item.StudentID)
                    {
                        lblUserName.Text = item.StudentName;
                        break;
                    }
                }
            
            
        }

        //UserName with Respective to the Student ID // Teacher ID
        protected void ddlSelectId_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnStudPassInsert.Enabled = true;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
            txtPassword.Text = "";
            int id = 0;
            string tsid = ddlSelectId.SelectedItem.ToString();
            if (int.TryParse(tsid, out id)) { }

            lblUserName.Text = "";

            studList = sbal.DisplayStudent();
            foreach (var item in studList)
            {
                if(id==item.StudentID)
                {
                    lblUserName.Text = item.StudentName;
                    break;
                }
            }
            teachList = tbal.DisplayTeacher();
            foreach (var item in teachList)
            {
                if(id==item.TeacherID)
                {
                    lblUserName.Text = item.TeacherName;
                    break;
                }
            }

            
        }

        protected void btnStudPassInsert_Click(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            login = new LoginDetails();
            int id = 0;
            string sid = ddlSelectId.SelectedItem.ToString();
            if (int.TryParse(sid, out id)) { }
            login.UserID = id;
            login.Password = txtPassword.Text;
            try
            {
                recordsAffected = lbal.InsertLogin(login);
                if (recordsAffected > 0)
                {
                    lblSuccess.Text = "Details are successfully Inserted with User ID : " + login.UserID;
                }
                else
                    throw new Student_Exception("<script>alert('Details are not Successfully Inserted')</script>");
            }
            catch(Login_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            catch(SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            login = new LoginDetails();
            int id = 0;
            string sid = ddlSelectId.SelectedItem.ToString();
            if (int.TryParse(sid, out id)) { }
            login.UserID = id;
            login.Password = txtPassword.Text;
            try
            {
                recordsAffected = lbal.UpdateLogin(login);
                if (recordsAffected > 0)
                {
                    lblSuccess.Text = "Details are successfully Updated with User ID : " + login.UserID;
                }
                else
                    throw new Student_Exception("<script>alert('Details are not Updated')</script>");
            }
             catch(Login_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            catch(SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            int id = 0;
            string tsid = ddlSelectId.SelectedItem.ToString();
            if (int.TryParse(tsid, out id)) { }
            try
            {
                recordsAffected = lbal.DeleteLogin(id);
                if (recordsAffected > 0)
                {
                    lblSuccess.Text = "Details are Successfully deleted with Id : " + id;
                    lblUserName.Text = "";
                    txtPassword.Text = "";
                    string name = ddlStudent.SelectedItem.ToString();

                    if (name == "Student")
                    {
                        studList = sbal.DisplayStudent();
                        ddlSelectId.DataSource = studList;
                        ddlSelectId.DataTextField = "StudentID";
                        DataBind();

                    }
                    else
                    {
                        teachList = tbal.DisplayTeacher();
                        ddlSelectId.DataSource = teachList;
                        ddlSelectId.DataTextField = "TeacherID";
                        DataBind();
                    }
                }
                else
                    throw new Student_Exception("<script>alert(' Details are not Deleted')</script>");
            }
            catch(Login_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            catch(SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
        }

        //Search Method
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            login = new LoginDetails();            
            int id = 0;
            string tsid = ddlSelectId.SelectedItem.ToString();
            if (int.TryParse(tsid, out id)) { }
            try
            {
                login = lbal.SearchLogin(id);
                if (login.UserID > 0)
                {
                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = true;
                    txtPassword.Text = login.Password;
                    btnStudPassInsert.Enabled = false;
                }
                else
                    throw new Student_Exception("<script>alert(' Details are not Deleted')</script>");
            }
            catch (Login_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
        }

    }
}