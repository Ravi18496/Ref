﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace WEB.PL
{
    public partial class StudInsert : System.Web.UI.Page
    {
        Student_BAL sbal = null;
        List<Student> studList = null;
        Student stud = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblSuccess.Text = "";
            sbal = new Student_BAL();
            studList = new List<Student>();

        }

        protected void btnInsertStudent_Click(object sender, EventArgs e)
        {
            lblSuccess.Text = "";
            int recordsAffected = 0;
            try
            {
                stud = new Student();
                stud.StudentName = txtStudName.Text;
                stud.Gender = rblGender.SelectedItem.ToString();
                stud.BloodGroup = ddlBG.SelectedItem.ToString();
                stud.Contact = txtContact.Text;
                stud.DOB = Convert.ToDateTime(txtDOB.Text);
                stud.Student_address = txtAddress.Text;
                recordsAffected = sbal.InsertStudent(stud);

                if (recordsAffected > 0)
                {
                    lblSuccess.Text = "Student Created Successfully with id " + recordsAffected;
                }
                else
                    throw new Student_Exception("<script>alert('Student Details are not Successfully Inserted')</script>");

            }
            catch (Student_Exception ex)
            {

                Response.Write("<script>alert('" + ex.Message + "')</script>");


            }
            catch (SystemException ex)
            {

                Response.Write("<script>alert('" + ex.Message + " ')</script>");
            }
        }

    }
}