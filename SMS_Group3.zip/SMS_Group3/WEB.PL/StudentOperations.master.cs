﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;


namespace WEB.PL
{
    public partial class StudentOperations : System.Web.UI.MasterPage
    {
        List<Student> slist = null;
        StudOperations_BAL sbal = new StudOperations_BAL();
        Student_BAL sbal1 = new Student_BAL();

        protected void Page_Load(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Session["userid"]);
            slist = sbal.GetAll();
            foreach (var item in slist)
            {
                if(item.StudentID == id)
                {
                    lblStudName.Text = "Hello " + item.StudentName;
                    break;
                }
            }
        }
    }
}