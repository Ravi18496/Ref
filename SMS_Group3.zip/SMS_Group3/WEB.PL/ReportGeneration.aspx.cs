﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;


namespace WEB.PL
{
    public partial class ReportGeneration : System.Web.UI.Page
    {
        Cash_BAL c = new Cash_BAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            List<Fees> feeList = new List<Fees>();
            feeList = c.DisplayAll();
            var res = from f in feeList
                      where f.Fees_amount < 30000
                      select f;
            foreach (var item in res.ToList())
            {
                item.Fees_amount = 30000 - item.Fees_amount;
            }
            gvFeeAmount.DataSource = res.ToList();
            gvFeeAmount.DataBind();
        }
    }
}