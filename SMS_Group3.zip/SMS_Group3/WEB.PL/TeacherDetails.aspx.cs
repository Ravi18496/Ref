﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace WEB.PL
{
    public partial class TeacherDetails : System.Web.UI.Page
    {
        Teacher teach = new Teacher() ;
        Teacher_BAL tbal = new Teacher_BAL();
        List<Teacher> teachList = new List<Teacher>(); 

        protected void Page_Load(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Session["userid"]);
            teachList = tbal.DisplayTeacher();
            foreach (var item in teachList)
            {
                if(item.TeacherID == id)
                {
                    txtId.Text = item.TeacherID.ToString();
                    txtName.Text = item.TeacherName;
                    txtEmail.Text = item.Email;
                    txtContact.Text = item.Contact;
                    txtAddress.Text = item.Address_Teacher;
                    rblGender.SelectedValue = item.Gender;
                    cal.VisibleDate = item.DOB;
                    cal.SelectedDate = item.DOB;
                }
            }
        }

        protected void btnUpdateTeacher_Click(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                teach.TeacherID = Convert.ToInt32(txtId.Text);
                teach.TeacherName = txtName.Text;
                teach.Gender = rblGender.SelectedItem.ToString();
                teach.Email = txtEmail.Text;
                teach.DOB = cal.SelectedDate;
                teach.Contact = txtContact.Text;
                teach.Address_Teacher = txtAddress.Text;
                recordsAffected = tbal.UpdateTeacher(teach);

                if (recordsAffected > 0)
                {
                    lblSuccess.Text = "Teacher Updated Successfully with id " + teach.TeacherID;
                }
                else
                    throw new Student_Exception("<script>alert('Teacher Details are not Successfully Updated')</script>");

            }
            catch (Teacher_Exception ex)
            {

                Response.Write("<script>alert('" + ex.Message + "')</script>");


            }
            catch (SystemException ex)
            {

                Response.Write("<script>alert('" + ex.Message + " ')</script>");
            }
        }
    }
}