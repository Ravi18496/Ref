﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace WEB.PL
{
    public partial class GiveGrade : System.Web.UI.Page
    {
        Marks_BAL mbal = new Marks_BAL();
        
        AssigningTeacher_BAL atbal = new AssigningTeacher_BAL();
        List<Marks> mlist = new List<Marks>();
        List<AssigningTeacher> aslist = new List<AssigningTeacher>();

        protected void Page_Load(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(Session["userid"]);
            aslist = atbal.GetAll();
            foreach (var item in aslist)
            {
                if(item.TeacherID == id)
                {
                    lblCid.Text = item.ClassID.ToString();
                    lbltid.Text = item.TeacherID.ToString();
                    break;
                }
            }

            List<AssigningTeacher> atl = new List<AssigningTeacher>();
            foreach (var item in aslist)
            {
                if(item.TeacherID == id)
                {
                    atl.Add(item);
                }
            }

            ddlStudentID.DataSource = atl;
            ddlStudentID.DataTextField = "StudentID";
            ddlStudentID.DataBind();

            mlist = mbal.GetAll();
            List<Marks> ml = new List<Marks>();
            foreach (var item in mlist)
            {
                if(item.TeacherID == id)
                {
                    ml.Add(item);
                }
            }

            if (!IsPostBack)
            {
                ddlMarkID.DataSource = ml;
                ddlMarkID.DataTextField = "MarksID";
                ddlMarkID.DataBind();
            }
        }

        protected void btnPost_Click(object sender, EventArgs e)
        {

            int recordsAffected = 0;
            
            try
            {
                Marks m = new Marks();
                m.ClassID = Convert.ToInt32(lblCid.Text);
                m.TeacherID = Convert.ToInt32(lbltid.Text);
                m.StudentID = Convert.ToInt32(ddlStudentID.Text);
                m.Mathematics = Convert.ToInt32(txtMaths.Text);
                m.Science = Convert.ToInt32(txtScience.Text);
                m.English = Convert.ToInt32(txtSocial.Text);
                m.Percentage = Convert.ToDecimal((m.Mathematics + m.Science + m.English)/3);
                recordsAffected = mbal.InsertMarks(m);
                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Successfully')</script>");
                }
                else
                    throw new Student_Exception("<script>alert('Student Details are not Successfully Inserted')</script>");

            }
            catch (Student_Exception ex)
            {

                Response.Write("<script>alert('" + ex.Message + "')</script>");


            }
            catch (SystemException ex)
            {

                Response.Write("<script>alert('" + ex.Message + " ')</script>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            int recordsAffected = 0;

            try
            {
                Marks m = new Marks();
                m.MarksID = Convert.ToInt32(ddlMarkID.Text);
                m.ClassID = Convert.ToInt32(lblCid.Text);
                m.TeacherID = Convert.ToInt32(lbltid.Text);
                m.StudentID = Convert.ToInt32(ddlStudentID.Text);
                m.Mathematics = Convert.ToInt32(txtMaths.Text);
                m.Science = Convert.ToInt32(txtScience.Text);
                m.English = Convert.ToInt32(txtSocial.Text);
                m.Percentage = Convert.ToDecimal((m.Mathematics + m.Science + m.English) / 3);
                m.MarksID = Convert.ToInt32(ddlMarkID.Text);
                recordsAffected = mbal.UpdateMarks(m);
                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Successfully')</script>");
                }
                else
                    throw new Student_Exception("<script>alert('Student Details are not Successfully Inserted')</script>");

            }
            catch (Student_Exception ex)
            {

                Response.Write("<script>alert('" + ex.Message + "')</script>");


            }
            catch (SystemException ex)
            {

                Response.Write("<script>alert('" + ex.Message + " ')</script>");
            }

        }

        protected void ddlMarkID_SelectedIndexChanged(object sender, EventArgs e)
        {
            int x = Convert.ToInt32(ddlMarkID.Text);
            mlist = mbal.GetAll();
            foreach (var item in mlist)
            {
                if(item.MarksID == x)
                {
                    txtMaths.Text = item.Mathematics.ToString();
                    txtScience.Text = item.Science.ToString();
                    txtSocial.Text = item.English.ToString();
                    break;
                }
            }
        }
    }
}