﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.BAL;
using SMS.Entities;

namespace WEB.PL
{
    public partial class CMUser : System.Web.UI.Page
    {
        List<LoginDetails> loginList = null;
        LoginValidations lbal = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            lbal = new LoginValidations();
            loginList = new List<LoginDetails>();
            loginList = lbal.DisplayLogin();
            dgvlogin.DataSource = loginList;
            DataBind();
        }
    }
}