﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.BAL;
using SMS.Exceptions;

namespace WEB.PL
{
    public partial class AdminStudent : System.Web.UI.Page
    {
        Student_BAL sbal = null;
        List<Student> studList = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            sbal = new Student_BAL();
            studList = new List<Student>();
            studList = sbal.DisplayStudent();
            dgvStudent.DataSource = studList;
            DataBind();

        }
    }
}