﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;
using System.Collections;

namespace WEB.PL
{
    public partial class GiveAttendence : System.Web.UI.Page
    {
        Attendence_BAL abal = new Attendence_BAL();
        Student_BAL sbal = new Student_BAL();
        ArrayList al = new ArrayList();
        List<Student> stdList = new List<Student>();
        List<Attendence> attList = new List<Attendence>();

        protected void Page_Load(object sender, EventArgs e)
        {
               if(!IsPostBack)
               {
                   stdList = sbal.DisplayStudent();
                   ddlStudentID.DataSource = stdList;
                   ddlStudentID.DataTextField = "StudentID";
                   ddlStudentID.DataBind();

                   attList = abal.GetAll();
                   ddlAttendenceID.DataSource = attList;
                   ddlAttendenceID.DataTextField = "AttendenceID";
                   ddlAttendenceID.DataBind();
               }
        }

        protected void btnPost_Click(object sender, EventArgs e)
        {
            int posted;
            Attendence att = new Attendence();
            try
            {
                att.Today_Date = cal.SelectedDate;
                int sid = 0;
                sid = Convert.ToInt32(ddlStudentID.Text);
                att.StudentID = sid;
                att.Attended = Convert.ToChar(ddlAttended.Text);
                posted = abal.InsertAttendence(att);
                if(posted > 0)
                {
                    Response.Write("<script>alert('Posted!!');</script>");
                }
                else
                {
                    Response.Write("<script>alert('Not Posted!!');</script>");
                }
            }
            catch(Attendence_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch(SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void ddlStudentID_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(ddlStudentID.Text);
            attList = abal.GetAll();
            foreach (var item in attList)
            {
                if(item.StudentID == id)
                {
                    ddlAttendenceID.Text = item.AttendenceID.ToString();
                    cal.VisibleDate = item.Today_Date;
                    cal.SelectedDate = item.Today_Date;
                    break;
                }
            }
        }
    }
}