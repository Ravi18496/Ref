﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.BAL;
using SMS.Entities;
using SMS.Exceptions;

namespace WEB.PL
{
    public partial class TeacherHome : System.Web.UI.Page
    {
        List<Teacher> teachList = null;
        Teacher_BAL tbal = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            teachList = new List<Teacher>();
            tbal = new Teacher_BAL();
            teachList = tbal.DisplayTeacher();
            dgvTeacher.DataSource = teachList;
            DataBind();
        }
    }
}