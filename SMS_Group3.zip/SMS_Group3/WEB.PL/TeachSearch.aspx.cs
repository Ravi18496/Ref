﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace WEB.PL
{
    public partial class TeachSearch : System.Web.UI.Page
    {
        Teacher teach = null;
        Teacher_BAL tbal = null;
        List<Teacher> teachList = null;
        //Page Load
        protected void Page_Load(object sender, EventArgs e)
        {
            teach = new Teacher();
            teachList = new List<Teacher>();
            tbal = new Teacher_BAL();
            if (!IsPostBack)
            {
                teachList = tbal.DisplayTeacher();
                ddlTeachId.DataSource = teachList;
                ddlTeachId.DataTextField = "TeacherID";
                DataBind();
            }

        }

        //DDL Selected Index change
        protected void ddlTeachId_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtName.Text = "";
            txtContact.Text = "";
            txtEmail.Text = "";
            txtDOB.Text = "";
            txtAddress.Text = "";
            rblGender.SelectedValue = null;
            btnUpdateTeacher.Enabled = false;
            btnDeleteTeacher.Enabled = false;
        }

        //Search Teacher
        protected void btnTeacherSearch_Click(object sender, EventArgs e)
        {
            teach = new Teacher();
            try
            {
                int id = 0;
                string tid = ddlTeachId.SelectedItem.ToString();
                if (int.TryParse(tid, out id)) { }
                teach = tbal.SearchTeacher(id);
                if (teach.TeacherID > 0)
                {
                    txtAddress.Text = teach.Address_Teacher;
                    txtContact.Text = teach.Contact;
                    txtDOB.Text = teach.DOB.ToString("yyyy-MM-dd");
                    txtEmail.Text = teach.Email;
                    txtName.Text = teach.TeacherName;
                    rblGender.SelectedValue = teach.Gender;
                    btnDeleteTeacher.Enabled = true;
                    btnUpdateTeacher.Enabled = true;
                }
            }
            catch (SystemException ex)
            {

            }
        }

        //Delete Teacher
        protected void btnDeleteTeacher_Click(object sender, EventArgs e)
        {

            try
            {
                int id = 0;
                string tid = ddlTeachId.SelectedItem.ToString();
                if (int.TryParse(tid, out id)) { }
                int recordsAffected = tbal.DeleteTeacher(id);
                if (recordsAffected > 0)
                {
                    lblSuccess.Text = "Teacher Details are successfully Deleted With Id : " + id;
                    //Rebinding the Dropdown List again.
                    teach = new Teacher();
                    teachList = new List<Teacher>();
                    tbal = new Teacher_BAL();

                    teachList = tbal.DisplayTeacher();
                    ddlTeachId.DataSource = teachList;
                    ddlTeachId.DataTextField = "TeacherID";
                    DataBind();
                    //Removing the data in the Text Fields.
                    txtName.Text = "";
                    txtContact.Text = "";
                    txtEmail.Text = "";
                    txtDOB.Text = "";
                    txtAddress.Text = "";
                    rblGender.SelectedValue = null;
                    btnUpdateTeacher.Enabled = false;
                    btnDeleteTeacher.Enabled = false;

                }
                else
                    throw new Student_Exception("<script>alert('Teacher Details are not Successfully Deleted')</script>");
            }
            catch (Teacher_Exception ex)
            {

                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            catch (SystemException ex)
            {

                Response.Write("<script>alert('" + ex.Message + " ')</script>");
            }
        }

        //Update Teacher
        protected void btnUpdateTeacher_Click(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                int id = 0;
                string tid = ddlTeachId.SelectedItem.ToString();
                if (int.TryParse(tid, out id)) { }
                teach.TeacherID = id;
                teach.TeacherName = txtName.Text;
                teach.Gender = rblGender.SelectedItem.ToString();
                teach.Email = txtEmail.Text;
                teach.DOB = Convert.ToDateTime(txtDOB.Text);
                teach.Contact = txtContact.Text;
                teach.Address_Teacher = txtAddress.Text;
                recordsAffected = tbal.UpdateTeacher(teach);

                if (recordsAffected > 0)
                {
                    lblSuccess.Text = "Teacher Updated Successfully with id " + id;
                }
                else
                    throw new Student_Exception("<script>alert('Teacher Details are not Successfully Updated')</script>");

            }
            catch (Teacher_Exception ex)
            {

                Response.Write("<script>alert('" + ex.Message + "')</script>");


            }
            catch (SystemException ex)
            {

                Response.Write("<script>alert('" + ex.Message + " ')</script>");
            }
        }


    }
}