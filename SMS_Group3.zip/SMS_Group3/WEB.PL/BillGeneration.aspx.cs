﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;
using System.Collections;

namespace WEB.PL
{
    public partial class BillGeneration : System.Web.UI.Page
    {
        Cash_BAL c = new Cash_BAL();
        Student_BAL sbal = new Student_BAL();
        ArrayList al = new ArrayList();
        ArrayList al1 = new ArrayList();
        List<Student> stdList = new List<Student>();
        List<Fees> feelist = new List<Fees>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                stdList = sbal.DisplayStudent();
                //foreach (var item in stdList)
                //{
                //    al.Add(item.StudentID);
                //}
                ddlStudentID.DataSource = stdList;
                ddlStudentID.DataTextField = "StudentID";
                //ddlStudentID.DataValueField = "StudentID";
                ddlStudentID.DataBind();

                feelist = c.DisplayAll();
                //foreach (var item in feelist)
                //{
                //    al1.Add(item.InvoiceID);
                //}
                ddlInvoiceID.DataSource = feelist;
                ddlInvoiceID.DataTextField = "InvoiceID";
                ddlInvoiceID.DataBind();
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            int inserted = 0;
            Fees fee = new Fees();
            try
            {
                fee.Payment_Date = Convert.ToDateTime(cal.SelectedDate);
                int sid = 0;
                sid = Convert.ToInt32(ddlStudentID.Text);
                fee.StudentID = sid;
                int aid = 0;
                if (int.TryParse(txtFeeAmount.Text, out aid)) { }
                fee.Fees_amount = aid;
                inserted = c.Insert(fee);
                if(inserted > 0)
                {
                    Response.Write("<script>alert('Inserted!!');</script>");
                }
                else
                    Response.Write("<script>alert('Not Inserted');</script>");
            }
            catch (Fees_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            bool updated = false;
            Fees fee = new Fees();
            try
            {
                fee.Payment_Date = Convert.ToDateTime(cal.SelectedDate);
                int sid = 0;
                sid = Convert.ToInt32(ddlStudentID.SelectedValue);
                fee.StudentID = sid;
                int aid = 0;
                if (int.TryParse(txtFeeAmount.Text, out aid)) { }
                fee.Fees_amount = aid;
                updated = c.Update(fee);
                if (updated)
                {
                    Response.Write("<script>alert('Updated!!');</script>");
                }
                else
                    Response.Write("<script>alert('Not Updated');</script>");
            }
            catch (Fees_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void ddlStudentID_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(ddlStudentID.Text);
            feelist = c.DisplayAll();
            foreach (var item in feelist)
            {
                if(item.StudentID == id)
                {
                    ddlInvoiceID.Text = item.InvoiceID.ToString();
                    cal.VisibleDate = item.Payment_Date;
                    cal.SelectedDate = item.Payment_Date;
                    txtFeeAmount.Text = item.Fees_amount.ToString();
                    break;
                }
            }
        }
    }
}