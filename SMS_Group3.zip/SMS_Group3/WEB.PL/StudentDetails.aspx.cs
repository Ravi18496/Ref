﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace WEB.PL
{
    public partial class StudentDetails : System.Web.UI.Page
    {
        List<Student> slist = null;
        StudOperations_BAL sbal=new StudOperations_BAL();
        Student_BAL sbal1 = new Student_BAL();
        


        protected void Page_Load(object sender, EventArgs e)
        {
            int id = 0;
            id = Convert.ToInt32(Session["userid"]);
            slist = new List<Student>();
            slist = sbal.GetAll();
            
            foreach (var item in slist)
            {
                if (id == item.StudentID)
                {
                    txtId.Text = Convert.ToString(item.StudentID);
                    txtStudName.Text = item.StudentName;
                    rblGender.Text = item.Gender;
                    txtdob.Text = item.DOB.ToString("yyyy-MM-dd");
                    txtBlood.Text = item.BloodGroup;
                    txtContact.Text = item.Contact;
                    txtAddress.Text = item.Student_address;
                    break;
                }
            }
        }

        protected void ddlStudId_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
}