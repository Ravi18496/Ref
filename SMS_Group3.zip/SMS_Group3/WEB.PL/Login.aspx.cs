﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;


namespace WEB.PL
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Master.Logout = false;
            //Master.Menu = false;
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                LoginDetails user = new LoginDetails();
                LoginValidations lv = new LoginValidations();
                user.UserID = Convert.ToInt32(txtUserID.Text);
                user.Password = txtPassword.Text;
                int userid = lv.AdminLogin(user);
                int count = 0;
                int a = userid;
                while(a>0)
                {
                    a=a/10;
                    count=count+1;
                }

                if (userid == 1)
                {
                    Response.Redirect("AdminHome.aspx");
                }
                else if (userid == 2)
                {
                    Response.Redirect("BillGeneration.aspx");
                }
                else if (count == 3)
                {
                    Session["userid"] = userid;
                    Response.Redirect("TeacherDetails.aspx"); 
                }
                else if (count == 4)
                {
                    Session["userid"] = userid;
                    Response.Redirect("StudentDetails.aspx"); 
                }
                else
                    lblError.Text = "Invalid UserId/Password";
                

            }
            catch (Login_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}