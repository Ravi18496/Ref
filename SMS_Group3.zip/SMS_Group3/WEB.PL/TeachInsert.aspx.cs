﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;


namespace WEB.PL
{
    public partial class TeachInsert : System.Web.UI.Page
    {
        Teacher teach = null;
        Teacher_BAL tbal = null;


        protected void Page_Load(object sender, EventArgs e)
        {
            teach = new Teacher();
            tbal = new Teacher_BAL();
        }

        //Teacher Insert
        protected void btnInsertTeacher_Click(object sender, EventArgs e)
        {
            int recordsAffected = 0;
            try
            {
                teach.TeacherName = txtName.Text;
                teach.Gender = rblGender.SelectedItem.ToString();
                teach.Email = txtEmail.Text;
                teach.DOB = Convert.ToDateTime(txtDOB.Text);
                teach.Contact = txtContact.Text;
                teach.Address_Teacher = txtAddress.Text;
                recordsAffected = tbal.InsertTeacher(teach);

                if (recordsAffected > 0)
                {
                    lblSuccess.Text = "Teacher Created Successfully with id " + recordsAffected;
                }
                else
                    throw new Student_Exception("<script>alert('Teacher Details are not Successfully Inserted')</script>");

            }
            catch (Teacher_Exception ex)
            {

                Response.Write("<script>alert('" + ex.Message + "')</script>");


            }
            catch (SystemException ex)
            {

                Response.Write("<script>alert('" + ex.Message + " ')</script>");
            }
        }
    }
}