﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using SMS.Entities;
using SMS.Exceptions;

namespace SMS.DAL
{
    public class TeacherOpearations
    {
        SqlCommand cmd = null;
        SqlConnection cn = null;
        SqlDataReader dr = null;

        public TeacherOpearations()
        {
            string constr = @"Data Source=ndamssql\sqlilearn;Initial Catalog=Training_13Dec17_Hinjawadi_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser";
            cn = new SqlConnection(constr);
        }

        public List<Teacher> Select()
        {
            List<Teacher> tealist = new List<Teacher>();
            try
            {
                cmd = new SqlCommand("Teacher_Select", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Teacher tea = new Teacher();
                    tea.TeacherID = Convert.ToInt32(dr[0]);
                    tea.TeacherName = Convert.ToString(dr[1]);
                    tea.Gender = Convert.ToString(dr[2]);
                    tea.DOB = Convert.ToDateTime(dr[3]);
                    tea.Contact = Convert.ToString(dr[4]);
                    tea.Email = Convert.ToString(dr[5]);
                    tea.Address_Teacher = Convert.ToString(dr[6]);
                    tealist.Add(tea);
                }
                return tealist;
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }

        }
    }
}
