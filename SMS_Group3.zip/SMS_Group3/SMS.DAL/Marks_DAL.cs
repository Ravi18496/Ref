﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using System.Data;
using System.Data.SqlClient;

namespace SMS.DAL
{
    public class Marks_DAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public Marks_DAL()
        {
            string cnStr = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_13Dec17_Hinjawadi_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser";
            cn = new SqlConnection(cnStr);
        }

        public List<Marks> SelectAll()
        {
            List<Marks> mark = new List<Marks>();

            try
            {
                cmd = new SqlCommand("Marks_Select", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Marks mrk = new Marks();
                    mrk.MarksID = (int)dr[0];
                    mrk.ClassID = (int)dr[1];
                    mrk.TeacherID = (int)dr[2];
                    mrk.StudentID = (int)dr[3];
                    mrk.English = (int)dr[4];
                    mrk.Mathematics = (int)dr[5];
                    mrk.Science = (int)dr[6];
                    mrk.Percentage = Convert.ToDecimal(dr[7]);

                    mark.Add(mrk);
                }
            }
            catch (Marks_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return mark;
        }

        //public List<Grade> TeacherSelectAll()
        //{
        //    List<Grade> grad = new List<Grade>();

        //    try
        //    {
        //        cmd = new SqlCommand("Grade_Select", cn);
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //        cn.Open();
        //        dr = cmd.ExecuteReader();
        //        while (dr.Read())
        //        {
        //            Grade grd = new Grade();
        //            grd.ClassID = (int)dr[0];
        //            //grd.GradeName = dr[1].ToString();
        //            //grd.Description_Grade = dr[2].ToString();
        //            //grd.Marks1 = (int)dr[3];
        //            //grd.Marks2 = (int)dr[4];
        //            //grd.Marks3 = (int)dr[5];
        //            grd.StudentID = (int)dr[6];
        //            grd.TeacherID = Convert.ToInt32(dr[7]);

        //            grad.Add(grd);
        //        }
        //    }
        //    catch (Grade_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        dr.Close();
        //        cn.Close();
        //    }
        //    return grad;
        //}

        //Insert Grade
        public int InsertMarks(Marks mark)
        {
            int recordsAffected = 0;
            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();
                //cmd.CommandText = "USP_InsertEmployee_142743v";
                cmd = new SqlCommand("Marks_Insert", cn);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ClassID", mark.ClassID);
                cmd.Parameters.AddWithValue("@TeacherID", mark.TeacherID);
                cmd.Parameters.AddWithValue("@StudentID", mark.StudentID);
                cmd.Parameters.AddWithValue("@English", mark.English);
                cmd.Parameters.AddWithValue("@Mathematics", mark.Mathematics);
                cmd.Parameters.AddWithValue("@Science", mark.Science);
                cmd.Parameters.AddWithValue("@Percentage", mark.Percentage);               
                cn.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Marks_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                cn.Close();
            }
            return recordsAffected;
        }

        //Update Grade
        public int UpdateMarks(Marks mark)
        {
            int recordsAffected = 0;
            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();
                //cmd.CommandText = "USP_UpdateEmployee_142743";

                cmd = new SqlCommand("Marks_Update", cn);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@MarksID", mark.MarksID);
                cmd.Parameters.AddWithValue("@ClassID", mark.ClassID);
                cmd.Parameters.AddWithValue("@TeacherID", mark.TeacherID);
                cmd.Parameters.AddWithValue("@StudentID", mark.StudentID);
                cmd.Parameters.AddWithValue("@English", mark.English);
                cmd.Parameters.AddWithValue("@Mathematics", mark.Mathematics);
                cmd.Parameters.AddWithValue("@Science", mark.Science);
                cmd.Parameters.AddWithValue("@Percentage", mark.Percentage);

                //cmd.Parameters.AddWithValue("@TeacherID", grade.TeacherID);

                cn.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;

            }
            catch (Marks_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                cn.Close();
            }

            return recordsAffected;
        }

        public int DeleteMarks(int mid)
        {
            int recordsAffected = 0;

            try
            {

                cmd = new SqlCommand("Marks_Delete", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MarksID", mid);
                cn.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Marks_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return recordsAffected;
        }
    }
}
