﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using SMS.Entities;
using SMS.Exceptions;

namespace SMS.DAL
{
    public class CreateAndManage_DAL
    {
        //SqlConnection con = null;
        //SqlCommand cmd = null;
        //SqlDataReader dr = null;

        //public CreateAndManage_DAL()
        //{
        //    string constr = ConfigurationManager.ConnectionStrings["con1"].ConnectionString;

        //    con = new SqlConnection(constr);
        //}
        
        ////Teacher Login Insert Method
        //public int InsertTeacherLogin(LoginDetails ld)
        //{
        //    int recordsAffected = 0;
        //    try
        //    {
        //        cmd = new SqlCommand("TeacherLoginInsert", con);
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        //        cmd.Parameters.AddWithValue("@TeacherID", ld.TeacherID);
        //        cmd.Parameters.AddWithValue("@UserTeacher", ld.UserTeacher);
        //        cmd.Parameters.AddWithValue("@PassTeacher", ld.PassTeacher);
                
        //        con.Open();
        //        recordsAffected = cmd.ExecuteNonQuery();


        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {

        //        con.Close();
        //    }
        //    return recordsAffected;
        //}

        ////Teacher Update  Login method
        //public int UpdateTeacherLogin(LoginDetails ld)
        //{
        //    int recordsAffected = 0;
        //    try
        //    {
        //        cmd = new SqlCommand("TeacherLoginUpdate", con);    //for stored procedure
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        //        cmd.Parameters.AddWithValue("@TeacherID", ld.TeacherID);
        //        cmd.Parameters.AddWithValue("@UserTeacher", ld.UserTeacher);
        //        cmd.Parameters.AddWithValue("@PassTeacher", ld.PassTeacher);
                
        //        con.Open();
        //        recordsAffected = cmd.ExecuteNonQuery();


        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;

        //    }
        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {

        //        con.Close();
        //    }

        //    return recordsAffected;
        //}

        ////Teacher Login Delete Method
        //public int DeleteTeacherLogin(int tid)
        //{
        //    int recordsAffected = 0;

        //    try
        //    {

        //        cmd = new SqlCommand("TeacherLoginDelte", con);
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@TeacherID", tid);
        //        con.Open();
        //        recordsAffected = cmd.ExecuteNonQuery();


        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //    return recordsAffected;
        //}

        ////Tacher Login Details Display Method
        //public List<TeacherLogin> DisplayTeacherLogin()
        //{
        //    List<TeacherLogin> ldList = new List<TeacherLogin>();
        //    try
        //    {
        //        cmd = new SqlCommand("TeacherLoginDisplay", con);
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        //        con.Open();
        //        dr = cmd.ExecuteReader();
        //        while (dr.Read())
        //        {
        //            if (dr.HasRows)
        //            {
        //                TeacherLogin ld = new TeacherLogin();
        //                ld.TeacherID = (int)dr["TeacherID"];
        //                ld.UserTeacher = dr["UserName"].ToString();
        //                ld.PassTeacher = dr["Password"].ToString();
                        
        //                ldList.Add(ld);
        //            }
        //            else
        //                throw new CreateAndManage_Exception("Records are not available");
        //        }
        //    }

        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        dr.Close();
        //        con.Close();
        //    }
        //    return ldList;

        //}

        ////Student Login Insert Method
        //public int InsertStudentLogin(LoginDetails ld)
        //{
        //    int recordsAffected = 0;
        //    try
        //    {
        //        cmd = new SqlCommand("StudentLoginInsert", con);
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        //        cmd.Parameters.AddWithValue("@StudentID", ld.StudentId);
        //        cmd.Parameters.AddWithValue("@UserStudent", ld.UserStudent);
        //        cmd.Parameters.AddWithValue("@PassStudent", ld.PassStudent);

        //        con.Open();
        //        recordsAffected = cmd.ExecuteNonQuery();


        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {

        //        con.Close();
        //    }
        //    return recordsAffected;
        //}

        ////Student Login Update Method
        //public int UpdateStudentLogin(LoginDetails ld)
        //{
        //    int recordsAffected = 0;
        //    try
        //    {
        //        cmd = new SqlCommand("StudentLoginUpdate", con);    //for stored procedure
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        //        cmd.Parameters.AddWithValue("@StudentID", ld.StudentId);
        //        cmd.Parameters.AddWithValue("@UserStudent", ld.UserStudent);
        //        cmd.Parameters.AddWithValue("@PassStudent", ld.PassStudent);

        //        con.Open();
        //        recordsAffected = cmd.ExecuteNonQuery();


        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;

        //    }
        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {

        //        con.Close();
        //    }

        //    return recordsAffected;
        //}

        ////Student Login details Delete Method
        //public int DeleteStudentLogin(int sid)
        //{
        //    int recordsAffected = 0;

        //    try
        //    {

        //        cmd = new SqlCommand("StudentLoginDelete", con);
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //        cmd.Parameters.AddWithValue("@StudentID", sid);
        //        con.Open();
        //        recordsAffected = cmd.ExecuteNonQuery();


        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //    return recordsAffected;
        //}

        ////Student Login Details Display method
        //public List<StudentLogin> DisplayStudentLogin()
        //{
        //    List<StudentLogin> ldList = new List<StudentLogin>();
        //    try
        //    {
        //        cmd = new SqlCommand("StudentLoginDisplay", con);
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        //        con.Open();
        //        dr = cmd.ExecuteReader();
        //        while (dr.Read())
        //        {
        //            if (dr.HasRows)
        //            {
        //                StudentLogin ld = new StudentLogin();
        //                ld.StudentId = (int)dr["StudentID"];
        //                ld.UserStudent = dr["UserName"].ToString();
        //                ld.PassStudent = dr["Password"].ToString();

        //                ldList.Add(ld);
        //            }
        //            else
        //                throw new CreateAndManage_Exception("Records are not available");
        //        }
        //    }

        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        dr.Close();
        //        con.Close();
        //    }
        //    return ldList;

        //}


        





        
        
    }
}
