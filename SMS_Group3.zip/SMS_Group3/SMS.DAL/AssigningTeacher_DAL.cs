﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using System.Data;


namespace SMS.DAL
{
    public class AssigningTeacher_DAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        public AssigningTeacher_DAL()
        {
            string cnStr = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_13Dec17_Hinjawadi_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser";
            cn = new SqlConnection(cnStr);
        }

        public List<AssigningTeacher> SelectAll()
        {
            List<AssigningTeacher> assign = new List<AssigningTeacher>();

            try
            {
                cmd = new SqlCommand("AssigningTeacher_Select", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    AssigningTeacher assg = new AssigningTeacher();
                    assg.AssigningID = (int)dr[0];
                    assg.ClassID = (int)dr[1];
                    assg.StudentID = (int)dr[2];
                    assg.TeacherID = (int)dr[3];
                   
                 

                    assign.Add(assg);
                }
            }
            catch (AssigningTeacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return assign;
        }

        public int InsertAssingingTeacher(AssigningTeacher assign)
        {
            int recordsAffected = 0;
            try
            {
                //SqlCommand cmd = DataConnection.GenerateCommand();
                //cmd.CommandText = "USP_InsertEmployee_142743v";
                cmd = new SqlCommand("AssigningTeacher_Insert", cn);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@ClassID", assign.ClassID);
                cmd.Parameters.AddWithValue("@StudentID", assign.StudentID);
                cmd.Parameters.AddWithValue("@TeacherID", assign.TeacherID);
            
                cn.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (AssigningTeacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                cn.Close();
            }
            return recordsAffected;
        }

        public int DeleteAssigningTeacher(int asid)
        {
            int recordsAffected = 0;

            try
            {

                cmd = new SqlCommand("AssigningTeacher_Delete", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AssigningID", asid);
                cn.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (AssigningTeacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();
            }
            return recordsAffected;
        }

        public int UpdateAssigningTeacher(AssigningTeacher assign)
        {
            int recordsAffected = 0;
            try
            {
              

                cmd = new SqlCommand("AssigningTeacher_Update", cn);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@ClassID", assign.ClassID);
                cmd.Parameters.AddWithValue("@StudentID", assign.StudentID);
                cmd.Parameters.AddWithValue("@TeacherID", assign.TeacherID);
              
       

                

                cn.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;

            }
            catch (AssigningTeacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                cn.Close();
            }

            return recordsAffected;
        }

    }
}
