﻿using SMS.Entities;
using SMS.Exceptions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.DAL
{
   public class Class_DAL
    {
         
         SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        //Default Constructor for Connection String
        public Class_DAL()
        {
            string constr = ConfigurationManager.ConnectionStrings["con1"].ConnectionString;

            con = new SqlConnection(constr);
        }

        //class Details Insert Method
        public int InsertClass(Class c)
        {
            int recordsAffected = 0;
            try
            {
                cmd = new SqlCommand("Class_Insert", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                //cmd.Parameters.AddWithValue("@ClassID", c.ClassID);
                cmd.Parameters.AddWithValue("@ClassName", c.ClassName);
               
                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                con.Close();
            }
            return recordsAffected;
        }
        public int UpdateClass(Class t)
        {
            int recordsAffected = 0;
            try
            {
                cmd = new SqlCommand("Class_Update", con);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;


              
                cmd.Parameters.AddWithValue("@ClassName", t.ClassName);
               

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();


            }
            catch (SqlException ex)
            {
                throw ex;

            }
            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                con.Close();
            }

            return recordsAffected;
        }
        public int DeleteClass(int cid)
        {
            int recordsAffected = 0;

            try
            {

                cmd = new SqlCommand("Class_Delete", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ClassID", cid);
                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();


            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return recordsAffected;
        }
        public List<Class> DisplayClass()
        {
            List<Class> tList = new List<Class>();
            try
            {
                cmd = new SqlCommand("Class_Select", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                con.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows)
                    {
                        Class t = new Class();
                        t.ClassID = (int)dr["ClassID"];
                        t.ClassName = dr["ClassName"].ToString();
                     

                        tList.Add(t);
                    }
                    else
                        throw new Class_Exception("Records are not available");
                }
            }

            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                con.Close();
            }
            return tList;

        }
      
     
        public List<Class> SearchClass(int tid)
        {
            List<Class> tList = new List<Class>();
            try
            {
                cmd = new SqlCommand("Class_Search", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ClassID", tid);

                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
               Class t = new Class();
                    dr.Read();
                    t.ClassID = (int)dr["ClassID"];
                    t.ClassName = dr["ClassName"].ToString();
                  

                    tList.Add(t);
                }
                else
                    throw new Class_Exception("Records are not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                con.Close();
            }
            return tList;
        }

    }
}
