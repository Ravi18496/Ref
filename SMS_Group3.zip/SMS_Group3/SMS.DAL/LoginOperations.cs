﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using SMS.Entities;
using SMS.Exceptions;

namespace SMS.DAL
{
    public class LoginOperations
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public LoginOperations()
        {
            string constr = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_13Dec17_Hinjawadi_Pune;Persist Security Info=True;User ID=sqluser;Password=sqluser";

            con = new SqlConnection(constr);
        }
        //Validate Login
        public int ValidateLogin(LoginDetails user)
        {

            int userid;
            try
            {
                cmd = new SqlCommand("UDP_LoginSMS", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserID", user.UserID);
                cmd.Parameters.AddWithValue("@Password", user.Password);

                con.Open();
                userid = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();
            }
            catch (Login_Exception ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userid;
        }

        //Insert Login
        public int InsertLogin(LoginDetails user)
        {
            int recordsAffected = 0;

            try
            {
                cmd = new SqlCommand("UDP_LoginSMS_Insert", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Password", user.Password);
                cmd.Parameters.AddWithValue("@UserID", user.UserID);

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();


            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return recordsAffected;
        }

        //Update Login Method
        public int UpdateLogin(LoginDetails user)
        {
            int recordsAffected = 0;

            try
            {
                cmd = new SqlCommand("UDP_LoginSMS_Update", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Password", user.Password);
                cmd.Parameters.AddWithValue("@UserID", user.UserID);

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return recordsAffected;
        }

        //Delete Login Method
        public int DeleteLogin(int userID)
        {
            int recordsAffected = 0;

            try
            {
                cmd = new SqlCommand("UDP_LoginSMS_Delete", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@UserID", userID);

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return recordsAffected;
        }

        //Display All Login Details Method
        public List<LoginDetails> DisplayLogin()
        {
            List<LoginDetails> loginList = new List<LoginDetails>();
            try
            {
                cmd = new SqlCommand("UDP_LoginSMS_DisplayAll", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                con.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows)
                    {
                        LoginDetails login = new LoginDetails();
                        login.SNo = (int)dr["S_no"];
                        login.UserID = (int)dr["UserID"];
                        login.Password = dr["Password"].ToString();


                        loginList.Add(login);
                    }
                    else
                        throw new Login_Exception("Records are not available");
                }
            }
            catch(Login_Exception ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                con.Close();
            }
            return loginList;
        }

        //Search Single Login Details
        public LoginDetails SearchLogin(int id)
        {
            LoginDetails login = new LoginDetails();
            try
            {
                cmd = new SqlCommand("UDP_LoginSMS_Search", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@UserID", id);

                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {

                    dr.Read();
                    login.SNo = (int)dr["S_no"];
                    login.Password = dr["Password"].ToString();
                    login.UserID = (int)dr["UserID"];
                }

                else
                    throw new Login_Exception("Records are not available");
            }
            catch(Login_Exception ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                con.Close();
            }
            return login;
        }

    }
}
