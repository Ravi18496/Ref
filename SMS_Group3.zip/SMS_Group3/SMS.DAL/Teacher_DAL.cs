﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using SMS.Entities;
using SMS.Exceptions;
using System.Data;

namespace SMS.DAL
{
    /// <summary>
    /// This class is for Teacher CRUD Operations
    /// </summary>
   public class Teacher_DAL
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        //Default Constructor for Connection String
        public Teacher_DAL()
        {
            string constr = ConfigurationManager.ConnectionStrings["con1"].ConnectionString;

            con = new SqlConnection(constr);
        }

        //Teacher Details Insert Method
        public int InsertTeacher(Teacher t)
        {
            int recordsAffected = 0;
            try
            {
                cmd = new SqlCommand("Teacher_Insert", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                //cmd.Parameters.AddWithValue("@TeacherID", t.TeacherID);
                cmd.Parameters.AddWithValue("@TeacherName", t.TeacherName);
                cmd.Parameters.AddWithValue("@Gender", t.Gender);
                cmd.Parameters.AddWithValue("@DOB", t.DOB);
                cmd.Parameters.AddWithValue("@Contact", t.Contact);
                cmd.Parameters.AddWithValue("@Email", t.Email);
                cmd.Parameters.AddWithValue("@Address_Teacher", t.Address_Teacher);
                cmd.Parameters.AddWithValue("@TID", SqlDbType.Int).Direction = ParameterDirection.Output;

                con.Open();
                cmd.ExecuteNonQuery();
                string primarykey = cmd.Parameters["@TID"].Value.ToString();
                recordsAffected = int.Parse(primarykey);


            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                con.Close();
            }
            return recordsAffected;
        }

        //Teacher Details Update Method
        public int UpdateTeacher(Teacher t)
        {
            int recordsAffected = 0;
            try
            {
                cmd = new SqlCommand("Teacher_Update", con);    //for stored procedure
                cmd.CommandType = System.Data.CommandType.StoredProcedure;


                cmd.Parameters.AddWithValue("@TeacherID", t.TeacherID);
                cmd.Parameters.AddWithValue("@TeacherName", t.TeacherName);
                cmd.Parameters.AddWithValue("@Gender", t.Gender);
                cmd.Parameters.AddWithValue("@DOB", t.DOB);
                cmd.Parameters.AddWithValue("@Contact", t.Contact);
                cmd.Parameters.AddWithValue("@Email", t.Email);
                cmd.Parameters.AddWithValue("@Address_Teacher", t.Address_Teacher);

                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();


            }
            catch (SqlException ex)
            {
                throw ex;

            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {

                con.Close();
            }

            return recordsAffected;
        }

        //Techer Details Delete Method
        public int DeleteTeacher(int tid)
        {
            int recordsAffected = 0;

            try
            {

                cmd = new SqlCommand("Teacher_Delete", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TeacherID", tid);
                con.Open();
                recordsAffected = cmd.ExecuteNonQuery();


            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return recordsAffected;
        }

        //Teacher Details Display Method
        public List<Teacher> DisplayTeacher()
        {
            List<Teacher> tList = new List<Teacher>();
            try
            {
                cmd = new SqlCommand("Teacher_Select", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                con.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows)
                    {
                        Teacher t = new Teacher();
                        t.TeacherID = (int)dr["TeacherID"];
                        t.TeacherName = dr["TeacherName"].ToString();
                        t.Gender = dr["Gender"].ToString();
                        t.DOB = Convert.ToDateTime(dr["DOB"]);
                        t.Contact = dr["Contact"].ToString();
                        t.Email = dr["Email"].ToString();
                        t.Address_Teacher = dr["Address_Teacher"].ToString();

                        tList.Add(t);
                    }
                    else
                        throw new Teacher_Exception("Records are not available");
                }
            }

            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                con.Close();
            }
            return tList;

        }

        //Teacher Details Total Count Method
        public int TotalCountTeacher(Teacher t)
        {
            int count = 0;
            try
            {
                cmd = new SqlCommand("Teacher_TotalCount", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                count = (int)cmd.ExecuteScalar();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            finally
            {
                con.Close();
            }
            return count;
        }

        //Teacher Details Search Method
        public Teacher SearchTeacher(int tid)
        {
            Teacher t = new Teacher();
            try
            {
                cmd = new SqlCommand("Teacher_Search", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TeacherID", tid);

                con.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {

                    dr.Read();
                    t.TeacherID = (int)dr["TeacherID"];
                    t.TeacherName = dr["TeacherName"].ToString();
                    t.Gender = dr["Gender"].ToString();
                    t.DOB = Convert.ToDateTime(dr["DOB"]);
                    t.Contact = dr["Contact"].ToString();
                    t.Email = dr["Email"].ToString();
                    t.Address_Teacher = dr["Address_Teacher"].ToString();


                }
                else
                    throw new Teacher_Exception("Records are not available");

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                con.Close();
            }
            return t;
        }
    }
}
