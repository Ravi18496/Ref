﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entities
{
   public class AssigningTeacher
    {
       public int AssigningID { get; set; }
       public int ClassID { get; set; }
       public int StudentID { get; set; }
       public int TeacherID { get; set; }

    }
}
