﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;

namespace SMS.BAL
{
    public class AssigningTeacher_BAL
    {
        AssigningTeacher_DAL dal = null;
        public AssigningTeacher_BAL()
        {
            dal = new AssigningTeacher_DAL();
        }

        //Getall method to retrieve all the data from stored procedure
        public List<AssigningTeacher> GetAll()
        {
            List<AssigningTeacher> assignlist = null;
            try
            {
                assignlist = dal.SelectAll();
            }
            catch (AssigningTeacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return assignlist;
        }


        //Insert 
        public int InsertAssigningTeacher(AssigningTeacher assign)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = dal.InsertAssingingTeacher(assign);
            }
            catch (AssigningTeacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }


        //Update
        public int UpdateAssigningTeacher(AssigningTeacher assign)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = dal.UpdateAssigningTeacher(assign);
            }
            catch (AssigningTeacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Delete
        public int DeleteAssigningTeacher(int asid)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = dal.DeleteAssigningTeacher(asid);
            }
            catch (AssigningTeacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

    }
}
