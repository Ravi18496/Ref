﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;
using System.Text.RegularExpressions;


namespace SMS.BAL
{
    public class Marks_BAL
    {
        Marks_DAL dal = null;

        public Marks_BAL()
        {
            dal = new Marks_DAL();
        }

        //Getall method to retrieve all the data from stored procedure
        public List<Marks> GetAll()
        {
            List<Marks> mrklist = null;
            try
            {
                mrklist = dal.SelectAll();
            }
            catch (Marks_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return mrklist;
        }

        //public List<Grade> TeacherGetAll()
        //{
        //    List<Grade> grdlist = null;
        //    try
        //    {

        //        grdlist = dal.TeacherSelectAll();

        //    }
        //    catch (Grade_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return grdlist;
        //}

        //Validations for Grade
        public bool ValidateMarks(Marks mark)
        {
            bool marksValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //if (grade.ClassID < 100 || grade.ClassID > 999)
                //{
                //  message.Append("Grade ID should be 3 digits\n");
                //  gradeValidated = false;
                //}                

                if (mark.English < 0 || mark.Mathematics < 0 || mark.Science < 0)
                {
                    message.Append("Marks Should be positive\n");
                    marksValidated = false;
                }
                //if (grade.StudentID < 1000 || grade.StudentID > 9999)
                //{
                //    message.Append("Student ID should be 4 digits\n");
                //    gradeValidated = false;
                //}
                if (marksValidated == false)
                    throw new Marks_Exception(message.ToString());
            }
            catch (Marks_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return marksValidated;
        }

        //Insert 
        public int InsertMarks(Marks mark)
        {
            int recordsAffected = 0;

            try
            {    
                if(ValidateMarks(mark))
                {
                    recordsAffected = dal.InsertMarks(mark);  
                }
                else
                    throw new Marks_Exception("Please Provide valid Marks");
                            
            }
            catch (Marks_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Update
        public int UpdateMarks(Marks mark)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateMarks(mark))
                {
                    recordsAffected = dal.UpdateMarks(mark);
                }
                else
                    throw new Marks_Exception("Please Provide valid Marks");
            }
            catch (Marks_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Delete
        public int DeleteMarks(int mid)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = dal.DeleteMarks(mid);
            }
            catch (Marks_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
    }
}
