﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;

namespace SMS.BAL
{
    public class Cash_BAL
    {
        Cash_DAL ca = new Cash_DAL();

        public bool CashValidated(Fees f)
        {
            bool cValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
                //if(f.InvoiceID < 100000 || f.InvoiceID >999999)
                //{
                //    cValidated = false;
                //    message.Append("Invoice ID should only be 6 digits.\n");
                //}
                if(f.StudentID <= 0)
                {
                    cValidated = false;
                    message.Append("Student ID should be Provided.\n");
                }

                if (f.Payment_Date == null)
                {
                    cValidated = false;
                    message.Append("Date should be provided.\n");
                }
                if(f.Fees_amount <= 0) 
                {
                    cValidated = false;
                    message.Append("Fees Amount should be provided.\n");
                }
                else if(f.Fees_amount >=30001)
                {
                    cValidated = false;
                    message.Append("Fees Amount should be lessthan 30000.\n ");
                }
                //else if(f.Fees_amount < 0 || f.Fees_amount >= 30000)
                //{
                //    cValidated = false;
                //    message.Append("Fees amount should be less than 30000 and it should not be a negative value.\n");
                //}

                if(cValidated == false)
                {
                    throw new Fees_Exception(message.ToString());
                }
                

            }
            catch(Fees_Exception ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return cValidated;
        }

        public int Insert(Fees f)
        {
            int recordsAffected = 0;

            try
            {
                if (CashValidated(f))
                {
                    recordsAffected = ca.Insert(f);
                    
                }
                else
                    throw new Fees_Exception("Please provide valid Details");
                
            }
            catch (Fees_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        public bool Update(Fees f)
        {
            bool recordsAffected = false;

            try
            {
                if(CashValidated(f))
                {
                    ca.Update(f);
                    recordsAffected = true;
                }
                
            }
            catch (Fees_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        public List<Fees> DisplayAll()
        {
            List<Fees> fe = null;

            try
            {
                fe = ca.SelectAll();
            }
            catch (Fees_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return fe;
        }
    }
}
