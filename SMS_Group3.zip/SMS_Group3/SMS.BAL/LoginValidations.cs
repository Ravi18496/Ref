﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.DAL;
using SMS.Exceptions;

namespace SMS.BAL
{
    public class LoginValidations
    {
       LoginOperations adal = new LoginOperations();

        public int AdminLogin(LoginDetails user)
        {
            int usertype;

            try
            {
                usertype = adal.ValidateLogin(user);
            }
            catch (Login_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return usertype;
        }

        public int InsertLogin(LoginDetails login)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = adal.InsertLogin(login);
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        public int UpdateLogin(LoginDetails login)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = adal.UpdateLogin(login);
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        public LoginDetails SearchLogin(int id)
        {
            LoginDetails login = new LoginDetails();
            try
            {
                login = adal.SearchLogin(id);
            }
            catch(Login_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return login;

        }

        public int DeleteLogin(int id)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = adal.DeleteLogin(id);
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;

        }

        public List<LoginDetails> DisplayLogin()
        {
            List<LoginDetails> loginList = new List<LoginDetails>();
            try
            {
                loginList = adal.DisplayLogin();
            }
            catch(Login_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return loginList;

        }
    }
}
