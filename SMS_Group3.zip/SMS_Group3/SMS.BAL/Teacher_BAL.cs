﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;

namespace SMS.BAL
{
    /// <summary>
    /// This class is For Teacher details validation
    /// </summary>

   public class Teacher_BAL
    {
        Teacher_DAL tdal = new Teacher_DAL();

        //Method to Validate Teacher details
        public bool ValidateTeacher(Teacher t)
        {
            bool tValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
                //if (t.TeacherID < 100 || t.TeacherID > 999)
                //{
                //    tValidated = false;
                //    message.Append("Teacher Id should only be 3 digits.\n");
                //}
                if (t.TeacherName == String.Empty)
                {
                    tValidated = false;
                    message.Append("Teacher Name should be provided.\n");
                }
                else if (!Regex.IsMatch(t.TeacherName, "[A-Z][a-z]+"))
                {
                    tValidated = false;
                    message.Append("Teacher Name should start with capital alphabet and it should have alphabets only.\n");
                }
                if (t.Gender == String.Empty)
                {
                    tValidated = false;
                    message.Append("Teacher Gender should be Selected.\n");
                }
                if (t.DOB >= DateTime.Today)
                {
                    tValidated = false;
                    message.Append("Teacher Date of should be Less than current date.\n");
                }
                if (t.Contact == String.Empty)
                {
                    tValidated = false;
                    message.Append("Contact Number should be provided.\n");
                }
                else if (!Regex.IsMatch(t.Contact, "[7-9][0-9]{9}"))
                {
                    tValidated = false;
                    message.Append("Contact Number should start with 7 or 8 or 9 and it should only be 10 digits.\n");
                }
                if (t.Email == String.Empty)
                {
                    tValidated = false;
                    message.Append("Email should be provided.\n");
                }
                else if (!Regex.IsMatch(t.Email, "[a-zA-z0-9]@[a-z].[a-z]"))
                {
                    tValidated = false;
                    message.Append("Please provide valid Email ID.\n");
                }
                if (t.Address_Teacher == String.Empty)
                {
                    tValidated = false;
                    message.Append("Teacher address should be provided");
                }

                if (tValidated == false)
                {
                    throw new Teacher_Exception(message.ToString());
                }


            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return tValidated;
        }

        //Method to Validate Insert Teacher's details
        public int InsertTeacher(Teacher t)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateTeacher(t))
                {
                    recordsAffected = tdal.InsertTeacher(t);
                }
                else
                {
                    throw new Teacher_Exception("Please provide valid Teacher Information.");
                }
            }

            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Method to validate Update Teachers's details
        public int UpdateTeacher(Teacher t)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateTeacher(t))
                {
                    recordsAffected = tdal.UpdateTeacher(t);
                }
                else
                    throw new Teacher_Exception("Please Provide valid Teacher Information");
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Method to validate Delete Teacher's details
        public int DeleteTeacher(int tid)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = tdal.DeleteTeacher(tid);
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Method to validate Display Teacher's details
        public List<Teacher> DisplayTeacher()
        {
            List<Teacher> tList = null;
            try
            {
                tList = new List<Teacher>();
                tList = tdal.DisplayTeacher();
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return tList;
        }

        //Method to validate Total Count
        public int TotalCountTeacher(Teacher t)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = tdal.TotalCountTeacher(t);
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Method to Search Teacher Record
        public Teacher SearchTeacher(int tid)
        {
            Teacher tList = null;
            try
            {
                tList = tdal.SearchTeacher(tid);
            }
            catch (Teacher_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return tList;
        }
    }
}
