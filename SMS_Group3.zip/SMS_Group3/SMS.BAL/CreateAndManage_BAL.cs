﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;

namespace SMS.BAL
{
    
    public class CreateAndManage_BAL
    {
        //CreateAndManage_DAL cmdal = null;

        //public int InsertTeacherLogin(LoginDetails ld)
        //{
        //    cmdal = new CreateAndManage_DAL();
        //    int recordsAffected = 0;

        //    try
        //    {
               
        //            recordsAffected = cmdal.InsertTeacherLogin(ld);
               
               
        //    }

        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return recordsAffected;
        //}

        //public int UpdateTeacherLogin(LoginDetails ld)
        //{
        //    cmdal = new CreateAndManage_DAL();
        //    int recordsAffected = 0;

        //    try
        //    {

        //        recordsAffected = cmdal.UpdateTeacherLogin(ld);


        //    }

        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return recordsAffected;
        //}

        //public int DeleteTeacherLogin(int tid)
        //{
        //    cmdal = new CreateAndManage_DAL();
        //    int recordsAffected = 0;

        //    try
        //    {

        //        recordsAffected = cmdal.DeleteTeacherLogin(tid);


        //    }

        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return recordsAffected;
        //}

        //public List<TeacherLogin> DisplayTeacherLogin()
        //{
        //    cmdal = new CreateAndManage_DAL();
        //    List<TeacherLogin> ldList = new List<TeacherLogin>();
        //    try
        //    {
        //        ldList = cmdal.DisplayTeacherLogin();
        //    }
        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return ldList;
        //}

        //public int InsertStudentLogin(LoginDetails ld)
        //{
        //    cmdal = new CreateAndManage_DAL();
        //    int recordsAffected = 0;

        //    try
        //    {

        //        recordsAffected = cmdal.InsertStudentLogin(ld);


        //    }

        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return recordsAffected;
        //}

        //public int UpdateStudentLogin(LoginDetails ld)
        //{
        //    cmdal = new CreateAndManage_DAL();
        //    int recordsAffected = 0;

        //    try
        //    {

        //        recordsAffected = cmdal.UpdateStudentLogin(ld);


        //    }

        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return recordsAffected;
        //}

        //public int DeleteStudentLogin(int sid)
        //{
        //    cmdal = new CreateAndManage_DAL();
        //    int recordsAffected = 0;

        //    try
        //    {

        //        recordsAffected = cmdal.DeleteStudentLogin(sid);


        //    }

        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return recordsAffected;
        //}

        //public List<StudentLogin> DisplayStudentLogin()
        //{
        //    cmdal = new CreateAndManage_DAL();
        //    List<StudentLogin> ldList = new List<StudentLogin>();
        //    try
        //    {
        //        ldList = cmdal.DisplayStudentLogin();
        //    }
        //    catch (CreateAndManage_Exception ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }
        //    return ldList;
        //}
    }
}
