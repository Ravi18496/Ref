﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entities;
using SMS.Exceptions;
using SMS.DAL;


namespace SMS.BAL
{
    public class Attendence_BAL
    {
        Attendence_DAL dal = null;
        public Attendence_BAL()
        {
            dal = new Attendence_DAL();
        }
        //Getall method to retrieve all the data from stored procedure
        public List<Attendence> GetAll()
        {
            List<Attendence> attlist = null;
            try
            {

                attlist = dal.SelectAll();

            }
            catch (Attendence_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return attlist;
        }

        //Validations for Attendence
        public bool ValidateAttendence(Attendence att)
        {
            bool attValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {

                //if (att.AttendenceID < 10000 || att.AttendenceID > 99999)
                //{
                //    message.Append("Attendence ID should be 3 digits\n");
                //    attValidated = false;
                //}
                //if (att.StudentID < 100 || att.StudentID > 999)
                //{
                //    message.Append("Student ID should be 3 digits\n");
                //    attValidated = false;
                //}
                if (att.Today_Date > DateTime.Today)
                {
                    message.Append("Date must be current date\n");
                    attValidated = false;
                }
                if (attValidated == false)
                    throw new Attendence_Exception(message.ToString());

            }
            catch (Attendence_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return attValidated;
        }

        //Insert
        public int InsertAttendence(Attendence att)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateAttendence(att))
                {
                    recordsAffected = dal.InsertAttendence(att);
                }
                else
                    throw new Marks_Exception("Please Provide valid Attendence Information");
            }
            catch (Attendence_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
    }
}
