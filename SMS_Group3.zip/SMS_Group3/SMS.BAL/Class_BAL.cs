﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Exceptions;
using SMS.Entities;
using SMS.DAL;
using System.Text.RegularExpressions;

namespace SMS.BAL
{
    public class Class_BAL
    {
        Class_DAL tdal = new Class_DAL();

        //Method to Validate Teacher details
        public bool ValidateClass(Class t)
        {
            bool tValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
               
                if (t.ClassName == String.Empty)
                {
                    tValidated = false;
                    message.Append("Teacher Name should be provided.\n");
                }
                else if (!Regex.IsMatch(t.ClassName, "[A-Z][a-z]+"))
                {
                    tValidated = false;
                    message.Append("Class Name should start with capital alphabet and it should have alphabets only.\n");
                }
                  if (tValidated == false)
                {
                    throw new Teacher_Exception(message.ToString());
                }


            }
            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return tValidated;
        }

         public int InsertClass(Class t)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateClass(t))
                {
                    recordsAffected = tdal.InsertClass(t);
                }
                else
                {
                    throw new Teacher_Exception("Please provide valid Class Information.");
                }
            }

            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Method to validate Update Teachers's details
        public int UpdateClass(Class t)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateClass(t))
                {
                    recordsAffected = tdal.UpdateClass(t);
                }
                else
                    throw new Teacher_Exception("Please Provide valid Class Information");
            }
            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Method to validate Delete Teacher's details
        public int DeleteClass(int tid)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = tdal.DeleteClass(tid);
            }
            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        
        public List<Class> DisplayClass()
        {
            List<Class> tList = null;
            try
            {
                tList = new List<Class>();
                tList = tdal.DisplayClass();
            }
            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return tList;
        }

       

        //Method to Search Teacher Record
        public List<Class> SearchClass(int tid)
        {
            List<Class> tList = null;
            try
            {
                tList = tdal.SearchClass(tid);
            }
            catch (Class_Exception ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return tList;
        }
    }
}
  