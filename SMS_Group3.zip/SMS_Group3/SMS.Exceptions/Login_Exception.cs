﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exceptions
{
    public class Login_Exception : ApplicationException
    {
        //for System Exceptions
        public Login_Exception()
            : base()
        { }

        //for User Defined Exceptions
        public Login_Exception(string message) 
            :base(message)
        {  }
        
    }
}
