﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exceptions
{
    /// <summary>
    /// This class is for Grade Exception
    /// </summary>
    public class Marks_Exception : ApplicationException
    {
        //System Exception
        public Marks_Exception()
            : base()
        { }

        //User Defined Exception
        public Marks_Exception(string message)
            : base(message)
        { }
    }
}
