﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exceptions
{
    /// <summary>
    /// This class is for AssigningTeacher Exception
    /// </summary>
   public class AssigningTeacher_Exception:ApplicationException
    {
       public AssigningTeacher_Exception()
           :base()
       { }
       public AssigningTeacher_Exception(string message)
           :base(message)
       {

       }
    }
}
