﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exceptions
{
    /// <summary>
    /// This class is for Attendence Exception
    /// </summary>

    public class Attendence_Exception : ApplicationException
    {
        //System Exception
        public Attendence_Exception()
            : base()
        { }

        //User Defined Exception
        public Attendence_Exception(string message)
            : base(message)
        { }
    }
}
