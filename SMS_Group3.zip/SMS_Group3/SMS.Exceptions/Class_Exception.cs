﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exceptions
{
   public class Class_Exception:ApplicationException
    {
        
        //System Exception
        public Class_Exception()
            : base()
        { }

        //User Defined Exception
        public Class_Exception(string message)
            : base(message)
        { }
    }
    }

