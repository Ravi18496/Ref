﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;
using System.Collections;


namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for Stud_Login.xaml
    /// </summary>
    public partial class Stud_Login : Window
    {
        StudOperations_BAL sbal = new StudOperations_BAL();
        StudentLogin_BAL slbal = new StudentLogin_BAL();
        ArrayList al = new ArrayList();
        List<Student> slist = null;
        public Stud_Login()
        {
           
            InitializeComponent();
            slist = new List<Student>();
            slist = sbal.GetAll();
            foreach (var item in slist)
            {
                al.Add(item.StudentID);
            }
            cbStudentId.ItemsSource = al;


        }

        private void btnStudentLogin_Click(object sender, RoutedEventArgs e)
        {
           
            try
            {
                LoginDetails user = new LoginDetails() { UserStudent = txtStudentUserName.Text, PassStudent = txtStudentPassword.Password };
                string username = slbal.StudentLogin(user);

                if (username == null || username == "")
                {
                    throw new Login_Exception("UserID/Password is wrong");
                }
                else
                {
                    StudOperations studoperations = new StudOperations();
                    studoperations.Show();
                }
            }
            catch (Login_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Populate the data
        private void cbStudentId_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = 0;
            slist = new List<Student>();
            slist = sbal.GetAll();
            //if (int.TryParse(cbStudentId.SelectedItem, out id)) { }
            id = Convert.ToInt32(cbStudentId.SelectedItem);
            

            foreach (var item in slist)
            {
                if (id == item.StudentID)
                {
                    txtStudentUserName.Text = item.StudentName;                    
                    break;
                }
            }
        }
    }
}
