﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for TeacherOperations.xaml
    /// </summary>
    public partial class TeacherOperations : Window
    {
        List<Teacher> tlist = new List<Teacher>();
        ArrayList al = new ArrayList();
        List<Grade> glist = new List<Grade>();
        Grade_BAL gbal = new Grade_BAL();
        Teacher_BAL tbal = new Teacher_BAL();
        TeacherLogin_BAL tlbal = new TeacherLogin_BAL();


        public TeacherOperations()
        {
            InitializeComponent();
            btnAttendance.Visibility = System.Windows.Visibility.Hidden;
            btnGrade.Visibility = System.Windows.Visibility.Hidden;
            Populate();
        }

        public void Populate()
        {
            tlist = tbal.DisplayTeacher();
            foreach (var item in tlist)
            {
                al.Add(item.TeacherID);
            }
            cbTid.ItemsSource = al;
        }

        private void cbTid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnAttendance.Visibility = System.Windows.Visibility.Hidden;
            btnGrade.Visibility = System.Windows.Visibility.Hidden;
            txtPwd.Clear();
            txtTname.Text = "";
            dgDisplay.ItemsSource = null;
            txtClass.Text = "";

            int id = Convert.ToInt32(cbTid.SelectedItem);
            tlist = tbal.DisplayTeacher();
           

            foreach (var item in tlist)
            {
                if (id == item.TeacherID)
                {
                    txtTname.Text = item.TeacherName;

                    break;
                }
            }

            glist = gbal.TeacherGetAll();
            //ArrayList gl = new ArrayList();

            var res1 = from x in glist
                       where x.TeacherID == id
                       select x.StudentID;

            cbSid.ItemsSource = res1.ToList();

            var res2 = from s in glist
                        where s.TeacherID == id
                        select s;

            foreach (var item in res2.ToList())
            {
                txtClass.Text = item.ClassID.ToString();
                break;
            }
            
        }

        private void btnGrade_Click(object sender, RoutedEventArgs e)
        {
            Grade g = new Grade();
           
            int i = 0;
            try
            {
        
                g.StudentID = Convert.ToInt32(cbSid.Text);
                g.Description_Grade = cbGD.Text;
                g.GradeName = cbGrade.Text;
                g.Marks1 = Convert.ToInt32(txtM1.Text);
                g.Marks2 = Convert.ToInt32(txtM2.Text);
                g.Marks3 = Convert.ToInt32(txtM3.Text);
                if (gbal.ValidateGrade(g))
                {
                    i = gbal.UpdateGrade(g);
                    if (i != 0)
                    {
                        MessageBox.Show("Inserted!!");
                    }
                }
            }
            catch (Grade_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAttendance_Click(object sender, RoutedEventArgs e)
        {
            Attendence att = new Attendence();
            Attendence_BAL abal = new Attendence_BAL();
            int i = 0;
            try
            {

                att.AttendenceID = Convert.ToInt32(txtAid.Text);
                att.StudentID = Convert.ToInt32(cbSid.Text);
                att.Attended = Convert.ToChar(txtAttend.Text);
                att.Today_Date = Convert.ToDateTime(date.Text);
                if (abal.ValidateAttendence(att))
                {
                    i = abal.InsertAttendence(att);

                    if (i != 0)
                    {
                        MessageBox.Show("Inserted!!");
                    }
                }
            }
            catch (Attendence_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoginDetails user = new LoginDetails() { UserTeacher = txtTname.Text, PassTeacher = txtPwd.Password };
                string username = tlbal.TeacherLogin(user);

                if (username == null || username == "")
                {
                    txtTname.Text = "";
                    txtPwd.Clear();
                    
                    throw new Login_Exception("UserID/Password is wrong");

                }
                else
                {
                    int id = 0;
                    tlist = new List<Teacher>();
                    tlist = tbal.DisplayTeacher();
                    id = Convert.ToInt32(cbTid.SelectedItem);

                    var res = from v in tlist
                              where v.TeacherID == id
                              select v;
                    dgDisplay.ItemsSource = res.ToList();

                    btnGrade.Visibility = System.Windows.Visibility.Visible;
                    btnAttendance.Visibility = System.Windows.Visibility.Visible;
                }
            }
            catch (Login_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLogoutTeacher_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}