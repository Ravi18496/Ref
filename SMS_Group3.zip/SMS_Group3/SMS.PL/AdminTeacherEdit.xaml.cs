﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for AdminTeacherEdit.xaml
    /// </summary>
   
    public partial class AdminTeacherEdit : Window
    {
        List<Teacher> allTeach = null;
        Teacher_BAL tbal = new Teacher_BAL();

        public AdminTeacherEdit()
        {
            InitializeComponent();
        }

        //Button Method to Insert Teacher Data
        private void btnTeacherInsert_Click(object sender, RoutedEventArgs e)
        {
            int teacherInserted = 0;
            Teacher teacher = new Teacher();
            try
            {
                int id = 0;
                
                if (int.TryParse(txtTeacherID.Text, out id)) { }
                //teacher.TeacherID = id;
                teacher.TeacherName = txtTeacherName.Text;
                teacher.DOB = Convert.ToDateTime(dpTeacherDOB.Text);
                if (btnTeacherFemale.IsChecked == true)
                    teacher.Gender = "Female";
                else teacher.Gender = "Male";
                teacher.Contact = txtTeacherContact.Text;
                teacher.Email = txtTeacherEmail.Text;
                teacher.Address_Teacher = new TextRange(rtxtTeacherAddress.Document.ContentStart,rtxtTeacherAddress.Document.ContentEnd).Text;
               
                teacherInserted = tbal.InsertTeacher(teacher);
                if (teacherInserted > 0)
                {
                    MessageBox.Show("Teacher Details are Sucessfully Inserted with ID : "+teacherInserted);
                }
                else
                {
                    throw new Teacher_Exception("Teacher Details are not inserted");
                }


            }
            catch (Teacher_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            PopulateUI(allTeach);
        }

        //Method to Populate Ui
        private void PopulateUI(List<Teacher> allTeach)
        {
            allTeach = tbal.DisplayTeacher();
            dgvTeacher.ItemsSource = allTeach;

        }

        //Button Method to Display All
        private void btnTeacherDisplayAll_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                allTeach = tbal.DisplayTeacher();
                PopulateUI(allTeach);
            }
            catch(Teacher_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Button Method to Update Teacher Details
        private void btnTeacherUpdate_Click(object sender, RoutedEventArgs e)
        {
            int recordsAffected = 0;
            Teacher teacher = new Teacher();
            try
            {
                int id = 0;

                if (int.TryParse(txtTeacherID.Text, out id)) { }
                teacher.TeacherID = id;
                teacher.TeacherName = txtTeacherName.Text;
                teacher.DOB = Convert.ToDateTime(dpTeacherDOB.Text);
                if (btnTeacherFemale.IsChecked == true)
                    teacher.Gender = "Female";
                else teacher.Gender = "Male";
                teacher.Contact = txtTeacherContact.Text;
                teacher.Email = txtTeacherEmail.Text;
                teacher.Address_Teacher = new TextRange(rtxtTeacherAddress.Document.ContentStart, rtxtTeacherAddress.Document.ContentEnd).Text;

                recordsAffected = tbal.UpdateTeacher(teacher);
                if (recordsAffected > 0)
                {
                    MessageBox.Show("Employee Sucessfully Updated");
                }
                else
                {
                    throw new Teacher_Exception("Employee Details are not Updated");
                }


            }
            catch (Teacher_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

            PopulateUI(allTeach);
        }

        //Button Method To Delete Teacher Details
        private void btnTeacherDelete_Click(object sender, RoutedEventArgs e)
        {
            int teachDeleted = 0;
            try
            {
                int id = 0;
                if (int.TryParse(txtTeacherID.Text, out id)) { }

                if (id <= 0)
                {
                    throw new Teacher_Exception("**Please provide valid Teacher Id to delete His/Her Teacher records**");
                }
                teachDeleted = tbal.DeleteTeacher(id);
                if (teachDeleted > 0)
                {
                    MessageBox.Show("Teacher Details are Successfully Deleted");
                    PopulateUI(allTeach);
                }
                else
                {
                    throw new Teacher_Exception("Teacher Details are not Available in the records");
                }

            }

            catch (Teacher_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Button Method To Search Teacher Details
        private void btnTeacherSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = 0;
                if (int.TryParse(txtTeacherID.Text, out id)) { }

                if (id <= 0)
                {
                    throw new Teacher_Exception("**Plese provide valid Teacher Id to search His/Her Teacher Details**");
                }

                allTeach = tbal.SearchTeacher(id);
                dgvTeacher.ItemsSource = allTeach;

            }
            catch (Teacher_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Button Method to Get TotalCount of the Teacher
        private void btnTeacherTotalCount_Click(object sender, RoutedEventArgs e)
        {
            int countTeacher = 0;
            Teacher teacher = new Teacher();
            try
            {
                countTeacher = tbal.TotalCountTeacher(teacher);

                if (countTeacher > 0)
                {
                    MessageBox.Show("Total Teacher records are : " + countTeacher);
                }
                else
                {
                    MessageBox.Show("Total Teacher Records are : " + countTeacher);
                }

            }
            catch (Teacher_Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



    }
}
