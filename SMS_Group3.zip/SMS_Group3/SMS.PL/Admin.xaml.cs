﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        AdminLogin_BAL abal = null;
        public Admin()
        {
            InitializeComponent();
            abal = new AdminLogin_BAL();
        }

        private void btnAdminSubmit_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                LoginDetails user = new LoginDetails() { UserAdmin = txtAdminUserName.Text, PassAdmin = txtAdminPassword.Password };
                string username = abal.AdminLogin(user);

                if (username == null || username == "")
                {
                    throw new Login_Exception("UserID/Password is wrong");
                }
                else
                {
                    AdminOperations aop = new AdminOperations();
                    aop.Show();
                    //Session["user"] = username;
                    //Response.Redirect("Home.aspx");
                    this.Close();
                }
            }
            catch (Login_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
