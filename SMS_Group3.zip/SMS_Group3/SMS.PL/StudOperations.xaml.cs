﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;
using System.Collections;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for StudOperations.xaml
    /// </summary>
    public partial class StudOperations : Window
    {
        List<Student> slist = null;
        StudOperations_BAL sbal = new StudOperations_BAL();
        StudentLogin_BAL slbal = new StudentLogin_BAL();
        Grade_BAL gbal = new Grade_BAL();
        List<Grade> glist = null;
        List<Attendence> alist = null;
        Attendence_BAL abal = new Attendence_BAL();
        ArrayList al = new ArrayList();
        public StudOperations()
        {
            InitializeComponent();
            slist = new List<Student>();
            slist = sbal.GetAll();
            foreach (var item in slist)
            {
                al.Add(item.StudentID);
            }
            cbId.ItemsSource = al;
            btnGrade.Visibility = System.Windows.Visibility.Hidden;
            btnAttendance.Visibility = System.Windows.Visibility.Hidden;
        }

        private void btnGrade_Click(object sender, RoutedEventArgs e)
        {
            glist = gbal.GetAll();
            int id = 0;
            id = Convert.ToInt32(cbId.SelectedValue);
            var res = from m in glist
                      where m.StudentID == id
                      select m;
            dgView.ItemsSource = res.ToList();
        }

        private void btnAttendance_Click(object sender, RoutedEventArgs e)
        {
            alist = abal.GetAll();
            int id = 0;
            id = Convert.ToInt32(cbId.SelectedValue);
            var res = from m in alist
                      where m.StudentID == id
                      select m;
            dgView.ItemsSource = res.ToList();
        }

        private void cbId_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = 0;
            slist = new List<Student>();
            slist = sbal.GetAll();
            id = Convert.ToInt32(cbId.SelectedItem);

            foreach (var item in slist)
            {
                if (id == item.StudentID)
                {
                    txtName.Text = item.StudentName;                   
                    break;
                }
            }
            btnGrade.Visibility = System.Windows.Visibility.Hidden;
            btnAttendance.Visibility = System.Windows.Visibility.Hidden;
            txtPwd.Password = "";
            txtGender.Text = "";
            txtDOB.Text = "";
            txtContact.Text = "";
            txtBloodGroup.Text = "";
            txtAdress.Text = "";
            dgView.ItemsSource = null;
        }

        private void btnSlogin_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                LoginDetails user = new LoginDetails() { UserStudent = txtName.Text, PassStudent = txtPwd.Password };
                string username = slbal.StudentLogin(user);

                if (username == null || username == "")
                {
                    txtName.Text = "";
                    txtGender.Text = "";
                    txtDOB.Text = "";
                    txtContact.Text = "";
                    txtBloodGroup.Text = "";
                    txtAdress.Text = "";
                    dgView.ItemsSource = null;
                    throw new Login_Exception("UserID/Password is wrong");
                    
                }
                else
                {
                    int id = 0;
                    slist = new List<Student>();
                    slist = sbal.GetAll();
                    id = Convert.ToInt32(cbId.SelectedItem);

                    foreach (var item in slist)
                    {
                        if (id == item.StudentID)
                        {
                            txtName.Text = item.StudentName;
                            txtGender.Text = item.Gender;
                            txtDOB.Text = item.DOB.ToString();
                            txtContact.Text = item.Contact;
                            txtBloodGroup.Text = item.BloodGroup;
                            txtAdress.Text = item.Student_address;
                            break;
                        }
                    }
                    btnGrade.Visibility = System.Windows.Visibility.Visible;
                    btnAttendance.Visibility = System.Windows.Visibility.Visible;
                }
            }
            catch (Login_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
