﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for CashierLogin.xaml
    /// </summary>
    public partial class CashierLogin : Window
    {
        CashierLogin_BAL cbal = null;
        public CashierLogin()
        {
            InitializeComponent();
            cbal = new CashierLogin_BAL();
        }

        private void btnCashierLogin_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                LoginDetails user = new LoginDetails() { UserCashier = txtCashierUserName.Text, PassCashier = txtCashierPassword.Password };
                string username = cbal.CashierLogin(user);

                if (username == null || username == "")
                {
                    throw new Login_Exception("UserID/Password is wrong");
                }
                else
                {
                    CashierOperations clogin = new CashierOperations();
                    clogin.Show();
                    this.Close();
                }
                    
            }
            catch (Login_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
