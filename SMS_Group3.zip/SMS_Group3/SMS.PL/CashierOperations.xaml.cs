﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMS.Entities;
using SMS.Exceptions;
using SMS.BAL;
using System.Collections;


namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for CashierOperations.xaml
    /// </summary>
    public partial class CashierOperations : Window
    {
        Cash_BAL c = new Cash_BAL();
        Studnet_BAL sbal = new Studnet_BAL();
        ArrayList al = new ArrayList();
        List<Student> stdList = new List<Student>();
        public CashierOperations()
        {
            InitializeComponent();
            stdList = sbal.DisplayStudent();
            foreach (var item in stdList)
            {
                al.Add(item.StudentID);
            }
            cbStudentID.ItemsSource = al;

        }

        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                List<Fees> flist = new List<Fees>();
                flist = c.DisplayAll();
                var res = from f in flist
                          where f.Fees_amount < 30000
                          select f;
                foreach (var item in res.ToList())
                {
                    item.Fees_amount = 30000 - item.Fees_amount;
                }
                dgView.ItemsSource = res.ToList();
                dgView.DataContext = res.ToList();
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool Updated;
                Fees fee = new Fees();
                int id = 0;
                if (int.TryParse(txtInvoice.Text, out id)) { }
                fee.InvoiceID = id;
                fee.Payment_Date = Convert.ToDateTime(txtDate.Text);
                int sid = 0;
                //if (int.TryParse(txtStuId.Text, out sid)) { }
                //fee.StudentID = sid;
                sid =Convert.ToInt32(cbStudentID.SelectedItem);
                fee.StudentID = sid;
                int aid = 0;
                if (int.TryParse(txtPay.Text, out aid)) { }
                fee.Fees_amount = aid;
                
                Updated = c.Update(fee);
                if (Updated)
                {
                    MessageBox.Show("Updated");
                }
                else
                    throw new Fees_Exception("Details are not Updated");
            }
            catch(Fees_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            int inserted;
            Fees fee = new Fees();
            try
            {
                int id = 0;
                if (int.TryParse(txtInvoice.Text, out id)) { }
                //fee.InvoiceID = id;
                fee.Payment_Date = Convert.ToDateTime(txtDate.Text);
                int sid = 0;
                //if (int.TryParse(txtStuId.Text, out sid)) { }
                //fee.StudentID = sid;
                sid = Convert.ToInt32(cbStudentID.SelectedItem);
                fee.StudentID = sid;
                int aid = 0;
                if (int.TryParse(txtPay.Text, out aid)) { }
                fee.Fees_amount = aid;
                inserted = c.Insert(fee);
                if (inserted > 0)
                {
                    MessageBox.Show("Inserted with Invoice ID :"+inserted);
                }
                else
                    throw new Fees_Exception("Details are not Inserted");
            }
            catch(Fees_Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
