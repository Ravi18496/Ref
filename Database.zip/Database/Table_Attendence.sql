CREATE PROCEDURE Attendence_Select
AS
SELECT * FROM dbo.Attendence


CREATE PROCEDURE Attendence_Insert
@AttendenceID Integer, @StudentID Integer, @Today_Date date, @Attended char
AS
insert into dbo.Attendence(AttendenceID,StudentID,Today_Date,Attended) values( @AttendenceID, @StudentID,@Today_Date,@Attended)


CREATE PROCEDURE Attendence_Delete
@AttendenceID Integer
AS
DELETE FROM dbo.Attendence WHERE AttendenceID = @AttendenceID  


CREATE PROCEDURE Attendence_Update
@AttendenceID Integer, @StudentID Integer, @Today_Date date, @Attended char
AS
UPDATE dbo.Attendence SET  
StudentID = @StudentID, Today_Date = @Today_Date, Attended = @Attended
WHERE AttendenceID = @AttendenceID 