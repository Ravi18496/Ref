﻿CREATE PROC UDP_LoginSMS
(
	@UserName		VARCHAR(20),
	@Password		VARCHAR(20)
	
)
AS
BEGIN
	SELECT UserName
	FROM LoginSMS
	WHERE UserName = @UserName AND
		Password = @Password
END