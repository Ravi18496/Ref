CREATE TABLE [dbo].[LoginSMS] 
(
    [UserName] VARCHAR (20) NULL,
    [Password] VARCHAR (20) NULL,
    [UserType] VARCHAR (20) NULL
);


CREATE TABLE [dbo].[Teacher] 
(
    [TeacherID]       INT          IDENTITY (100, 1) NOT NULL,
    [TeacherName]     VARCHAR (20) NULL,
    [Gender]          VARCHAR (6)  NULL,
    [DOB]             DATE         NULL,
    [Contact]         VARCHAR (10) NULL,
    [Email]           VARCHAR (20) NULL,
    [Address_Teacher] VARCHAR (20) NULL,
    PRIMARY KEY CLUSTERED ([TeacherID] ASC)
);


CREATE TABLE [dbo].[Student]
(
    [StudentID]       INT          IDENTITY (1000, 1) NOT NULL,
    [StudentName]     VARCHAR (20) NULL,
    [Gender]          VARCHAR (6)  NULL,
    [DOB]             DATE         NULL,
    [BloodGroup]      VARCHAR (5)  NULL,
    [Contact]         VARCHAR (10) NULL,
    [Student_address] VARCHAR (20) NULL,
    PRIMARY KEY CLUSTERED ([StudentID] ASC)
);

CREATE TABLE [dbo].[Marks] 
(
    [MarksID]     INT         IDENTITY (400, 1) NOT NULL,
    [ClassID]     INT         NULL,
    [TeacherID]   INT         NULL,
    [StudentID]   INT         NULL,
    [English]     INT         NULL,
    [Mathematics] INT         NULL,
    [Science]     INT         NULL,
    [Percentage]  DECIMAL (2) NULL,
    PRIMARY KEY CLUSTERED ([MarksID] ASC),
    FOREIGN KEY ([ClassID]) REFERENCES [dbo].[Class] ([ClassID]),
    FOREIGN KEY ([TeacherID]) REFERENCES [dbo].[Teacher] ([TeacherID]),
    FOREIGN KEY ([StudentID]) REFERENCES [dbo].[Student] ([StudentID])
);


CREATE TABLE [dbo].[Attendence] 
(
    [AttendenceID] INT      IDENTITY (10000, 1) NOT NULL,
    [StudentID]    INT      NULL,
    [Today_Date]   DATE     NULL,
    [Attended]     CHAR (1) NULL,
    PRIMARY KEY CLUSTERED ([AttendenceID] ASC),
    FOREIGN KEY ([StudentID]) REFERENCES [dbo].[Student] ([StudentID])
);


CREATE TABLE [dbo].[AssigningTeacher] (
    [AssigningID] INT IDENTITY (300, 1) NOT NULL,
    [ClassID]     INT NULL,
    [StudentID]   INT NULL,
	[TeacherID]   INT NULL,
    PRIMARY KEY CLUSTERED ([AssigningID] ASC),
    FOREIGN KEY ([ClassID]) REFERENCES [dbo].[Class] ([ClassID]),
    FOREIGN KEY ([StudentID]) REFERENCES [dbo].[Student] ([StudentID]),
    FOREIGN KEY ([TeacherID]) REFERENCES [dbo].[Teacher] ([TeacherID])
);


CREATE TABLE [dbo].[Class] 
(
    [ClassID]   INT          IDENTITY (1, 1) NOT NULL,
    [ClassName] VARCHAR (20) NULL,
    PRIMARY KEY CLUSTERED ([ClassID] ASC)
);


CREATE TABLE [dbo].[AssigningTeacher] 
(
    [AssigningID] INT IDENTITY (300, 1) NOT NULL,
    [ClassID]     INT NULL,
    [StudentID]   INT NULL,
    PRIMARY KEY CLUSTERED ([AssigningID] ASC),
    FOREIGN KEY ([ClassID]) REFERENCES [dbo].[Class] ([ClassID]),
    FOREIGN KEY ([StudentID]) REFERENCES [dbo].[Student] ([StudentID])
);


