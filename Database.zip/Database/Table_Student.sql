CREATE PROCEDURE Student_Select
AS
SELECT * FROM dbo.Student


CREATE PROCEDURE Student_Insert
@StudentName varchar(20), 
@Gender varchar(6), @DOB date, 
@Contact varchar(10), 
@BloodGroup varchar(5), 
@Student_address varchar(20),
@ID Integer Out
AS
INSERT INTO dbo.Student(StudentName,Gender,DOB,Contact,BloodGroup,Student_address) 
VALUES ( @StudentName, @Gender, @DOB, @Contact,@BloodGroup,@Student_address)
SET @ID=@@Identity 
RETURN @ID


CREATE PROCEDURE Student_Delete
@StudentID Integer
AS
DELETE FROM dbo.Student WHERE StudentID = @StudentID


CREATE PROCEDURE Student_Update
@StudentID Integer, 
@StudentName varchar(20), 
@Gender varchar(6), 
@DOB date, 
@Contact varchar(10), 
@BloodGroup varchar(5),
@Student_address varchar(20)
AS
UPDATE dbo.Student SET  
StudentName = @StudentName, Gender = @Gender, DOB = @DOB,Contact = @Contact, BloodGroup = @BloodGroup, Student_address = @Student_address
WHERE StudentID = @StudentID


CREATE PROCEDURE Student_Search
@StudentID int
AS
SELECT * FROM Student where  StudentID=@StudentID
RETURN 0


CREATE PROCEDURE Student_TotalCount
AS
SELECT  Count(*) FROM Student








