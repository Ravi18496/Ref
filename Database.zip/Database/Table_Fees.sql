CREATE PROCEDURE Fees_Select
AS
SELECT * FROM dbo.Fees


CREATE PROCEDURE Fees_Insert
@InvoiceID Integer, @StudentID Integer, @Payment_date date, @Fees_amount int
AS
insert into dbo.Fees(InvoiceID,StudentID,Payment_date,Fees_amount) values( @InvoiceID, @StudentID,@Payment_date,@Fees_amount)



CREATE PROCEDURE Fees_Update
@InvoiceID Integer, @StudentID Integer, @Payment_date date, @Fees_amount int
AS
UPDATE dbo.Fees SET  
Payment_date = @Payment_date, Fees_amount = @Fees_amount
WHERE StudentID = @StudentID


CREATE PROCEDURE Fees_Delete
@InvoiceID Integer
AS
DELETE FROM dbo.Fees WHERE InvoiceID = @InvoiceID  

