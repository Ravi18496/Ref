CREATE PROCEDURE Marks_Select
AS
SELECT * FROM dbo.Marks


Alter PROCEDURE Marks_Insert
@ClassID int, 
@TeacherID int, 
@StudentID int, 
@English int,
@Mathematics int, 
@Science int, 
@Percentage decimal(2),  
@MID integer out
AS
INSERT INTO dbo.Marks(ClassID, TeacherID, StudentID, English, Mathematics, Science, Percentage) 
VALUES (@ClassID, @TeacherID, @StudentID, @English, @Mathematics, @Science, @Percentage)
SET @MID=@@IDENTITY
RETURN @MID


CREATE PROCEDURE Marks_Delete
@MarksID Integer
AS
DELETE FROM dbo.Marks WHERE MarksID = @MarksID


CREATE proc Marks_Update
@MarksID int,
@ClassID int,
@TeacherID int,
@StudentID int,
@English int,
@Mathematics int,
@Science int,
@Percentage decimal
AS
UPDATE Marks 
SET ClassID=@ClassID,TeacherID=@TeacherID,StudentID=@StudentID,English=@English,Mathematics=@Mathematics,Science=@Science,Percentage=@Percentage
WHERE MarksID=@MarksID



