﻿CREATE PROCEDURE Class_Select
AS
SELECT *from Class


alter PROCEDURE Class_Insert
@ClassName varchar,
AS
INSERT INTO Class(ClassName) VALUES (@ClassName)





CREATE PROCEDURE Class_Delete
@ClassID integer 
AS
DELETE FROM Class WHERE ClassID=@ClassID


CREATE PROCEDURE Class_Update
@ClassID integer,
@ClassName varchar
AS
UPDATE Class SET ClassName=@ClassName WHERE ClassID=@ClassID

