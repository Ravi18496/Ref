﻿CREATE PROCEDURE AssigningTeacher_Select
AS
SELECT *FROM AssigningTeacher


alter PROCEDURE AssigningTeacher_Insert
@ClassID int,
@StudentID int,
@TeacherID int
AS
INSERT INTO AssigningTeacher (ClassID,StudentID,TeacherID) VALUES (@ClassID,@StudentID,@TeacherID)



CREATE PROCEDURE AssigningTeacher_Delete
@AssigningID int
AS
DELETE FROM AssigningTeacher WHERE AssigningID=@AssigningID


CREATE PROCEDURE AssigningTeacher_Update
@AssigningID int,
@ClassID int,
@StudentID int,
@TeacherID int
AS
	UPDATE AssigningTeacher SET ClassID=@ClassID, StudentID=@StudentID, TeacherID=@TeacherID
	WHERE AssigningID=@AssigningID






