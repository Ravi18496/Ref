CREATE PROCEDURE Teacher_Select
AS
SELECT * FROM dbo.Teacher


CREATE PROCEDURE Teacher_Insert
@TeacherName varchar(20), 
@Gender varchar(6), 
@DOB date, 
@Contact varchar(10), 
@Email varchar(20), 
@Address_Teacher varchar(20), 
@TID integer out
AS
INSERT INTO dbo.Teacher(TeacherName,Gender,DOB,Contact,Email,Address_Teacher) 
VALUES ( @TeacherName, @Gender, @DOB, @Contact, @Email, @Address_Teacher)
SET @TID=@@IDENTITY
RETURN @TID


CREATE PROCEDURE Teacher_Delete
@TeacherID Integer
AS
DELETE FROM dbo.Teacher WHERE TeacherID = @TeacherID


CREATE PROCEDURE Teacher_Update
@TeacherID Integer, 
@TeacherName varchar(20), 
@Gender varchar(6), 
@DOB date, 
@Contact varchar(10), 
@Email varchar(20), 
@Address_Teacher varchar(20)
AS
UPDATE dbo.Teacher SET  
TeacherName = @TeacherName, Gender = @Gender, DOB = @DOB,Contact = @Contact, @Email = Email, @Address_Teacher = Address_Teacher
WHERE TeacherID = @TeacherID


CREATE PROCEDURE Teacher_Search
@TeacherID int
AS
SELECT * FROM Teacher where TeacherID=@TeacherID
RETURN 0


CREATE PROCEDURE Teacher_TotalCount
AS
SELECT Count(*) FROM Teacher




