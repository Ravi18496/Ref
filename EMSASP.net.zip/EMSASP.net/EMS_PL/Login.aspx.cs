﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMSASP.net;
using EMSException;
using EMPBL;


namespace EMS_PL
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                User user = new User();
                user.UserName = txtUserName.Text;
                user.Password = txtPassword.Text;

                string username = UserValidations.ValidateUser(user);

                if (username == string.Empty || username == null)
                {
                    lblError.Text = "Invalid username/Password";
                }

                else
                {
                    Session["user"] = username;
                    Response.Redirect("Home.aspx");
                }
            }
            catch (User_Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch(SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }     
    }
}