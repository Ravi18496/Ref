﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMSASP.net;
using EMSException;
using EMPBL;

namespace EMS_PL
{
    public partial class Delete : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            Master.Logout = true;
            Master.Menu = true;
            List<EMS_Entity> empLIst1 = new List<EMS_Entity>();
            empLIst1 = EMPValidations.DisplayEmployee();
            if (!IsPostBack)
            {
                lbEmpid.DataSource = empLIst1;

                lbEmpid.DataValueField = "EmpId";
                lbEmpid.DataBind();

            }
            
           //dlempid.DataSource = empLIst;
        
            //dlempid.DataValueField = "EmpId";
            //dlempid.DataBind();
        }

        protected void BtmSubmit_Click(object sender, EventArgs e)
        {

            //lbEmpid.Items.Remove(lbEmpid.SelectedValue);
            int id = 0;
            id = int.Parse(lbEmpid.SelectedItem.ToString());
            
            int recordsAffected = EMPValidations.DeleteEmployee(id);
            if (recordsAffected > 0)
            {
                Response.Write("DELETED");

                List<EMS_Entity> emplist = new List<EMS_Entity>();

                emplist = EMPValidations.DisplayEmployee();

                lbEmpid.DataSource = emplist;
            }


        }
            //EMS_Entity emp = new EMS_Entity();
            //int id = 0;
            //if (int.TryParse(lbEmpid.SelectedValue.Remove(id), out id)) { }
            //emp.EmpId = id;

            //int recordsAffected = EMPValidations.DeleteEmployee(id);
            //if (recordsAffected > 0)
            //{
            //    Response.Write("Deleted successfully");
            //}
            //else
            //{
            //    Response.Write("Not deleted");
            //}
            //}

        protected void lbEmpid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void dlempid_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }                     

        }


        //protected void lbEmpid_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    //EMS_Entity emp = new EMS_Entity();
        //    //lbEmpid.DataSource = emp.EmpId.ToString();
        //    //lbEmpid.DataTextField = (emp.EmpId).ToString();
        //    //lbEmpid.DataValueField = (emp.EmpId).ToString();
        //    //lbEmpid.DataBind();

        //}
           
        }

        //protected void lbEmpid_SelectedIndexChanged(object sender, EventArgs e)
        //{
            
        //}
    

