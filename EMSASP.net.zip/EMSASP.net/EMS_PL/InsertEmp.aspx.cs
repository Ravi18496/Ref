﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMSASP.net;
using EMSException;
using EMPBL;

namespace EMS_PL
{
    public partial class InsertEmp : System.Web.UI.Page
    {
        EMS_Entity emp = new EMS_Entity();
        protected void Page_Load(object sender, EventArgs e)
        {
            Master.Logout = true;
            Master.Menu = true;
        }

        protected void BtnSub_Click(object sender, EventArgs e)
        {
            int id = 0;
            if (int.TryParse(txtEmpId.Text, out id)) { }
            emp.EmpId = id;
            emp.Empname = txtEmpName.Text;
            if (Gender.SelectedItem.Value=="Male")
            {
                emp.Gender = "Male";
            }

            else if (Gender.SelectedItem.Value == "Female")
            {
                emp.Gender = "Female";
            }
            emp.DOJ = Convert.ToDateTime(dateDoj.Text);
            emp.Salary =Convert.ToDecimal(TxtSal.Text);

            int recordsAffected = EMPValidations.InsertEmployee(emp);

            if(recordsAffected>0)
            {
                Response.Write("Data inserted successfully");
            }
            else
            {
                Response.Write("Data not inserted");
            }

        }
    }
}