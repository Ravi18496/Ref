﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using EMSASP.net;
using EMPBL;
using EMSException;

namespace EMS_PL
{
    public partial class Search : System.Web.UI.Page
    {
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        EMS_Entity emp = new EMS_Entity();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["con1"].ConnectionString;
            con = new SqlConnection(conStr);
            Master.Logout = true;
            Master.Menu = true;
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            int id = 0;
            if (int.TryParse(txtEmpId.Text, out id)) { }
            emp.EmpId = id;

            int recordsAffected = EMPValidations.DeleteEmployee(id);
            if(recordsAffected>0)
            {
                Response.Write("Deleted successfully");
            }
            else
            {
                Response.Write("Not deleted");
            }
            
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

            //try
            //{
            //    int empId = int.Parse(txtEmpId.Text.ToString());
            //    EMS_Entity emp = EMPValidations.SearchEmployee(empId);

            //    if(emp!=null)
            //    {
            //        List<EMS_Entity> empList = new List<EMS_Entity>();
            //        empList.Add(emp);

                    
            //    }
            //}
            //catch
            //{

            //}

            int id = 0;
            if (int.TryParse(txtEmpId.Text, out id)) { }
            EMS_Entity emp = new EMS_Entity();
            int i = 0;

            cmd = new SqlCommand("usp_SearchEmp_142285", con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@EmpId", id);

            con.Open();
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {

                dr.Read();
                emp.EmpId = (int)dr["EmpId"];

                emp.Empname = dr["EmpName"].ToString();
                emp.Gender = dr["Gender"].ToString();
                emp.DOJ = Convert.ToDateTime(dr["DOJ"]);
                emp.Salary = (decimal)dr["Salary"];

                i = i + 1;
            }
            else
                Response.Write("Records Not Available");
            con.Close();
            dr.Close();

            //txtEmpId.Text = emp.EmpId.ToString();
            txtEmpName.Text = emp.Empname;
            TxtGen.Text = emp.Gender;
            txtDoj.Text = emp.DOJ.ToString();
            TxtSal.Text = emp.Salary.ToString();

            if (i > 0)
            {
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;
            }
            else
            {
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }


        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            int id = 0;
            if (int.TryParse(txtEmpId.Text, out id)) { }
            emp.EmpId = id;
            emp.Empname = txtEmpName.Text;
            emp.Gender = TxtGen.Text;
          emp.DOJ= Convert.ToDateTime(txtDoj.Text);
          emp.Salary = Convert.ToDecimal(TxtSal.Text);

          int recordsAffected = EMPValidations.UpdateEmployee(emp);

            if(recordsAffected>0)
            {
                Response.Write("Data updated");
            }
            else
            {
                Response.Write("Data not updated");
            }
        }
    }
}