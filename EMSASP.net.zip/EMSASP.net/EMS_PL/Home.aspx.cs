﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMSASP.net;
using EMSException;
using EMS_PL;
using EMPBL;

namespace EMS_PL
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          if(Session["user"]!=null)
          {
              lblWelcome.Text = "Welcome " + Session["user"].ToString();
              Master.Logout = true;
              Master.Menu = true;
          }
            else
          {
              Response.Redirect("Login.aspx");
          }

          try
          {
              List<EMS_Entity> emplist = EMPValidations.DisplayEmployee();

              if (emplist.Count > 0)
              {
                  gvEmployee.DataSource = emplist;
                  gvEmployee.DataBind();

              }
              else
                  throw new EmpException("Employee details not avialable");
          }
            catch(EmpException ex)
          {
              Response.Write("<script>alert('" + ex.Message + "');</script>");
          }
            catch(SystemException ex)
          {
              Response.Write("<script>alert('" + ex.Message + "');</script>");
          }
        }
    }
}