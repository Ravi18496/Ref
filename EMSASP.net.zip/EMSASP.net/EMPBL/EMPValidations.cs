﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSASP.net;
using EMSException;
using EmsDAL;

namespace EMPBL
{
    public class EMPValidations
    {
        public static int InsertEmployee(EMS_Entity emp)
        {
            int recordsAffected;

            try
            {
                recordsAffected = EmployeeOperations.InsertEmployee(emp);
            }
            catch(EmpException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        public static int UpdateEmployee(EMS_Entity emp)
        {
            int recordsAffected;

            try 
            {
                recordsAffected = EmployeeOperations.UpdateEmployee(emp);
            }
            catch(EmpException ex) 
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        public static EMS_Entity SearchEmployee(int empid)
        {
            EMS_Entity emp = null;

            try
            {
                emp = EmployeeOperations.SearchEmployee(empid);
            }
            catch(EmpException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return emp;
        }

        public static List<EMS_Entity>DisplayEmployee()
        {
            List<EMS_Entity> emplist = null;

            try
            {
                emplist = EmployeeOperations.DisplayEmployee();
            }
            catch(EmpException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return emplist;
        }

        public static int DeleteEmployee(int empid)
        {
            int recordsAffected;

            try
            {
                recordsAffected = EmployeeOperations.DeleteEmployee(empid);
            }
            catch(EmpException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
       
    }
    
}
