﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMSASP.net;
using EMSException;
using EmsDAL;

namespace EMPBL
{
   public class UserValidations
    {
       public static string ValidateUser(User user)
       {
           string username = "";

           try
           {
               username=UserOperations.ValidateUser(user);
           }
           catch(User_Exception ex)
           {
               throw ex;
           }
           catch(SystemException ex)
           {
               throw ex;
           }
           return username;
       }
    }
}
