﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMSException
{
   public class User_Exception:ApplicationException
    {

       public User_Exception():base()
       { }

       public User_Exception(string message):base(message)
       { }
    }
}
