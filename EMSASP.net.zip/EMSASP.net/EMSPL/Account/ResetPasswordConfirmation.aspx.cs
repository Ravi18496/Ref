﻿using System.Web.UI;

namespace EMSPL.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}