﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMSASP.net
{
    public class EMS_Entity
    {
        public int EmpId { get; set; }
        public string Empname { get; set; }
        public string Gender { get; set; }
        public DateTime DOJ { get; set; }
        public Decimal Salary { get; set; }
    }
}
