﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using EMSASP.net;
using EMSException;


namespace EmsDAL
{
    public class UserOperations
    {

        public static string ValidateUser(User user)
        {
            string username = "";
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "USP_Login142285";

                cmd.Parameters.AddWithValue("@UserName", user.UserName);
                cmd.Parameters.AddWithValue("@Password", user.Password);

                cmd.Connection.Open();
                username = Convert.ToString(cmd.ExecuteScalar());
                cmd.Connection.Close();
            }

            catch(User_Exception ex)
            {
                throw ex;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return username;
        }
    }
}
