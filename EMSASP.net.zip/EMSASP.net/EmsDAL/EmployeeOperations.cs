﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EMSASP.net;
using EMSException;

namespace EmsDAL
{
  public class EmployeeOperations
    { 
        public static int InsertEmployee(EMS_Entity emp)
        {
            int rowsAffected = 0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_insertEmp_142285";
                cmd.Parameters.AddWithValue("@EmpId", emp.EmpId);
                cmd.Parameters.AddWithValue("@Empname", emp.Empname);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@DOJ", emp.DOJ);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch(EmpException ex)
            {
                throw ex;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return rowsAffected;
        }


      public static List<EMS_Entity> DisplayEmployee()
        {
            List<EMS_Entity> Emplist = null;
          try
          {
              SqlCommand cmd = DataConnection.GenerateCommand();

              cmd.CommandText ="usp_SelectEmp_142285";

              cmd.Connection.Open();

              SqlDataReader dr = cmd.ExecuteReader();

              if(dr.HasRows)
              {
                  Emplist=new List<EMS_Entity>();
                  while(dr.Read())
                  {
                  EMS_Entity emp = new EMS_Entity();

                  emp.EmpId = Convert.ToInt32(dr["EmpId"]);
                  emp.Empname = dr["Empname"].ToString();
                  emp.Gender = dr["Gender"].ToString();
                  emp.DOJ = Convert.ToDateTime(dr["DOJ"]);
                  emp.Salary = Convert.ToDecimal(dr["Salary"]);

                  Emplist.Add(emp);
                  }
              }
              else
                  throw new EmpException("Employee details not found");
              cmd.Connection.Close();
          }
          catch(EmpException ex)
          {
              throw ex;
          }
          catch(SqlException ex)
          {
              throw ex;
          }
          catch(SystemException ex)
          {
              throw ex;
          }
          return Emplist;
         
        }

      public static int DeleteEmployee(int empid)
      {
          int recordsAffected = 0;

          try
          {
              SqlCommand cmd = DataConnection.GenerateCommand();

              cmd.CommandText = "usp_DeleteEmp_142285";
              cmd.Parameters.AddWithValue("@EmpId", empid);

              cmd.Connection.Open();
              recordsAffected = cmd.ExecuteNonQuery();
              cmd.Connection.Close();
          }
          catch(EmpException ex) 
          {
              throw ex;
          }
          catch(SqlException ex)
          {
              throw ex;
          }
          catch(SystemException ex)
          {
              throw ex;
          }

          return recordsAffected;
      }

      public static int UpdateEmployee(EMS_Entity emp)
      {
          int rowsAffeceted = 0;
          try 
          {
              SqlCommand cmd = DataConnection.GenerateCommand();

              cmd.CommandText = "usp_UpdateEmp_142285";

              cmd.Parameters.AddWithValue("@EmpId", emp.EmpId);
              cmd.Parameters.AddWithValue("@Empname", emp.Empname);
              cmd.Parameters.AddWithValue("@Gender", emp.Gender);
              cmd.Parameters.AddWithValue("@DOJ", emp.DOJ);
              cmd.Parameters.AddWithValue("@Salary", emp.Salary);

              cmd.Connection.Open();
              rowsAffeceted = cmd.ExecuteNonQuery();
              cmd.Connection.Close();
          }
          catch (EmpException ex)
          {
              throw ex;
          }
          catch(SqlException ex)
          {
              throw ex;
          }
          catch(SystemException ex)
          {
              throw ex;
          }

          return rowsAffeceted;
      }

      public static EMS_Entity SearchEmployee(int empid)
      {
          EMS_Entity emp = null;

          try
          {
              SqlCommand cmd = DataConnection.GenerateCommand();
              cmd.CommandText = "usp_SearchEmp_142285";

              cmd.Parameters.AddWithValue("@EmpId", empid);

              cmd.Connection.Open();
              SqlDataReader dr = cmd.ExecuteReader();
              if(dr.HasRows)
              {
                  dr.Read();
                  emp = new EMS_Entity();
                  emp.EmpId=Convert.ToInt32(dr["EmpId"]);
                  emp.Empname=dr["Empname"].ToString();
                  emp.Gender = dr["DOJ"].ToString();
                  emp.DOJ = Convert.ToDateTime(dr["DOB"]);
                  emp.Salary = Convert.ToDecimal(dr["Salary"]);
              }
              else
              {
                  throw new EmpException("Employee not available with code:" + empid);
              }
              cmd.Connection.Close();

          }
          catch (EmpException ex)
          {
              throw ex;
          }
          catch (SqlException ex)
          {
              throw ex;
          }
          catch (SystemException ex)
          {
              throw ex;
          }
          return emp;
      }
    }
}
